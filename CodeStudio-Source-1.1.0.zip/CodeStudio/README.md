# CodeStudio 1.0.0

Deutschsprachiger lokaler Windows-Code-Editor mit Monaco, Dateiexplorer, echtem PowerShell-/cmd-Terminal und optionalem KI-Assistenten in der linken Seitenleiste. Das Projekt liegt getrennt von der bestehenden NovaNotes-Anwendung. Windows 10/11 x64 sind die Zielplattformen; der tatsächliche Prüfstand steht in [docs/PRUEFBERICHT.md](docs/PRUEFBERICHT.md).

## Installation

Der NSIS-Installer wird als **`release/CodeStudio-Setup-1.0.0-x64.exe`** erzeugt. Die tatsächlich abgeschlossenen Build- und Installationstests sind im Prüfbericht aufgeführt. Setup öffnen, das Installationsverzeichnis wählen und anschließend **CodeStudio** im Windows-Startmenü starten. Setup unterstützt die Installation für das aktuelle Windows-Konto, einen Startmenüeintrag und die Desktop-Verknüpfung. Deinstallation über **Windows → Einstellungen → Apps → Installierte Apps → CodeStudio**. Eigene Projektordner werden dabei nicht gelöscht.

Der Installer und die Anwendung besitzen **keine Herausgebersignatur**. Electron und die für den Editor nötigen Ressourcen werden mitgeliefert. Zum normalen Editorstart sind weder separat installiertes Node.js noch eine Entwicklungsumgebung oder ein Entwicklungsserver erforderlich. Die Laufzeiten für eigene Programme sind davon getrennt.

## Erste Schritte

1. **Datei → Projekt öffnen …** wählt einen vorhandenen lokalen Ordner. **Neues Projekt …** legt einen neuen Ordner an. Zuletzt geöffnete Projekte sind auf der Startansicht erreichbar.
2. Im Explorer Ordner aufklappen und Dateien öffnen. Das Kontextmenü bietet Anlegen, Umbenennen, Verschieben und Löschen. Löschungen verwenden nach Bestätigung den Windows-Papierkorb.
3. Dateien in Tabs bearbeiten. Ein Punkt am Tab zeigt ungespeicherte Änderungen. **Strg+S** speichert; **Strg+Umschalt+S** öffnet „Speichern unter“. Beim Schließen fragt die Anwendung nach ungespeicherten Änderungen. Bei externen Änderungen bitte den angezeigten Konflikt bewusst auflösen.
4. **Ausführen** startet die aktive gespeicherte Datei mit der passenden erkannten Laufzeit oder öffnet eine Vorschau. **Stoppen** beendet den zugehörigen Prozessbaum. Programmargumente und Laufzeiten stehen unter **Einstellungen → Laufzeiten und Ausführung**.
5. **Terminal → Neues PowerShell-Terminal** öffnet eine echte interaktive Shell im Projektordner. Weitere Sitzungen und cmd sind ebenfalls verfügbar. Terminalbefehle und eigene Programme laufen mit den Rechten des Windows-Benutzers.

Explorer, Projektsuche und KI-Chat teilen sich die linke Seitenleiste. Die Trennlinie rechts an der Seitenleiste und oberhalb des unteren Bereichs lässt sich ziehen. Unten gibt es Terminal, Ausgabe und Probleme. Das Zahnrad öffnet die Einstellungen. Dark Mode ist Standard; Light Mode, Schrift, Einrückung, Zeilenumbruch und Minimap lassen sich anpassen. Theme, Fenstergröße und Panelaufteilung werden im Benutzerprofil gespeichert.

| Tastenkürzel | Aktion |
|---|---|
| Strg+N | Neue Datei |
| Strg+S | Speichern |
| Strg+Umschalt+S | Speichern unter |
| Strg+P | Datei schnell öffnen |
| Strg+F / Strg+H | In der Datei suchen / ersetzen |
| Strg+Umschalt+F | Im Projekt suchen |
| Strg+, | Einstellungen |
| Strg+Z / Strg+Y | Rückgängig / wiederholen |
| Strg+D | Nächstes Vorkommen als weitere Auswahl |
| Alt+Z | Zeilenumbruch umschalten |
| F5 / Umschalt+F5 | Ausführen / stoppen |
| Strg+J | Unteren Bereich ein-/ausblenden |

## Sprachen und Ausführung

Syntaxfarben und Zeilennummern sind keine Zusage vollständiger IntelliSense-Funktionen. Monaco liefert grundlegende Sprachfunktionen für Websprachen; CodeStudio enthält keinen allgemeinen Language-Server-Client für Python, Java, Kotlin oder C/C++.

| Sprache | Bearbeitung und Diagnose | Formatierung | Ausführen / Vorschau |
|---|---|---|---|
| HTML, CSS | Monaco-Syntax und eingebaute Web-Sprachdienste | Monaco | HTML-Vorschau mit lokalen Ressourcen; CSS über eine zugehörige index.html |
| JavaScript, TypeScript | Monaco-Syntax, eingebaute TS/JS-Worker; keine vollständige Projekt-/npm-Typauflösung zugesagt | Monaco | Separates Node.js; TypeScript mit mitgeliefertem Compiler |
| JSON | Monaco-Syntax und JSON-Validierung | Monaco | Bearbeiten/validieren, kein Programmstart |
| YAML | Syntax und YAML-Parserfehler | Kein zusätzlicher Formatter integriert | Bearbeiten/validieren |
| Markdown | Syntax | Kein zusätzlicher Formatter integriert | Bereinigte Markdown-Vorschau |
| Python | Syntax; kein Python-LSP integriert | Externe Werkzeuge über Terminal | Separater Python-Interpreter |
| Java | Syntax; kein Java-LSP integriert | Externe Werkzeuge über Terminal | JDK mit javac/java; Maven-/Gradle-Aufgaben bei erkanntem Projekt |
| Kotlin | Syntax; kein Kotlin-LSP integriert | Externe Werkzeuge über Terminal | kotlinc und Java; Gradle-Aufgaben bei erkanntem Projekt |
| C, C++, C#, SQL, PowerShell | Syntax; keine zusätzlichen Sprachserver integriert | Externe Werkzeuge über Terminal | PowerShell direkt; sonst vorhandene Projektwerkzeuge im Terminal |

Bei fehlenden Interpretern/Compilern zeigt CodeStudio eine verständliche Fehlermeldung und bleibt benutzbar. Zusätzliche Software wird nicht automatisch installiert. Einfache TypeScript-Dateien werden als CommonJS/ES2022 kompiliert; komplexe ESM-/Bundler-Projekte benötigen ihre vorhandenen Projektbefehle im Terminal. Details und Grenzen stehen in [docs/runtime.md](docs/runtime.md). Die Beispieldateien in `examples/` dienen der Ausführungsprüfung und können als Projekt geöffnet werden.

## KI einrichten

Unter **Einstellungen → API-Key** einen Anbieter auswählen, dessen eigenen API-Key speichern und ein Modell auswählen oder eine Modell-ID eintragen. **Modelle laden** fragt die echte Modellliste ab, soweit der Endpunkt dies unterstützt. **Verbindung testen** sendet eine echte kleine Textanfrage; dabei können Anbieterkosten entstehen. Ohne Key bleibt der normale Editor vollständig verwendbar.

OpenAI, Grok/xAI, Anthropic/Claude und Google/Gemini haben eigene Adapter. Für **Meta/Llama** muss ausdrücklich **Groq** oder **Together AI** als Betreiber gewählt werden: Meta Model API bietet laut offizieller Meta-Hilfe keine Llama-Modelle an. Der gewählte Betreiber und seine Zieladresse sind sichtbar. Ein Betreiberwechsel entfernt den bisher gespeicherten Key. Ein benutzerdefinierter kompatibler Endpunkt ist optional möglich.

Im linken KI-Chat die Auswahl, die aktive gespeicherte Datei oder bewusst gewählte Projektdateien anheften. Angeheftete Kontexte sind sichtbar und werden vor dem Senden erneut geprüft. Zugangsdaten, `.env`-Dateien und private Schlüssel werden standardmäßig blockiert. Die Grenze beträgt 30 Dateien und insgesamt 100.000 Zeichen Dateikontext. Zwischenzeitlich geänderte Dateien müssen neu angeheftet werden.

KI-Dateivorschläge werden als Diff angezeigt. Erst eine bewusste Übernahme schreibt Änderungen. Der ursprüngliche Dateistand wird geprüft; Zwischenänderungen werden nicht stillschweigend überschrieben. Übernommene Änderungen lassen sich rückgängig machen. KI-Terminalbefehle werden nicht automatisch ausgeführt. Projektbezogene Chatverläufe lassen sich löschen. Weitere Details, offizielle API-Quellen und Prüfgrenzen: [docs/ai.md](docs/ai.md).

## Daten und Schutzgrenzen

Projekte sind gewöhnliche Dateien am selbst gewählten Ort. Einstellungen, geschützte Zugangsdaten und projektbezogene Chatverläufe liegen im Electron-Benutzerdatenverzeichnis für CodeStudio, gewöhnlich `%APPDATA%\CodeStudio\`. Es werden keine API-Keys in Projektdateien oder unverschlüsseltem `localStorage` gespeichert. Electron `safeStorage` schützt gespeicherte Keys mit Windows-Funktionen; andere Programme desselben Benutzers sind dadurch nicht automatisch ausgeschlossen. Chatverläufe enthalten lokalen Unterhaltungstext, keinen automatisch gesammelten Projektinhalt.

Der Editor-Renderer besitzt keine Node-Integration. Dateisystem, Prozesse und API-Anfragen sind im Hauptprozess; die IPC akzeptiert nur die Hauptseite und erlaubte Aktionen. Projektvorschauen haben keinen Preload und keinen IPC-Zugriff. Dateizugriffe sind auf bewusst geöffnete Orte begrenzt; Verknüpfungen nach außerhalb werden abgewiesen. Ein lokales Nutzerprogramm ist keine sichere Sandbox: Es läuft mit den Rechten des Benutzers.

## Quellcode bauen

Voraussetzungen: Windows x64, Node.js mindestens 22.12 (hier verwendet: 24.22.1) und npm. Wenn für das native PTY-Modul kein passendes vorgebautes Modul vorhanden ist, werden Python und die C++-Buildtools von Visual Studio benötigt. Die Lockdatei fixiert die Abhängigkeiten. Der Editor selbst benötigt diese Entwicklungswerkzeuge nach der Installation nicht.

```powershell
cd CodeStudio
npm ci
npm run dev
```

```powershell
npm test
npm run build
npm run dist:win
```

`npm run build` erzeugt die gebündelte Oberfläche und den Electron-Hauptprozess. `npm run dist:win` baut zusätzlich den x64-NSIS-Installer im Ordner `release/`. NSIS ist auf einen Installationsdialog mit frei wählbarem Verzeichnis eingestellt. `electron-builder` berücksichtigt native Abhängigkeiten und verpackt PTY-Ressourcen außerhalb des ASAR-Archivs. Die App-ID lautet dauerhaft `de.codestudio.desktop`. Der Integrationstest wird mit `npm run test:integration` ausgeführt, sobald seine Voraussetzungen laut Prüfbericht vorhanden sind.

Die Dateien in `electron/` trennen Dateiverwaltung, Prozesse, Einstellungen, Zugangsdaten und Anbieteradapter. Die Oberfläche liegt in `src/`, Buildskripte in `scripts/`, kritische automatisierte Prüfungen in `tests/`. [docs/PRUEFBERICHT.md](docs/PRUEFBERICHT.md) unterscheidet zwischen implementiert, gebaut, tatsächlich getestet und offen.
