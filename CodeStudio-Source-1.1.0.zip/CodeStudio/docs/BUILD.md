# Windows-Build · CodeStudio 1.1.0

Die Entwicklung und Paketierung wurde unter Windows 11 Pro x64, Build 26200, mit Node.js 24.22.1 und npm 12.2.2 durchgeführt. Für einen eigenen Build Node.js 24 x64 einschließlich npm installieren. Die fertige Anwendung benötigt dieses Entwicklungswerkzeug nicht.

Im entpackten Quellcodeordner:

```powershell
npm ci
npm test
npm run build
npm run dist:win
```

Ergebnis: `release/1.1.0/CodeStudio-Setup-1.1.0-x64.exe`. Das unverpackte Windows-Paket liegt unter `release/1.1.0/win-unpacked/`. `npm run dev` startet optional den Entwicklungsmodus. Für den gelieferten Stand mit Lockdatei immer `npm ci` verwenden.

Die Lockdatei fixiert alle installierten Versionen. Die vom Paketmanager erforderlichen Installationsskripte sind im Feld `allowScripts` festgelegt. Die mitgelieferten `build/icon.ico` und `build/icon.png` sind fertige Ressourcen; das optionale Python-Skript zur Neuerzeugung des Symbols gehört nicht zu den Buildvoraussetzungen.

Der eigene Projektcode steht unter der MIT-Lizenz in `LICENSE`. `THIRD_PARTY_NOTICES.txt` enthält die gesammelten Lizenz- und Hinweistexte der dort bezeichneten Drittkomponenten; deren eigene Bedingungen bleiben bestehen. Beide Dateien werden in das App-Paket aufgenommen. Auch Electron-Lizenz und Chromium-Hinweise neben der installierten EXE müssen bei einer Weitergabe erhalten bleiben. Die Hinweissammlung ersetzt keine vollständige Prüfung aller transitiven Abhängigkeiten.

Electron 45.2.3 enthält Chromium und seine eigene Node-Laufzeit. node-pty 1.1.0 liefert ein Windows-x64-N-API-Modul und ConPTY-Ressourcen; diese liegen unverpackt unter `app.asar.unpacked`. `npmRebuild: false` ist dafür bewusst gesetzt, weil kein versionsgebundenes V8-Modul neu kompiliert werden muss. Die tatsächliche Terminalprüfung im verpackten Programm ist im Prüfbericht aufgeführt. Nach einem Austausch von Electron oder node-pty muss diese Prüfung wiederholt werden.

TypeScript 7.0.2 und sein optionales Windows-x64-Compilerpaket werden über `extraResources` vollständig außerhalb von ASAR kopiert:

```text
resources/compiler/typescript/
resources/compiler/node_modules/@typescript/typescript-win32-x64/
```

Dazu gehören `typescript/lib/tsc.js`, die nativen Compilerdateien sowie sämtliche Standardbibliotheken wie `lib.d.ts`, `lib.es2022.d.ts` und `lib.dom.d.ts`. Ein bloßes `asarUnpack` der gewöhnlichen Abhängigkeit genügt nicht, weil die normale Abhängigkeitsverpackung Deklarationsdateien herausfiltern kann. Die Programmausführung bevorzugt den vollständigen Ressourcen-Compiler. Nur die Ausführung eigener TypeScript-Dateien benötigt eine separat erkannte Node.js-Laufzeit. Die Syntaxprüfung des Editors läuft unabhängig davon im mitgelieferten Monaco-Worker.

Neue Profile starten auf Englisch. Englisch, Deutsch, Spanisch, Französisch und Italienisch stehen in den Einstellungen zur Auswahl. Erst die ausdrückliche Übernahme mit Neustart speichert den Sprachwechsel; ungespeicherte Dateien werden vorher abgefragt. `src/main.tsx` lädt zunächst die gespeicherten Einstellungen, danach die passende Monaco-Sprachdatei und erst anschließend den App-/Editor-Code. Der Build muss deshalb alle von Vite erzeugten Sprach- und App-Chunks unter `dist/` enthalten. Unbekannte Meldungen externer Laufzeiten oder APIs werden nicht automatisch übersetzt.

Die NSIS-Konfiguration steht in `package.json`: stabile App-ID `de.codestudio.desktop`, x64, interaktiver Assistent, freie Verzeichniswahl, Benutzerinstallation, Startmenü, Desktopverknüpfung und reguläre Deinstallation. Der Installer bietet dieselben fünf Sprachen mit Englisch als Standard an. Seine Dialogsprache und die gespeicherte App-Sprache sind getrennte Einstellungen. App und Installer sind nicht mit einem Herausgeberzertifikat signiert.

Weitere Prüfungen:

```powershell
npm run test:integration
$env:CODESTUDIO_EXE = "$PWD\release\1.1.0\win-unpacked\CodeStudio.exe"
npm run test:integration
node scripts/test-locales.mjs
Remove-Item Env:CODESTUDIO_EXE
```

Ohne `CODESTUDIO_EXE` prüft `npm run test:integration` die gebauten App-Ressourcen mit der Entwicklungs-Electron-Binärdatei. Mit der Variablen wird genau die angegebene verpackte EXE geprüft. Die optionale Sprachmatrix `node scripts/test-locales.mjs` verwendet ebenfalls `CODESTUDIO_EXE`; ohne Variable erwartet sie `release/win-unpacked/CodeStudio.exe`. Für Version 1.1.0 daher den oben gezeigten Pfad ausdrücklich setzen. Ihr Bericht liegt unter `.qa/locale-results.json`.

Die Tests verwenden eigene Profile und Projektordner unter `.qa`. Sie starten mit `CODESTUDIO_BACKGROUND_TEST=1` unsichtbar und verwenden ausschließlich die virtuelle Dokumentfokusemulation des Testbrowsers. Die Sprachmatrix prüft Standard- und gespeicherte Sprache, Monaco-Widgets, Neustart-Persistenz und den Schutz ungespeicherter Dateien. Simulierte native Dialogantworten und ein abgefangener Relaunch-Aufruf für den Neustarttest werden im Bericht ausdrücklich bezeichnet; das erneute Öffnen des gespeicherten Profils erfolgt in einem echten neuen Prozess. API-Schlüssel der funktionalen Tests sind ausschließlich inaktive Testzeichenfolgen; es werden keine Live-KI-Anfragen gesendet.

Wer zuerst das verpackte Programm prüfen und danach aus genau diesem Paket den Installer erstellen möchte, kann den Build aufteilen:

```powershell
npm run build
node node_modules/electron-builder/cli.js --dir --win --x64
```

Nach den Prüfungen dürfen die App-Ressourcen bis zum folgenden Schritt nicht verändert werden:

```powershell
node node_modules/electron-builder/cli.js --prepackaged release/1.1.0/win-unpacked --win nsis --x64
node scripts/verify-package.mjs release/1.1.0
```

`npm run dist:win` ist der zusammenhängende Standardbefehl mit Ausgabe unter `release/1.1.0/`. Das anschließend aufgerufene `scripts/verify-package.mjs` prüft Installergröße, native PTY-Ressourcen und die vollständigen TypeScript-Standardbibliotheken.

Eine echte Installation und Deinstallation prüft optional `.\scripts\test-installer.ps1`. Dieses Skript verändert eine Windows-Benutzerinstallation und deren Startmenüeintrag und verweigert den Start bei einer bereits vorhandenen CodeStudio-Installation. Dafür ein separates Testkonto verwenden. Installerprüfung und App-Tests getrennt ausführen: Der Installer kann laufende CodeStudio-Instanzen beenden. Eine solche Prüfung wird durch den Build oder die Sprachmatrix nicht automatisch durchgeführt.

Die Lockdatei und Befehle machen den Build nachvollziehbar, garantieren jedoch keine bitidentische Setup-Datei: Buildpfade, Zeitstempel und Kompression können das Binärartefakt verändern. Tatsächlich ausgeführte Prüfungen und offene Abnahmepunkte stehen im jeweiligen versionsbezogenen Prüfbericht.

Geprüfte Primärdokumentation: [Electron: native Module](https://www.electronjs.org/docs/latest/tutorial/using-native-node-modules), [Electron: Sicherheit](https://www.electronjs.org/docs/latest/tutorial/security), [Electron: Plattformen](https://github.com/electron/electron#platform-support), [electron-builder: NSIS](https://www.electron.build/docs/nsis/), [node-pty](https://github.com/microsoft/node-pty).
