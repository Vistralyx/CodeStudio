# Terminal, Laufzeiten und Ausführung

CodeStudio startet echte Windows-Prozesse. Diese laufen mit den Rechten des angemeldeten Benutzers. Es handelt sich **nicht** um eine Sicherheits-Sandbox. Laufzeiten werden niemals automatisch installiert.

## Terminal

Jede Sitzung verwendet `node-pty` und Windows ConPTY. PowerShell wird ohne Benutzerprofil gestartet; `cmd.exe /d` ist die Alternative. Sitzungen starten im bewusst geöffneten Projektordner. Eingaben und Größenänderungen werden direkt zur PTY weitergereicht. Strg+C sendet einen Abbruch; Schließen und **Stoppen** beenden den eigenen Prozessbaum mit Windows `taskkill /PID … /T /F`. Beim Beenden der App werden alle vom Dienst verwalteten Sitzungen geschlossen.

Eine PTY vereinigt Standardausgabe und Fehlerausgabe zu einem interaktiven Terminaldatenstrom. Deshalb wird dieser Strom als `combined` bezeichnet; eine nachträgliche zuverlässige Trennung der beiden Kanäle wird nicht behauptet. Exitcodes werden vom tatsächlichen PTY-Prozess gemeldet. Eine Überschrift mit Arbeitsordner ist als App-Information gekennzeichnet, nicht als Programmausgabe.

## Laufzeiten

Unter **Einstellungen → Laufzeiten und Ausführung** werden Node.js, Python, Java, javac, kotlinc, Maven und Gradle über den aktuellen PATH gefunden und mit einer Versionsanfrage geprüft. Für jeden Eintrag kann über einen nativen Dateidialog eine vorhandene EXE/CMD/BAT ausgewählt werden. Eine fehlende Laufzeit verhindert weder den Editorstart noch das Bearbeiten anderer Dateien. Bekannte Python-Microsoft-Store-Platzhalter unter WindowsApps werden bei der automatischen Suche übersprungen, damit die Erkennung kein Store-Fenster öffnet. Ein bewusst manuell gewählter Pfad wird tatsächlich geprüft.

Der Editor bringt seine eigene Electron-Laufzeit mit. Für eigene JavaScript- und TypeScript-Programme wird bewusst ein separates Node.js verwendet.

Der vollständige TypeScript-Compiler einschließlich seiner Deklarationsdateien wird im Installer zusätzlich als App-Ressource ausgeliefert: `resources/compiler/typescript/` und `resources/compiler/node_modules/@typescript/typescript-win32-x64/`. Die Ausführung verwendet vorrangig `resources/compiler/typescript/lib/tsc.js`. Das native TypeScript-7-Werkzeug findet dadurch seine eigene `lib.d.ts` außerhalb von ASAR-Dateien. Ein reines `asarUnpack` der gewöhnlichen Abhängigkeit reicht hier nicht aus, weil die reguläre Abhängigkeitsverpackung Deklarationsdateien ausschließen kann. Im Entwicklungsbetrieb ohne diese Ressourcen wird der lokal installierte Compiler verwendet. Bei fehlender Standardbibliothek der Ressourcen wird ein konkreter Installationsfehler angezeigt.

| Datei / Projekt | Tatsächlicher Ablauf |
|---|---|
| HTML | Privater HTTP-Server auf `127.0.0.1` mit zufälligem Port; HTML und lokale Ressourcen werden aus dem geöffneten Projekt geliefert. |
| CSS | Vorschau einer `index.html` im selben Ordner, ersatzweise im Projektordner. CSS allein ist kein ausführbares Programm. |
| JavaScript, MJS, CJS | Erkanntes/ausgewähltes `node` startet die gespeicherte Datei. |
| TypeScript, CTS, MTS | Der mitgelieferte TypeScript-Compiler kompiliert den Einstiegspunkt und aufgelöste lokale Importe; anschließend startet externes Node.js die Ausgabe. Die aktuelle einfache Dateiausführung verwendet Node16-Modulauflösung/ES2022 und liest **keine Projekt-tsconfig**. Der nächste package.json-Modultyp wird für die temporäre Ausgabe übernommen. MTS/CTS behalten die vom Compiler erzeugten Erweiterungen; komplexe ESM-/Bundler-Projekte sollten ihre eigenen Build-Befehle im Terminal ausführen. |
| Python | Ausgewähltes `python -u Datei.py` für zeitnahe Ausgabe und interaktive Eingaben. |
| Java | `javac -encoding UTF-8 -d TEMP -sourcepath PROJEKT Datei.java`, anschließend `java -cp TEMP paket.Klasse`. Paketdeklarationen werden berücksichtigt. Einstiegsklasse und Dateiname müssen zusammenpassen. |
| Kotlin KT | `kotlinc Datei.kt -include-runtime -d TEMP/program.jar`, anschließend `java -jar …`. |
| Kotlin KTS | `kotlinc -script Datei.kts -- ARGUMENTE`. |
| Maven | Bei `pom.xml`: compile, test, package, exec:java. Ein vorhandenes `mvnw.cmd` hat Vorrang. `exec:java` benötigt die übliche Hauptklassenkonfiguration. |
| Gradle | Bei Gradle-Projektdateien: build, test, run. `gradlew.bat` hat Vorrang; run setzt ein entsprechend eingerichtetes application-Plugin voraus. |
| PowerShell | Windows PowerShell `-NoProfile -File Datei.ps1`; bestehende Windows-Ausführungsrichtlinien für Nutzerskripte gelten. |
| JSON / YAML / Markdown | Bearbeitung, Validierung bzw. Vorschau in der Oberfläche; kein erfundener Prozesslauf. |

Compiler-Ausgaben für einfache Programme liegen in einem eindeutig benannten temporären Verzeichnis und werden nach Ende des Prozesses entfernt. Das Projekt ist das Arbeitsverzeichnis; relative Dateien und Eingaben beziehen sich darauf. Node-CJS-Abhängigkeiten können über `NODE_PATH=PROJEKT/node_modules` aufgelöst werden. Für komplexe Projekte ist das echte Terminal vorgesehen.

Programmargumente werden in einzelne Argumente zerlegt. Leerzeichen können mit einfachen oder doppelten Anführungszeichen zusammengefasst werden; leere Argumente sind mit `""` möglich. Argumente sind Daten, keine PowerShell-Befehle. Pfade und Argumente werden als PowerShell-Stringliterale in einen UTF-16-kodierten Startauftrag eingebettet. Die native Argumentliste wird über .NET ProcessStartInfo nach den Windows-Quotingregeln übergeben, damit auch leere Argumente, eingebettete Anführungszeichen und abschließende Backslashes erhalten bleiben. Batch-Wrapper gehören zur ausdrücklich gestarteten lokalen Projektsoftware; ihre eigenen Skripte und Argumentverarbeitungsregeln gelten zusätzlich. Die einfache Batch-Ausführung lehnt Prozentzeichen und eingebettete Anführungszeichen ab, da cmd diese sonst verändern könnte; für solche speziellen Fälle ist das Terminal vorgesehen.

## Desktop-Grenzen

Die Umgebung gestarteter Programme enthält eine Positivliste von Windows-/Toolchainvariablen. API-Keys, beliebige Secret-/Tokenvariablen, fremde PSModulePath-Vorgaben und Electron-Startoptionen werden nicht vererbt. PowerShell ermittelt seine normalen Systemmodulpfade selbst. Absichtlich im Projekt oder Betriebssystem abgelegte Daten bleiben für Benutzerprogramme entsprechend deren Benutzerrechten zugänglich.

Die Vorschau besitzt keinen Electron-Preload und keinen Zugriff auf die Editor-IPC. Jeder Dateizugriff wird gegen das geöffnete Projekt und den kanonischen Dateipfad geprüft. Verknüpfungen nach außerhalb, `.env`, private Schlüssel, bekannte Zugangsdaten-Dateien/-Ordner wie `.npmrc` und `.aws`, `.git` und `node_modules` werden nicht ausgeliefert. Die Vorschau ist lesend, hat keine CORS-Freigabe und erhält eine Content-Security-Policy, die Netzwerkzugriffe auf ihren eigenen Ursprung begrenzt. Dadurch werden lokale Ressourcen unterstützt; fremde CDN-Ressourcen werden standardmäßig blockiert. Änderungen im Projekt lösen eine Aktualisierungsbenachrichtigung aus.

## Offizielle Quellen

Gelesen am 05.11.2026:

- [Microsoft node-pty, Windows-/ConPTY-Unterstützung und API](https://github.com/microsoft/node-pty)
- [TypeScript-Compileroptionen und Dateiausführung](https://www.typescriptlang.org/docs/handbook/compiler-options.html)
- [Windows taskkill, insbesondere /T und /F](https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/taskkill)
- [Java-Befehlsreferenz](https://docs.oracle.com/en/java/javase/26/docs/specs/man/java.html)
- [Kotlin-Befehlszeilencompiler](https://kotlinlang.org/docs/command-line.html)

Automatisierte Tests in `tests/runtime.test.ts` prüfen die Umgebungsfilterung, echte PowerShell-Argumentübergabe, das Beenden eines echten Prozessbaums und die lokale Vorschau einschließlich Pfadflucht. Native PTY-/Editorintegration und die Beispielprogramme müssen zusätzlich im tatsächlichen Electron-Paket geprüft werden; ein Unit-Test allein belegt diese Integration nicht.

## Durchgeführte Laufzeitprüfung am 05.11.2026

Auf dem vorhandenen Windows-x64-System, Build **10.0.26200**, wurden Electron **45.2.3** und die mit `node-pty` **1.1.0** gelieferten `win32-x64`-N-API-Binaries zusammen tatsächlich gestartet. Ein eigener C++-Neubau war für diese Binärkombination nicht nötig. Die Prüfung lief direkt unter Electron, noch nicht aus dem abschließenden NSIS-Installationsverzeichnis.

| Prüfung | Beobachtetes Ergebnis |
|---|---|
| Sechs automatisierte Laufzeittests | Bestanden, einschließlich echter Prozessbaumbeendigung und echter PowerShell-Argumentübergabe. |
| JavaScript | Node.js 24.22.1, interaktive Namenseingabe `Jörg`, echte Ausgabe und Exitcode 0. |
| TypeScript | TypeScript 7.0.2 kompiliert; Node.js führt Ausgabe aus; Exitcode 0. |
| Python | Python 3.14.8, interaktive Namenseingabe `Jörg`, echte Ausgabe und Exitcode 0. |
| Java | javac/Java 26.0.2.1, echte Kompilierung und Ausgabe, Exitcode 0. |
| Dauerlauf | Nach echter Ausgabe mit Stoppen beendet; erzwungener Exitcode 1 als Abbruch beobachtet. |
| PowerShell-Terminal | Eigene interaktive Sitzung im Projektordner mit Umlaut, `Write-Output 'TERMINAL_ECHT'; exit`, Ausgabe und Exitcode 0. |
| HTML/CSS | Beide lokalen Dateien erfolgreich vom echten Vorschau-HTTP-Server gelesen. |
| Kotlin | Compiler fehlt auf diesem System; die tatsächlich erzeugte Fehlermeldung wurde geprüft. Keine Kotlin-Kompilierung behauptet. |
| Maven/Gradle | Hier nicht installiert; Projektausführungen bleiben ungeprüft. |

Die vollständigen Terminaldaten des Entwicklungstests stehen lokal in `.qa/runtime-report.json`. Eine Prüfung der verpackten, installierten Anwendung ist ein zusätzlicher Abnahmeschritt und muss im übergreifenden Prüfbericht separat ausgewiesen werden.
