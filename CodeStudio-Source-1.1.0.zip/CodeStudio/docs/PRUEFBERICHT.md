# CodeStudio 1.0.0 – Prüfbericht

Stand: 5. November 2026. Dieser Bericht trennt vorhandenen Code, tatsächlich erzeugte Pakete und ausgeführte Prüfungen. Eine erfolgreiche Paketierung ersetzt keine vollständige Windows-Abnahme.

## Lieferstand und Umgebung

- Installierbarer **NSIS-Installer für Windows x64**: `release/final/CodeStudio-Setup-1.0.0-x64.exe`.
- Quellcode einschließlich Lockdatei, Tests und Konfiguration: `release/final/CodeStudio-Quellcode-1.0.0.zip`.
- Anleitung: `release/final/Anleitung-CodeStudio.txt`; technische Buildanleitung: [BUILD.md](BUILD.md).
- Tatsächliche Testumgebung: **Windows 11 Pro x64, Build 10.0.26200**. Keine separate Windows-10-Testumgebung verfügbar.
- Electron 45.2.3 / Chromium 156.0.8078.80 / integriertes Node 24.22.2; Entwicklungs-Node 24.22.1, npm 12.2.2.
- React 19.3.1, Monaco 0.57.0 mit offizieller deutscher Oberfläche, xterm 6.0.0, node-pty 1.1.0, TypeScript 7.0.2, electron-builder 26.18.0.
- DOMPurify 3.4.17 und YAML 2.9.1. Alle aufgelösten Versionen stehen in `package-lock.json`.
- **Keine Herausgebersignatur** für Setup und App; Authenticode-Status der Setup-Datei: `NotSigned`.

Die Abschlussdatei wurde tatsächlich erzeugt: **146601955 Bytes**. SHA-256: `84ba90f6738835f68863b36c109ff24224f4761c743aea3f7e16288c8ec7bb27`. Die Strukturprüfung bestätigt die eingebetteten App-Ressourcen, PTY-Nativmodule und den vollständigen TypeScript-Compiler einschließlich Standardbibliotheken.

## Implementiert

| Bereich | Vorhandene Funktionen und Grenzen |
|---|---|
| Oberfläche | Deutsche Menüs, Explorer/Suche/KI links, Dateitabs, Breadcrumbs, Terminal/Ausgabe/Probleme unten, Statuszeile, verschiebbare Trennlinien; Dark/Light und gespeicherte Fenster-/Panelwerte |
| Dateien | Native Projekt-/Dateiauswahl, neue Projekte, verschachtelter Explorer, Erstellen/Umbenennen/Verschieben, Drag-and-drop, Papierkorb nach Bestätigung, mehrere Tabs, Speichern/Speichern unter, Verlustschutz, externe Änderungen und Hashkonflikte, Dateisuche/Textsuche mit Grenzen und Ausschlüssen |
| Editor | Syntaxfarben für die verlangten Sprachen; Web-/TS-/JSON-Dienste, YAML-Parser, Suchen/Ersetzen, Mehrfachcursor, Faltung, Kommentare, Formatierung soweit ein eingebauter Formatter vorhanden ist. Keine vollständigen Python-/Java-/Kotlin-/C++-Sprachserver |
| Terminal/Ausführung | Echte PowerShell-/cmd-ConPTY-Sitzungen, Größenänderung und interaktive Eingaben, Prozessbaum-Stopp; Node, TS, Python, Java, Kotlin sowie erkannte Maven-/Gradle-Aufgaben. PTY führt Standard- und Fehlerausgabe zusammen |
| Vorschau | Lokaler Loopbackserver mit Pfadprüfung und Dateifiltern, HTML/CSS/klassisches JS/Module/lokales fetch; getrennte Herkunft, Sandbox, kein Editor-Preload. Bereinigte Markdown-Vorschau |
| KI | Provideradapter für OpenAI, xAI, Claude, Gemini; Llama nur über ausdrücklich gewählten Betreiber; sichtbares benutzerdefiniertes Ziel, Modelllisten/manuelle Modell-ID, echte Verbindungstests, Streaming/Abbruch, Kontextdateien/Auswahl, projektbezogener löschbarer Verlauf, Diff/Übernehmen/Rückgängig |
| Zugangsdaten | Asynchrones Electron-safeStorage unter Windows; keine Klartext-Keys in Projekten, localStorage oder Prozessumgebung. Betreiber-/Adresswechsel entfernt den alten Key. Keine mitgelieferten echten Schlüssel |
| Desktop-Grenzen | Renderer-Sandbox, Context Isolation, Node aus, begrenzte Preload-Schnittstelle, Hauptframe-/Absenderprüfung, Pfad-/Junction-Prüfung. Gestartete Nutzerprogramme laufen mit Benutzerrechten und sind keine sichere Sandbox |
| Setup | Stabile App-ID `de.codestudio.desktop`, Benutzerinstallation, Verzeichniswahl, Startmenü, eigene Seite mit optionaler Desktopverknüpfung, regulärer Deinstaller; Benutzerprofil bleibt bei Deinstallation erhalten |

Die einfache TypeScript-Kette verwendet ES2022/Node16-CommonJS für Einstiegsskripte und ignoriert die Projekt-tsconfig. Umfangreiche Bundler-/npm-Projekte verwenden ihre vorhandenen Befehle im Terminal. Weitere Sprachgrenzen stehen in [README](../README.md) und [runtime.md](runtime.md).

## Automatisierte Tests

| Prüfung | Tatsächliches Ergebnis | Aussagegrenze |
|---|---|---|
| `npm test` | **71 Tests bestanden** in drei Dateien | Windows-Datei-/Prozesstests und ausdrücklich simulierte Provider-/Dialogadapter |
| Dateiverwaltung | **42 bestanden** | Echte temporäre Dateien: Umlaut-/Leerzeichenpfade, Traversal, Gerätepfade/ADS, Junctions, Scopewechsel, UTF-8/UTF-16/BOM, Binärdaten, Konflikte, exklusive Erstellung, Suche, Kontextfilter, Diff/Undo. Native Dialoge/Papierkorbanbindung in Unit-Tests injiziert |
| KI-Adapter | **23 bestanden** | HTTP-Antworten und Credential-Protector simuliert. Getrennte Formate/Header, zerteiltes SSE, HTTP-/Streamfehler, Redaktion, sensible Inhalte, Kontext-Hashes und Projektwechsel geprüft. Keine Live-Anbietererfolge |
| Laufzeiten | **6 bestanden** | Darunter echte PowerShell-Argumentübergabe und echte Prozessbaumbeendigung sowie Loopback-/Pfadschutz |
| Vollständige Paket-Integration | **31 bestanden, 0 fehlgeschlagen, 2 übersprungen** | Tatsächliche verpackte EXE, eigenes Profil. Bericht [integration-packaged-results.json](pruefbelege/integration-packaged-results.json) |
| Fehlende Laufzeit | Bestanden | Fehlender Kotlin-Compiler erzeugt verständlichen Fehler; der Editor bleibt benutzbar |
| Windows-safeStorage | Bestanden im Paket | Echte Windows-Verschlüsselung mit inaktiven Testzeichenfolgen: Speichern, Ersetzen, Entschlüsseln, Löschen; kein Klartext auf Disk, keine API-Netzwerkanfrage |
| Schlüsselweitergabe an Programme | Bestanden | Sentinel-API-Key aus der Testumgebung ist im gestarteten JS-Programm nicht vorhanden |
| Neuaufbau | `npm ci` und `npm run build` erfolgreich | Eigene frische Quellkopie ohne übernommenes node_modules, Lock unverändert. Nach letzten reinen Quelländerungen erneut gebaut und Fingerprints abgeglichen; keine Behauptung bitidentischer EXEs |
| Produktionsabhängigkeiten | `npm audit --omit=dev`: 0 Funde | Zeitpunktbezogener Paketmanagerbericht, keine allgemeine Sicherheitsgarantie |

Der vollständige Integrationslauf prüfte Explorer und Erstellen über die echte Oberfläche, drei genaue schnelle Tipprunden, Speichern und erneutes Lesen, kontrollierte Abbruch-/Speicherentscheidungen bei ungespeicherten Dateien, externe Konflikte, Strg+P, initiale YAML-Diagnosen und deren Entfernung beim Schließen, Dark/Light und Aufteilung nach Neustart.

JS, TypeScript, Python und Java wurden wirklich ausgeführt; TypeScript und Java tatsächlich kompiliert. Interaktive Eingabe, echte PowerShell-/cmd-Sitzungen und Stoppen einschließlich eines gestarteten Kindprozesses wurden geprüft. HTML lief über die Ausführen-Schaltfläche im App-iframe: klassische Skripte, ES-Modulimport und lokale JSON-fetch-Anfrage. Zugriff auf Eltern-Dokument/Editor-Bridge blieb gesperrt.

Der KI-Diff im Integrationstest stammt ausdrücklich aus einer **synthetischen lokalen Chatnachricht**. Die echte Monaco-Diffanzeige, Einzelübernahme, Rückgängig und Konfliktschutz wurden danach über die Oberfläche geprüft. Das ersetzt keinen Live-KI-Chat.

Native Warnungsentscheidungen wurden kontrolliert über den Testprozess beantwortet und sind als solche im JSON-Bericht gekennzeichnet. Eine reale manuelle Papierkorbbedienung und globale Zwischenablagen-Tastaturbedienung sind dadurch nicht abgenommen.

## Prüfungen am abschließenden Oberflächenstand

Nach dem vollständigen 31-Punkte-Lauf wurden das mitgelieferte deutsche Monaco-Sprachpaket und die synchrone Erfassung unmittelbar folgender Speicherbefehle ergänzt. Danach erfolgte eine eigene **gezielte Paketprüfung: 4 bestanden, 0 fehlgeschlagen, keine Rendererfehler**. Die tatsächlich gerenderten Such-/Ersetzen-Beschriftungen waren deutsch. Vier aufeinanderfolgende Tippen→sofort Strg+S-Durchgänge sendeten jeweils den neuesten Inhalt an den Hauptprozess und speicherten ihn vollständig. Diff/Einzelübernahme/Rückgängig und Schließen der Ansicht wurden erneut geprüft. Nachweis: [localization-results.json](pruefbelege/localization-results.json). Der vorherige vollständige Lauf wird dadurch nicht nachträglich als identischer Binärstand ausgegeben.

Zusätzlich bestanden **5 Prüfungen des Pakets mit reinem Windows-PATH**: lokale Ressourcen aus app.asar ohne Entwicklungsserver, erfolgreiche App-Initialisierung, Renderer-Isolation, eigenes unsichtbares/unfokussiertes Testfenster und gerenderte App-Oberfläche. Node-/Entwicklungsverzeichnisse fehlten im PATH; die App verwendete ihre eingebettete Laufzeit. Nachweis: [no-devtools-results.json](pruefbelege/no-devtools-results.json). Dies ist kein Test auf einem separaten Rechner ohne installierte Werkzeuge. Der erste zu strenge Harness-Warteversuch auf inaktives Monaco wurde korrigiert und nicht als bestandener Produktcheck gezählt.

Die letzten Tests verwendeten ausschließlich ein eigenes Profil und unsichtbare Fenster mit virtueller CDP-Dokumentfokusemulation. Die vorhandene Benutzerinstallation, globale Zwischenablage und native Bildschirmsteuerung wurden dabei nicht bedient.

## Installation und laufende Benutzerinstallation

Eine frühe tatsächlich erzeugte Setup-Datei wurde unbeaufsichtigt für das aktuelle Windows-Konto in einen frei gewählten Pfad mit Leerzeichen/Umlauten installiert (Exitcode 0). Der Startmenüeintrag zeigte auf die installierte EXE. Der erste Testlauf brach an einer zu engen Prüfannahme für den Registry-Anzeigenamen ab: tatsächlich heißt er `CodeStudio 1.0.0`, nicht nur `CodeStudio`. Der vorhandene Registry-Eintrag wurde anschließend gelesen. Dies ist kein vollständiger bestandener Installerlauf.

Diese frühe separate Testinstallation wurde mit ihrem echten Deinstaller entfernt (Exitcode 0). Danach wurde geprüft: ihre EXE fehlt, die außerhalb des Programmordners angelegte Projektdatei ist weiterhin vorhanden.

Der Benutzer hat anschließend selbst den Zwischenstand regulär installiert und gestartet. Die laufende Installation unter `%LOCALAPPDATA%\Programs\CodeStudio` wurde nur anhand des Prozesspfads erkannt und bei den späteren Tests unverändert belassen. Das ist eine Nutzerbeobachtung, keine automatisierte Abnahme der letzten Setup-Datei.

Die Sichtprüfung des Installationsassistenten bestätigte deutsche Texte und die Benutzer-/Alle-Benutzer-Auswahl. Sie wurde durch den Benutzer mit Escape beendet. Weitere native Bildschirmsteuerung wurde eingestellt; spätere App-Tests liefen mit eigenen unsichtbaren Fenstern und virtueller CDP-Dokumentfokusemulation.

**Der letzte Installer wurde gebaut und strukturell geprüft, aber nicht erneut installiert/deinstalliert**, damit die inzwischen verwendete Benutzerinstallation erhalten bleibt. Das Installertestskript verweigert inzwischen absichtlich den Start bei vorhandener CodeStudio-Installation. Für eine vollständige abschließende Abnahme ist ein separates Windows-Testkonto beziehungsweise Testsystem ohne CodeStudio nötig.

Projektordner außerhalb des Programmverzeichnisses und das CodeStudio-Benutzerprofil bleiben bei regulärer Deinstallation erhalten. Eigene Projekte sollten nicht innerhalb des Installationsverzeichnisses abgelegt werden.

## Behobene Befunde

- Monaco-Modell ist während des Tippens maßgeblich; gewöhnliche React-Echos setzen weder Inhalt noch Cursor zurück. Nur explizite externe Revisionen ersetzen den Modellinhalt.
- Der Zustand für sofortige Speicher-/Schließbefehle wird synchron mit den Editoränderungen aktualisiert, damit Strg+S direkt nach dem Tippen keinen älteren Stand verwendet.
- Windows-Speichersperren: begrenzte Wiederholung bei EPERM/EBUSY/EACCES, erneute Pfad-/Hashprüfung vor jedem Versuch, kein Löschen des Ziels als Ersatz für atomisches Ersetzen.
- Vollständiger nativer TypeScript-Compiler samt lib.d.ts wird explizit als Ressource kopiert; ein ASAR-Unpack allein genügte wegen Standardfiltern des Paketierers nicht.
- Read-only-Diffs verwenden kein Gutter-Aktionsmenü und lösen Modelle vor der Entsorgung. Der beobachtete Lebenszyklusfehler entspricht dem [dokumentierten Monaco-Befund](https://github.com/microsoft/monaco-editor/issues/4581); es wird keine globale Fehlerunterdrückung verwendet.
- DOMPurify und YAML wurden auf gepatchte Versionen aktualisiert. Verbleibende sechs moderate Auditmeldungen betreffen ausschließlich minimatch in der Entwicklungs-/Buildkette. Ein inkompatibler Major-Override wurde nicht erzwungen.

## Explizit offen

- Keine echten API-Zugangsdaten bereitgestellt: keine Live-Verbindung/Modellverfügbarkeit/Streamingantwort bei OpenAI, xAI, Claude, Gemini, Groq oder Together geprüft.
- Kotlin, Maven und Gradle waren hier nicht installiert; deren erfolgreiche Kompilierung/Projektaufgaben bleiben ungeprüft.
- Kein gesonderter Windows-10-Test und kein zweiter frischer Rechner ohne Entwicklungswerkzeuge. Ein bereinigter PATH im selben Windows-System ist davon zu unterscheiden.
- Abschließende Installation, Start über Startmenü und Deinstallation exakt der letzten Setup-Datei bleiben offen; siehe bestehende Benutzerinstallation oben.
- Keine manuelle Endabnahme der optionalen Desktop-Checkbox, des Papierkorbs oder der globalen Zwischenablagen-Tastaturbedienung nach dem Abbruch der Bildschirmsteuerung.
- Keine Codesignatur, SmartScreen-Reputation oder automatische Updateverteilung eingerichtet.

Die Build-/Testprotokolle, JSON-Ergebnisse und ausgewählte Screenshots liegen im Quellcode unter `docs/pruefbelege/`. Die frühere fehlgeschlagene Installer-Prüfannahme bleibt dort ausdrücklich als früher Teilversuch dokumentiert; daraus wird kein vollständig bestandener Installerlauf abgeleitet.


