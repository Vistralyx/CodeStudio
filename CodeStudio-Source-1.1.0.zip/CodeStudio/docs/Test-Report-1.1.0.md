# CodeStudio 1.1.0 — Test report

Date: 6 November 2026. This report covers the packaged 1.1.0 application. The older `PRUEFBERICHT.md` and its evidence describe the historical 1.0.0 release.

## Delivered changes

- A new or legacy profile without a language preference starts in English. Invalid saved language values fall back to English while retaining other preferences.
- Settings → Appearance → Language offers English, Deutsch, Español, Français and Italiano. Selecting a language is a draft; **Apply language and restart** persists it. Unsaved files go through the existing Save/Discard/Cancel protection before the restart.
- The workbench, settings, panels, native application menus, application dialogs and application-generated backend errors are translated. Monaco's own language bundle is loaded before the first editor is created. Translations ship offline with the application.
- Filenames, paths, model IDs, existing chat messages, source code, terminal/compiler output and unrecognized operating-system or provider messages are preserved. Changing the interface language does not translate those contents.
- File conflicts retain a stable `FILE_CONFLICT` marker across Electron's context bridge, independently of their displayed language.
- Project-owned code now has an MIT `LICENSE`. `THIRD_PARTY_NOTICES.txt` preserves the collected component notices; bundled Electron and Chromium notices are retained. This collection is not a complete transitive license audit.
- No README was created or edited. The existing root README is byte-identical to the one in the 1.0.0 source archive (SHA-256 `c650c98e92d981991b8b8ddb5ae6312e57fc7b1ebbc27f9a9499979324dc0460`).

## Executed checks

| Check | Result | Scope |
| --- | --- | --- |
| Unit tests | **104 passed** | Filesystem 43, AI adapters 27, runtime 9, language/settings 25. Provider HTTP responses are mocked; no real provider credentials are used. |
| Type checking and production build | **Passed** | `npm run build`, including TypeScript, offline Monaco resources, renderer and Electron bundles. |
| Full packaged integration | **32 passed, 0 failed, 2 skipped** | Actual `release/1.1.0/win-unpacked/CodeStudio.exe`; German fixture plus an English IPC conflict check. |
| Packaged language matrix | **9 passed, 0 failed** | Fresh English default, all five saved languages, actual localized Monaco Find control, preference persistence across real process restarts, invalid-language fallback and dirty-file restart guard. |
| Fresh source installation/build | **Passed** | `npm ci` and `npm run build` in a separate source copy without reused node_modules; unchanged lockfile. Fingerprint scope and the test-harness-only refresh are recorded in the reproduction evidence. |
| Installer build | **Passed** | NSIS setup created from the same unchanged application package used by the integration and language checks. |
| Package resources | **Passed** | Native PTY prebuilds and complete Windows TypeScript compiler/standard libraries present. Packaged main/preload, MIT license and third-party notices match their source files. Electron/Chromium license files are present. |

The full integration run executed JavaScript, TypeScript, Python and Java, including TypeScript/Java compilation, interactive process input, process-tree stopping, real PowerShell/cmd terminals, local HTML/module/fetch preview, file watching, rapid typing/save, search, external-change protection and Windows safeStorage with inert test strings. It checked isolation from preview content and refusal of IPC from a foreign window. Both packaged suites recorded **zero renderer errors**.

The AI diff test used an explicitly synthetic local chat suggestion. The actual diff, Apply and Undo controls then changed real temporary project files. This is not a live model response or a provider availability test.

Native dialog choices and the language-change relaunch call were intercepted only inside isolated test instances. The saved language was subsequently opened in a real new process. This verifies the guard and persistence; it is not manual operation of native Windows dialogs or an uninterrupted `app.relaunch` end-to-end check.

Hidden window captures show translated workbench layouts; some captured a prior compositor frame. Settings labels and language choices were asserted through the actual DOM, not claimed as complete visual review of those captures. Two initial harness waits were corrected (Monaco Find uses a textarea; an Apply button's text contained trailing whitespace); the final successful runs used the unchanged product package.

## Environment and remaining limits

- Tested on **Windows 11 Pro x64, build 26200**. Electron 45.2.3, Chromium 156.0.8078.80, embedded Node 24.22.2; build Node 24.22.1 and npm 12.2.2.
- The final setup is **146,775,111 bytes** and **unsigned**. See `SHA256SUMS.txt` for its exact checksum. It was built and structurally checked, not installed or uninstalled during this update. The user's existing installation and real settings/API keys were not modified or read by the tests.
- No native desktop automation, OS focus changes or global clipboard access were used. All application checks used their own hidden profiles and temporary projects.
- The two skipped integration checks were successful Kotlin execution (compiler unavailable) and live AI use (no credentials supplied to tests). Maven/Gradle execution, live model availability, separate Windows 10 testing and a clean second machine remain unverified.
- Manual installer language/shortcut pages, final installation/uninstallation and shell shortcuts remain unverified for this exact setup. The existing installer test refuses to run when CodeStudio is already installed.
- No code-signing certificate or automatic update service is configured. A fresh source build demonstrates buildability, not byte-identical installer reproduction.

Machine-readable results and selected logs are in `docs/pruefbelege/1.1.0/`. Detailed build instructions are in `docs/BUILD.md`.
