# KI-Anbindung und Schlüssel

CodeStudio benötigt für Dateiverwaltung, Bearbeitung, Vorschau und Terminal keinen API-Key. KI-Anfragen werden ausschließlich nach „Senden“, „Modelle laden“ oder „Verbindung testen“ ausgeführt. Der Verbindungstest erzeugt eine echte kleine Textanfrage und kann beim Anbieter Kosten verursachen. Es gibt keine fest eingebauten KI-Antworten und keine Preisberechnung.

Unter **Einstellungen → API-Key** Anbieter wählen, einen Key dieses Anbieters speichern und die Modell-ID setzen oder Modelle laden. Modellvorschläge bedeuten keine geprüfte Kontoverfügbarkeit. Nur eine echte erfolgreiche Textantwort setzt den Status auf erfolgreich. Der aktive Anbieter und das Modell sind im linken Chat sichtbar. Requests können abgebrochen werden; nach 180 Sekunden werden sie beendet. Gemeldete Tokenzahlen stammen ausschließlich aus API-Metadaten, nicht aus erfundenen Schätzungen.

## Anbieter und Ziele

| Eintrag | Festes Ziel | Format |
|---|---|---|
| OpenAI | `https://api.openai.com/v1` | Responses API, `store: false`, SSE |
| Grok / xAI | `https://api.x.ai/v1` | dokumentierte Chat Completions, SSE |
| Anthropic / Claude | `https://api.anthropic.com/v1` | Messages API, `anthropic-version: 2026-10-21`, SSE |
| Google / Gemini | `https://generativelanguage.googleapis.com/v1beta` | `generateContent` / `streamGenerateContent`, SSE |
| Meta / Llama, Betreiber Groq | erst nach ausdrücklicher Betreiberwahl `https://api.groq.com/openai/v1` | Chat Completions |
| Meta / Llama, Betreiber Together AI | erst nach ausdrücklicher Betreiberwahl `https://api.together.xyz/v1` | Chat Completions |
| Benutzerdefiniert | vom Benutzer sichtbare eingetragene Basisadresse | kompatible Chat Completions |

**Meta/Llama:** Laut offizieller Meta-Hilfe stellt Meta Model API keine Llama-Modelle bereit. CodeStudio erfindet deshalb keinen allgemeinen Meta-Llama-Endpunkt. Für gehostete Llama-Modelle muss der Benutzer ausdrücklich Groq oder Together AI wählen, ein dort verfügbares Modell wählen und den Key genau dieses Betreibers eingeben. Ein Meta-Key wird nicht automatisch an andere Dienste gesendet. Beim Wechsel des Betreibers oder der benutzerdefinierten Adresse wird der bisherige gespeicherte Key gelöscht; der neue Betreiber benötigt einen neu eingegebenen Key. Ein Modellname allein belegt nicht, dass es bei diesem Betreiber oder Konto verfügbar ist.

Benutzerdefinierte Ziele benötigen HTTPS; unverschlüsseltes HTTP ist ausschließlich für `localhost`, `127.0.0.1` und `::1` zulässig. URLs mit Benutzername, Passwort, Query oder Fragment sind nicht erlaubt. HTTP-Weiterleitungen werden für API-Anfragen abgelehnt. Anbieterspezifische Schlüssel werden nicht zwischen den Einträgen übernommen. Lokale kompatible Endpunkte können bei Bedarf einen frei gewählten Platzhalter als API-Key verwenden, wenn ihr Server keine Authentifizierung erfordert.

## Schlüssel und Kontext

Keys werden im Benutzerdatenverzeichnis in `credentials.safe.json` ausschließlich als mit Electron `safeStorage.encryptStringAsync` geschützte Daten gespeichert. Auf Windows nutzt Electron den Betriebssystemschutz; andere Programme desselben Benutzers sind dadurch nicht automatisch ausgesperrt. Ohne verfügbaren Schutz wird die Speicherung verweigert. Keys stehen nicht in Projekteinstellungen, `localStorage`, Logs oder der Umgebung gestarteter Programme. „Einblenden“ entschlüsselt den Key nur für die bewusste Anzeige im Einstellungsdialog; „Löschen“ entfernt den gespeicherten Wert.

Dateikontext ist nur der ausdrücklich angeheftete Inhalt. Vor dem Senden prüft der Hauptprozess freigegebene Dateipfade, den gespeicherten Datei-Hash und bei Auswahlen, ob der Abschnitt noch zur gespeicherten Datei gehört. Zwischenzeitlich geänderte Dateien müssen erneut angeheftet werden. Ungespeicherte Dateiänderungen bitte vor dem Anheften speichern. `.env`-Dateien, typische Credential-Dateien, `.ssh`/`.aws` und private Schlüssel werden blockiert. Maximal 30 Dateien und insgesamt 100.000 Zeichen Dateikontext sind erlaubt. Der Chat kann höchstens 260.000 Zeichen und 150 Nachrichten enthalten. Zugangsdaten niemals absichtlich in eine Chat-Nachricht einfügen.

Chatverläufe liegen getrennt nach Projekt im Benutzerdatenverzeichnis und lassen sich löschen. Sie enthalten den Unterhaltungstext; vertraulicher Code bleibt dort lokal lesbar. Standardmäßig werden Dateiinhalte nicht automatisch gesammelt. Der Assistent kann ausschließlich Vorschläge machen. Codeblöcke mit `codestudio-file path="relativer/pfad"` dienen der Diff-Vorschau; erst die bewusste Übernahme ändert Dateien. Terminalbefehle werden niemals aus einer KI-Antwort automatisch gestartet.

## Geprüfte offizielle Dokumentation (5. November 2026)

- [OpenAI Responses und SSE](https://developers.openai.com/api/docs/guides/streaming-responses), [Modellliste](https://developers.openai.com/api/reference/resources/models/methods/list).
- [xAI Chat Completions](https://docs.x.ai/developers/rest-api-reference/inference/chat-completions).
- [Claude Messages](https://platform.claude.com/docs/en/api/messages), [Modelle](https://platform.claude.com/docs/en/api/models/list), [API-Versionen](https://platform.claude.com/docs/en/api/versioning).
- [Gemini Inhaltsgenerierung](https://aistudio.google.com/api-reference/generate-content), [Modellliste](https://aistudio.google.com/api-reference/models).
- [Meta: Ist Llama auf Model API verfügbar?](https://dev.meta.ai/help/about-model-api/llama-and-model-api).
- [Groq OpenAI-Kompatibilität und Basisadresse](https://console.groq.com/docs/openai), [Together AI Kompatibilität](https://docs.together.ai/docs/inference/openai-compatibility).
- [Electron safeStorage: asynchrone Verschlüsselung](https://www.electronjs.org/docs/latest/api/safe-storage).

## Prüfgrenzen

Die automatisierten Providertests verwenden **simulierte HTTP-Antworten** und prüfen Anfrageformate, Authentifizierungsheader, zerteilte SSE-Daten, Abbruch/Fehler, Kontextgrenzen und Schlüsseltrennung. Der Schlüsselspeicher wird in diesen Unit-Tests mit einem ausdrücklich simulierten Protector geprüft; das ist kein Nachweis der Windows-Verschlüsselung. Tatsächliche Windows-/Installerprüfungen stehen im übergeordneten Prüfbericht. Ohne vom Benutzer bereitgestellte Zugangsdaten wurden keine erfolgreichen Live-Anfragen bei OpenAI, xAI, Claude, Gemini, Groq oder Together AI behauptet.
