import {stat,readFile} from 'node:fs/promises';
import path from 'node:path';
const pkg=JSON.parse(await readFile(new URL('../package.json',import.meta.url),'utf8'));
const output=path.resolve(process.argv[2]||pkg.build?.directories?.output||'release');
const root=path.join(output,'win-unpacked/resources');
for(const item of [
  'app.asar',
  'app.asar.unpacked/node_modules/node-pty/prebuilds/win32-x64/conpty.node',
  'compiler/typescript/lib/tsc.js',
  'compiler/typescript/package.json',
  'compiler/node_modules/@typescript/typescript-win32-x64/package.json',
  'compiler/node_modules/@typescript/typescript-win32-x64/lib/tsc.exe',
  'compiler/node_modules/@typescript/typescript-win32-x64/lib/lib.d.ts',
  'compiler/node_modules/@typescript/typescript-win32-x64/lib/lib.es2022.d.ts',
  'compiler/node_modules/@typescript/typescript-win32-x64/lib/lib.dom.d.ts',
]) {
  const file=path.join(root,item);
  if(!(await stat(file)).isFile())throw new Error(`Paketressource fehlt: ${item}`);
}
const setup=await stat(path.join(output,`CodeStudio-Setup-${pkg.version}-x64.exe`));
if(setup.size<30_000_000)throw new Error('Die Setup-Datei ist unerwartet klein.');
console.log('Windows-Paket geprüft: PTY, vollständiger TypeScript-Compiler samt Bibliotheken und Setup vorhanden.');
