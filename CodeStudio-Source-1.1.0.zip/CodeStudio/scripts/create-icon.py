"""Regenerate the committed product icon; optional Pillow development tool."""
from pathlib import Path
from PIL import Image, ImageDraw

image = Image.new('RGBA', (256, 256), (0, 0, 0, 0))
draw = ImageDraw.Draw(image)
draw.rounded_rectangle((8, 8, 248, 248), radius=52, fill='#20262d', outline='#647f9b', width=6)
draw.line([(92, 82), (48, 128), (92, 174)], fill='#bed1e5', width=13, joint='curve')
draw.line([(164, 82), (208, 128), (164, 174)], fill='#bed1e5', width=13, joint='curve')
draw.line([(144, 64), (112, 192)], fill='#92b0ce', width=11)
target = Path(__file__).resolve().parent.parent / 'build'
target.mkdir(exist_ok=True)
image.save(target / 'icon.png')
image.save(target / 'icon.ico', sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
