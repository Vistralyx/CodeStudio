"""Bundle only release source and documented evidence, never profiles or caches."""
from pathlib import Path
import hashlib
import json
import zipfile
import sys

root = Path(__file__).resolve().parent.parent
package = json.loads((root / 'package.json').read_text(encoding='utf-8-sig'))
version = package['version']
release = root / (sys.argv[1] if len(sys.argv) > 1 else package.get('build', {}).get('directories', {}).get('output', 'release'))
release.mkdir(exist_ok=True)
target = release / f'CodeStudio-Source-{version}.zip'
files = [root / name for name in ['package.json', 'package-lock.json', 'tsconfig.json', 'vite.config.ts', 'index.html', '.gitignore', 'README.md', 'LICENSE', 'THIRD_PARTY_NOTICES.txt']]
for directory in ['src', 'electron', 'scripts', 'tests', 'build', 'examples', 'docs']:
    files.extend(p for p in (root / directory).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for file in sorted(files):
        archive.write(file, 'CodeStudio/' + file.relative_to(root).as_posix())
    archive.write(release / 'Quick-Start.txt', 'CodeStudio/Quick-Start.txt')
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
    assert 'CodeStudio/package-lock.json' in archive.namelist()
    assert not any('/node_modules/' in p or '/.qa/' in p or '/.build-tools/' in p for p in archive.namelist())

artifacts = [release / f'CodeStudio-Setup-{version}-x64.exe', target, release / 'Quick-Start.txt', release / 'Test-Report.md']
lines = []
for file in artifacts:
    digest = hashlib.sha256(file.read_bytes()).hexdigest()
    lines.append(f'{digest}  {file.name}')
(release / 'SHA256SUMS.txt').write_text('\n'.join(lines) + '\n', encoding='utf-8')
print(f'Quellcodearchiv geprüft: {target} ({target.stat().st_size} Bytes)')
