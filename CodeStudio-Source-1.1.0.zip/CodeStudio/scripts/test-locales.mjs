import {_electron as electron} from 'playwright';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import {fileURLToPath} from 'node:url';

// All windows use an isolated disposable profile and remain hidden. Keyboard
// events travel only over this app's CDP connection. No clipboard/native UI use.
const projectDir=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const executable=process.env.CODESTUDIO_EXE?path.resolve(process.env.CODESTUDIO_EXE):path.join(projectDir,'release','win-unpacked','CodeStudio.exe');
const runDir=path.join(projectDir,'.qa',`locales-${Date.now()}`);
await fs.mkdir(runDir,{recursive:true});
const report={startedAt:new Date().toISOString(),application:executable,os:os.version(),uiAutomation:'Hidden isolated Electron profiles, browser CDP only; no OS focus, screen automation or clipboard access.',results:[],rendererErrors:[],screenshots:[],limits:['External OS/compiler/API messages without catalogue entries remain in their original language.','A manual close and new launch verifies saved-language persistence. If relaunch is intercepted for a restart-guard test, the report identifies that simulation.']};
let app,page,phase='setup';
const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
async function test(name,fn){
  phase=name;const start=Date.now();
  try{const detail=await fn();report.results.push({name,status:'passed',durationMs:Date.now()-start,...(detail?{detail}:{})});console.log('PASS '+name)}
  catch(error){report.results.push({name,status:'failed',error:error.stack||error.message});console.error('FAIL '+name+': '+error.message);throw error}
}
function invoke(command,args={}){return page.evaluate(({command,args})=>window.studio.invoke(command,args),{command,args})}
async function launch(profile){
  phase='launch';const env={...process.env,CODESTUDIO_TEST_DATA:profile,CODESTUDIO_BACKGROUND_TEST:'1'};delete env.ELECTRON_RUN_AS_NODE;delete env.CODESTUDIO_DEV;
  app=await electron.launch({executablePath:executable,args:[],env,timeout:45000});page=await app.firstWindow({timeout:30000});
  await app.evaluate(({BrowserWindow})=>{for(const window of BrowserWindow.getAllWindows()){window.show=()=>{};window.showInactive=()=>{};window.focus=()=>{};window.hide()}});
  const cdp=await page.context().newCDPSession(page);await cdp.send('Emulation.setFocusEmulationEnabled',{enabled:true});
  page.setDefaultTimeout(12000);page.on('pageerror',error=>report.rendererErrors.push({phase,message:error.message,stack:error.stack}));
  await page.waitForFunction(()=>document.querySelector('.app')||document.querySelector('.workbench'),{timeout:45000});
  assert.match(page.url(),/^file:\/\//);assert.equal(await app.evaluate(({BrowserWindow})=>BrowserWindow.getAllWindows().some(window=>window.isVisible())),false);
}
async function close(){
  if(!app)return;
  try{await invoke('app.close')}catch{}
  await app.close().catch(()=>{});app=undefined;page=undefined;
}
async function menu(action){await app.evaluate(({BrowserWindow},action)=>BrowserWindow.getAllWindows()[0].webContents.send('menu.action',action),action)}
const expectations={
  en:{file:'File',settings:'Settings',find:'Find',replace:'Replace',welcome:'Open project'},
  de:{file:'Datei',settings:'Einstellungen',find:'Suchen',replace:'Ersetzen',welcome:'Projekt öffnen'},
  es:{file:'Archivo',settings:'Configuración',find:'Buscar',replace:'Reemplazar',welcome:'Abrir proyecto'},
  fr:{file:'Fichier',settings:'Paramètres',find:'Rechercher',replace:'Remplacer',welcome:'Ouvrir un projet'},
  it:{file:'File',settings:'Impostazioni',find:'Trova',replace:'Sostituisci',welcome:'Apri progetto'},
};
async function inspectLanguage(language){
  const expected=expectations[language],bootstrap=await invoke('app.bootstrap');
  assert.equal(bootstrap.settings.language,language);assert.equal(await page.locator('html').getAttribute('lang'),language);
  const nls=await page.evaluate(()=>({language:globalThis._VSCODE_NLS_LANGUAGE,messages:Array.isArray(globalThis._VSCODE_NLS_MESSAGES),find:globalThis._VSCODE_NLS_MESSAGES?.[1019]}));
  if(language==='en')assert.deepEqual(nls,{language:undefined,messages:false,find:undefined});
  else assert.deepEqual(nls,{language,messages:true,find:expected.find});
  const mainMenu=page.locator('.menubar button').first();
  // The menu structure is stable while visible labels are language-specific.
  if(await mainMenu.count())assert.equal((await mainMenu.innerText()).trim(),expected.file);
  await menu('new');await page.locator('.editor-host .view-lines .view-line').first().waitFor();await menu('find');
  const input=page.locator('.find-widget .find-part :is(input,textarea)').first();await input.waitFor();assert.equal(await input.getAttribute('placeholder'),expected.find);
  // The placeholder is captured by Monaco's module initialization. This catches
  // loading NLS after App/Monaco, even when its global language later looks right.
  await page.keyboard.press('Escape');await menu('settings');await page.locator('.settings').waitFor();
  const heading=(await page.locator('.settings > header h2').innerText()).trim();assert.equal(heading,expected.settings);
  const select=page.getByTestId('language-select');await select.waitFor();assert.equal(await select.inputValue(),language);
  assert.deepEqual(await select.locator('option').evaluateAll(options=>options.map(option=>({value:option.value,label:option.textContent?.trim()}))),[{value:'en',label:'English'},{value:'de',label:'Deutsch'},{value:'es',label:'Español'},{value:'fr',label:'Français'},{value:'it',label:'Italiano'}]);
  try{
    const image=await app.evaluate(async({BrowserWindow})=>(await BrowserWindow.getAllWindows()[0].webContents.capturePage(undefined,{stayHidden:true,stayAwake:true})).toPNG().toString('base64'));
    const name=`locale-${language}-${bootstrap.settings.theme}.png`;await fs.writeFile(path.join(projectDir,'.qa',name),Buffer.from(image,'base64'));if(!report.screenshots.includes(name))report.screenshots.push(name);
  }catch(error){(report.captureNotes??=[]).push(error.message)}
  return {language,htmlLanguage:language,monacoFind:expected.find,settingsHeading:heading};
}

try{
  await test('A fresh profile starts in English',async()=>{
    const profile=path.join(runDir,'fresh');await fs.mkdir(profile);await launch(profile);const detail=await inspectLanguage('en');await close();return detail;
  });
  for(const language of ['de','es','fr','it','en']){
    await test(`Saved ${language} UI and Monaco locale load before the first editor`,async()=>{
      const profile=path.join(runDir,language);await fs.mkdir(profile);await fs.writeFile(path.join(profile,'settings.json'),JSON.stringify({language,theme:'light',fontSize:17,sidebarWidth:330,panelHeight:250}));
      await launch(profile);const detail=await inspectLanguage(language);const settings=(await invoke('app.bootstrap')).settings;assert.equal(settings.theme,'light');assert.equal(settings.fontSize,17);
      await close();await launch(profile);assert.equal((await invoke('app.bootstrap')).settings.language,language);assert.equal(await page.locator('html').getAttribute('lang'),language);await close();return {...detail,persistedAcrossProcessRestart:true};
    });
  }
  await test('Unknown persisted locale falls back to English without losing other preferences',async()=>{
    const profile=path.join(runDir,'invalid');await fs.mkdir(profile);await fs.writeFile(path.join(profile,'settings.json'),JSON.stringify({language:'unsupported',theme:'light',fontSize:20}));
    await launch(profile);assert.equal((await invoke('app.bootstrap')).settings.language,'en');assert.equal((await invoke('app.bootstrap')).settings.fontSize,20);assert.equal(await page.locator('html').getAttribute('lang'),'en');await close();
  });
  await test('Settings language change protects a dirty draft and applies only after explicit restart',async()=>{
    const profile=path.join(runDir,'restart-guard'),marker=path.join(runDir,'relaunch-request.json');await fs.mkdir(profile);await launch(profile);
    await app.evaluate(({app,dialog},marker)=>{
      const original=dialog.showMessageBox;globalThis.__qaLanguageDialog={original,response:2,calls:[]};
      dialog.showMessageBox=async(...args)=>{const state=globalThis.__qaLanguageDialog,options=args.at(-1);state.calls.push({title:options.title,buttons:options.buttons});return {response:state.response,checkboxChecked:false}};
      // Observe the real restart command without leaving a detached process.
      app.relaunch=()=>process.getBuiltinModule('fs').writeFileSync(marker,JSON.stringify({requested:true}));
    },marker);
    await menu('new');await page.locator('.editor-host .view-lines').first().click({position:{x:30,y:10}});await page.keyboard.type('CS_LANGUAGE_UNSAVED_DRAFT',{delay:10});await page.locator('.dirty-dot').waitFor();
    await menu('settings');const select=page.getByTestId('language-select'),apply=page.getByTestId('language-apply');await select.selectOption('fr');
    assert.equal((await invoke('app.bootstrap')).settings.language,'en');assert.equal(await page.locator('html').getAttribute('lang'),'en');
    await apply.click();await page.waitForFunction(()=>!document.querySelector('[data-testid="language-apply"]')?.disabled);assert.equal((await invoke('app.bootstrap')).settings.language,'en');
    assert.equal(await fs.stat(marker).then(()=>true).catch(()=>false),false);assert.equal(await page.locator('.dirty-dot').count(),1);
    const calls=await app.evaluate(()=>globalThis.__qaLanguageDialog.calls);assert.equal(calls.length,1);assert.deepEqual(calls[0].buttons,['Save','Discard','Cancel']);
    const savedBefore=await fs.readFile(path.join(profile,'settings.json'),'utf8').then(JSON.parse).catch(()=>null);if(savedBefore)assert.equal(savedBefore.language,'en');
    await app.evaluate(()=>{globalThis.__qaLanguageDialog.response=1});const closed=page.waitForEvent('close');await apply.click().catch(()=>{});await closed;
    assert.deepEqual(JSON.parse(await fs.readFile(marker,'utf8')),{requested:true});await app.close().catch(()=>{});app=undefined;page=undefined;
    const saved=JSON.parse(await fs.readFile(path.join(profile,'settings.json'),'utf8'));assert.equal(saved.language,'fr');await launch(profile);await inspectLanguage('fr');await close();
    return {dirtyDraftCancellation:true,explicitApply:true,persistedLanguage:'fr',newProcessLocale:'fr',simulation:'Native dialog responses Cancel/Discard and app.relaunch call were intercepted. The persisted profile was then opened in a real new hidden process.'};
  });
  await test('No renderer errors during the hidden language matrix',async()=>assert.deepEqual(report.rendererErrors,[]));
}catch(error){report.error=error.stack||error.message}
finally{
  await close();report.finishedAt=new Date().toISOString();report.counts={passed:report.results.filter(result=>result.status==='passed').length,failed:report.results.filter(result=>result.status==='failed').length};
  await fs.writeFile(path.join(projectDir,'.qa','locale-results.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report.counts));process.exitCode=report.counts.failed?1:0;
}
