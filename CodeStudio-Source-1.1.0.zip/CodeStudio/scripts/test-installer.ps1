param([string]$Setup)
$ErrorActionPreference = 'Stop'
$projectRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$packageConfig = Get-Content -LiteralPath (Join-Path $projectRoot 'package.json') -Raw | ConvertFrom-Json
if (!$Setup) { $Setup = Join-Path (Join-Path $projectRoot $packageConfig.build.directories.output) ('CodeStudio-Setup-' + $packageConfig.version + '-x64.exe') }
$existingInstallation = Get-ChildItem 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall' -ErrorAction SilentlyContinue | Where-Object { (Get-ItemProperty -LiteralPath $_.PSPath -ErrorAction SilentlyContinue).DisplayName -like 'CodeStudio*' } | Select-Object -First 1
if ($existingInstallation) { throw 'Eine CodeStudio-Installation ist bereits vorhanden. Dieser Installationstest würde sie verändern. Bitte ein separates Windows-Testkonto ohne CodeStudio verwenden.' }
$testRoot = Join-Path $projectRoot ('.qa\installer-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
$installDir = Join-Path $testRoot 'Installierter Editor ÄÖÜ'
$profileDir = Join-Path $testRoot 'Benutzerprofil'
$fixtureDir = Join-Path $testRoot 'Eigenes Projekt ÄÖÜ'
New-Item -ItemType Directory -Path $testRoot,$profileDir,$fixtureDir -Force | Out-Null
Set-Content -LiteralPath (Join-Path $fixtureDir 'erhalten.txt') -Value 'Projekt muss nach Deinstallation erhalten bleiben.' -Encoding utf8
$report = [ordered]@{date=(Get-Date -Format o);windows=[Environment]::OSVersion.VersionString;setup=[IO.Path]::GetFullPath($Setup);installDir=$installDir;results=@()}
function Add-Check([string]$name, [bool]$passed, [string]$detail) {
  $script:report.results += [ordered]@{name=$name;status=$(if($passed){'passed'}else{'failed'});detail=$detail}
  Write-Output ("$name : $passed")
  if (!$passed) { $script:report | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath (Join-Path $projectRoot '.qa\installer-results.json') -Encoding utf8; throw $detail }
}
$setupProcess = Start-Process -FilePath $Setup -ArgumentList @('/S','/currentuser',('/D=' + $installDir)) -WindowStyle Hidden -PassThru -Wait
Add-Check 'NSIS-Installation mit eigenem Verzeichnis und Umlauten' ($setupProcess.ExitCode -eq 0 -and (Test-Path -LiteralPath (Join-Path $installDir 'CodeStudio.exe'))) ('Installer-Exitcode: ' + $setupProcess.ExitCode)
$shortcut = Join-Path ([Environment]::GetFolderPath('StartMenu')) 'Programs\CodeStudio.lnk'
if (!(Test-Path -LiteralPath $shortcut)) { $shortcut = Join-Path ([Environment]::GetFolderPath('StartMenu')) 'Programs\CodeStudio\CodeStudio.lnk' }
$wsh = New-Object -ComObject WScript.Shell
$target = if (Test-Path -LiteralPath $shortcut) { $wsh.CreateShortcut($shortcut).TargetPath } else { '' }
Add-Check 'Startmenueintrag zeigt auf installierte Anwendung' ($target -eq (Join-Path $installDir 'CodeStudio.exe')) $target
$uninstallKey = Get-ChildItem 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall' | Where-Object { (Get-ItemProperty -LiteralPath $_.PSPath -ErrorAction SilentlyContinue).DisplayName -like 'CodeStudio*' } | Select-Object -First 1
Add-Check 'Regulaerer Deinstallationseintrag vorhanden' ([bool]$uninstallKey) ([string]$uninstallKey)
$originalPath = $env:PATH
$originalProfile = $env:CODESTUDIO_TEST_DATA
try {
  $env:PATH = "$env:SystemRoot\system32;$env:SystemRoot;$env:SystemRoot\System32\WindowsPowerShell\v1.0"
  $env:CODESTUDIO_TEST_DATA = $profileDir
  Start-Process -FilePath $shortcut -WindowStyle Hidden | Out-Null
  $deadline = (Get-Date).AddSeconds(35)
  do {
    Start-Sleep -Milliseconds 300
    $editorProcess = Get-Process -Name CodeStudio -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq (Join-Path $installDir 'CodeStudio.exe') -and $_.MainWindowHandle -ne 0 } | Select-Object -First 1
  } while (!$editorProcess -and (Get-Date) -lt $deadline)
  Add-Check 'Start ueber Startmenueintrag mit bereinigtem PATH ohne Node oder Entwicklungsserver' ([bool]$editorProcess) ('Fenstertitel: ' + $editorProcess.MainWindowTitle + '; PATH: ' + $env:PATH)
  # WM_CLOSE uses the app's regular close path; no test files are open or dirty.
  if ($editorProcess) { $null = $editorProcess.CloseMainWindow(); $editorProcess.WaitForExit(15000) | Out-Null }
} finally { $env:PATH = $originalPath; $env:CODESTUDIO_TEST_DATA = $originalProfile }
$uninstaller = Join-Path $installDir 'Uninstall CodeStudio.exe'
Add-Check 'Deinstallationsprogramm vorhanden' (Test-Path -LiteralPath $uninstaller) $uninstaller
$uninstallProcess = Start-Process -FilePath $uninstaller -ArgumentList @('/S','/currentuser') -WindowStyle Hidden -PassThru -Wait
$deadline = (Get-Date).AddSeconds(30)
while ((Test-Path -LiteralPath (Join-Path $installDir 'CodeStudio.exe')) -and (Get-Date) -lt $deadline) { Start-Sleep -Milliseconds 300 }
Add-Check 'Deinstallation entfernt App und Startmenueintrag' (!(Test-Path -LiteralPath (Join-Path $installDir 'CodeStudio.exe')) -and !(Test-Path -LiteralPath $shortcut)) ('Deinstaller-Exitcode: ' + $uninstallProcess.ExitCode)
Add-Check 'Eigene Projektdatei nach Deinstallation erhalten' ((Get-Content -LiteralPath (Join-Path $fixtureDir 'erhalten.txt') -Raw).Contains('Projekt muss')) $fixtureDir
$report.signature = (Get-AuthenticodeSignature -LiteralPath $Setup).Status.ToString()
$report.sha256 = (Get-FileHash -LiteralPath $Setup -Algorithm SHA256).Hash
$report.limits = @('Gleiches Windows-11-System mit bereinigtem PATH; kein zweiter frischer Testrechner und kein Windows-10-Test.','Unbeaufsichtigte NSIS-Installation; Interaktion mit dem Installationsassistenten ist damit nicht separat abgenommen.')
$report | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath (Join-Path $projectRoot '.qa\installer-results.json') -Encoding utf8
Write-Output ('Pruefbericht: ' + (Join-Path $projectRoot '.qa\installer-results.json'))

