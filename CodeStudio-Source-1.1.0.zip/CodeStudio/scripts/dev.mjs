import {spawn} from 'node:child_process';
import {build} from 'esbuild';
import {createServer} from 'vite';
await import('./build-main.mjs');
const server=await createServer(); await server.listen();
const electron=spawn((await import('electron')).default,['.'],{stdio:'inherit',env:{...process.env,CODESTUDIO_DEV:'1'}});
electron.on('exit',async code=>{await server.close();process.exit(code??0)});
