import { _electron as electron } from 'playwright';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import http from 'node:http';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';

// Exercises the built desktop app, never a development server. Test credentials
// below are generated inert strings. No provider/model/test/chat request is sent.
const require=createRequire(import.meta.url);
const projectDir=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const expectedVersion=JSON.parse(await fs.readFile(path.join(projectDir,'package.json'),'utf8')).version;
const qaDir=path.join(projectDir,'.qa');
const runDir=path.join(qaDir,`integration-${Date.now()}`);
const fixture=path.join(runDir,'Projekt mit Leerzeichen und Umlauten ÄÖÜ');
const profile=path.join(runDir,'profile');
await fs.mkdir(fixture,{recursive:true});await fs.mkdir(profile);
await fs.writeFile(path.join(profile,'settings.json'),JSON.stringify({language:'de',recentProjects:[fixture],lastProject:null,theme:'dark'}));
const report={startedAt:new Date().toISOString(),platform:{platform:process.platform,arch:process.arch,release:os.release(),version:os.version()},application:process.env.CODESTUDIO_EXE?path.resolve(process.env.CODESTUDIO_EXE):'development Electron binary, production-built app resources',results:[],screenshots:[],limits:['Keine echten API-Zugangsdaten vorhanden; externe KI-Verbindungen und Live-Chat werden nicht getestet.','Kein separates Windows-10- oder sauberes System ohne Entwicklungswerkzeuge in diesem Integrationstest.','Native Installationsdialoge, Startmenü und Deinstallation werden separat geprüft.']};
report.uiAutomation='Verstecktes eigenes Testfenster, ausschließlich Browser-CDP; keine native Bildschirm- oder globale Tastatur-/Zwischenablagensteuerung.';
report.expectedVersion=expectedVersion;report.primaryFixtureLanguage='de';
let app,page,failedTest=false,currentPhase='startup';const terminalIds=new Set();const errors=[];
const env={...process.env,CODESTUDIO_TEST_DATA:profile,CODESTUDIO_BACKGROUND_TEST:'1',OPENAI_API_KEY:'CODESTUDIO-INERT-ENV-SENTINEL-NOT-A-KEY'};
delete env.ELECTRON_RUN_AS_NODE;delete env.CODESTUDIO_DEV;
const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
async function waitFile(file,predicate,timeout=10000){const start=Date.now();let value='';while(Date.now()-start<timeout){try{value=await fs.readFile(file,'utf8');if(predicate(value))return value;}catch{}await delay(50);}throw new Error(`Datei wurde nicht rechtzeitig aktualisiert: ${path.basename(file)}: ${value.slice(-300)}`);}
const stripVT=value=>value.replace(/\x1b\][^\x07]*(?:\x07|\x1b\\)/g,'').replace(/\x1b\[(\d*)C/g,(_,n)=>' '.repeat(Math.min(500,Number(n)||1))).replace(/\x1b\[[0-?]*[ -/]*[@-~]/g,'').replace(/\r/g,'');
async function capture(name){
  try{
    const png=await Promise.race([app.evaluate(async({BrowserWindow})=>{const window=BrowserWindow.getAllWindows()[0];if(!window)throw new Error('Testfenster nicht verfügbar.');const image=await window.webContents.capturePage(undefined,{stayHidden:true,stayAwake:true});if(image.isEmpty())throw new Error('Versteckte Aufnahme ist leer.');return image.toPNG().toString('base64');}),delay(5000).then(()=>{throw new Error('Versteckte Aufnahme nach 5 Sekunden nicht verfügbar.');})]);
    await fs.writeFile(path.join(qaDir,name),Buffer.from(png,'base64'));report.screenshots.push('.qa/'+name);return true;
  }catch(error){(report.captureNotes??=[]).push({name,message:error.message});return false;}
}
const invoke=(command,args={})=>page.evaluate(({command,args})=>window.studio.invoke(command,args),{command,args});
async function rejects(command,args,pattern){let message='';try{await invoke(command,args);}catch(error){message=error.message;}assert.match(message,pattern);return message;}
async function test(name,fn){currentPhase=name;const start=Date.now();try{const detail=await fn();report.results.push({name,status:'passed',durationMs:Date.now()-start,...(detail?{detail}:{} )});console.log(`PASS ${name}`);}catch(error){failedTest=true;report.results.push({name,status:'failed',durationMs:Date.now()-start,error:error.message});console.error(`FAIL ${name}: ${error.message}`);if(page){try{await capture(`failure-${report.results.length}.png`);console.error((await page.locator('.editor-host').innerText()).slice(-1000));}catch{}}throw error;}}
function skip(name,reason){report.results.push({name,status:'skipped',reason});console.log(`SKIP ${name}: ${reason}`);}
async function launch(){
  currentPhase='desktop launch';
  app=await electron.launch({executablePath:process.env.CODESTUDIO_EXE?path.resolve(process.env.CODESTUDIO_EXE):require('electron'),args:process.env.CODESTUDIO_EXE?[]:[projectDir],env,timeout:45000});
  page=await app.firstWindow({timeout:30000});
  await app.evaluate(({BrowserWindow})=>{for(const window of BrowserWindow.getAllWindows()){window.show=()=>{};window.showInactive=()=>{};window.focus=()=>{};window.hide();}});
  const browserSession=await page.context().newCDPSession(page);await browserSession.send('Emulation.setFocusEmulationEnabled',{enabled:true});
  page.setDefaultTimeout(10000);
  page.on('pageerror',error=>{const item={message:error.message,stack:error.stack,phase:currentPhase,time:new Date().toISOString()};errors.push(item);console.error('RENDERER_ERROR '+JSON.stringify(item));});
  await page.waitForFunction(()=>!!window.studio,{timeout:30000});
  await page.waitForFunction(()=>document.querySelector('#root')?.childElementCount>0,{timeout:30000});
  await page.evaluate(()=>{
    window.__qa={terminal:[],exits:[],runs:[],previews:[]};
    for(const [event,target] of [['terminal.data','terminal'],['terminal.exit','exits'],['run.exit','runs'],['preview.updated','previews']])window.studio.on(event,data=>window.__qa[target].push(data));
  });
}
async function close(){
  if(!app)return;
  currentPhase='desktop close';
  try{await invoke('run.stop');}catch{}
  for(const id of terminalIds)try{await invoke('terminal.close',{id});}catch{}
  terminalIds.clear();
  try{await invoke('preview.close');}catch{}
  try{await invoke('app.close');}catch{}
  try{await app.close();}catch{}
  app=undefined;page=undefined;
}
async function waitBuffer(id,predicate,timeout=30000){
  const start=Date.now();let last={data:''};
  while(Date.now()-start<timeout){last=await invoke('terminal.buffer',{id});if(predicate(last))return {...last,text:stripVT(last.data)};await delay(120);}
  throw new Error(`Terminal condition timed out: ${stripVT(last.data).slice(-1500)}`);
}
async function dialogAnswers(responses){
  await app.evaluate(({dialog},responses)=>{
    if(!globalThis.__qaNativeDialog){const original=dialog.showMessageBox;globalThis.__qaNativeDialog={original,responses:[],calls:[]};dialog.showMessageBox=async(...args)=>{const state=globalThis.__qaNativeDialog,options=args.at(-1);state.calls.push({title:options.title,message:options.message,buttons:options.buttons});return {response:state.responses.shift()??2,checkboxChecked:false};};}
    globalThis.__qaNativeDialog.responses=responses;
  },responses);
}
async function restoreDialogs(){await app.evaluate(({dialog})=>{if(globalThis.__qaNativeDialog){dialog.showMessageBox=globalThis.__qaNativeDialog.original;delete globalThis.__qaNativeDialog;}});}
async function appendInEditor(content){await page.locator('.editor-host .view-lines').first().click({position:{x:30,y:10}});await page.keyboard.press('Control+End');await page.keyboard.press('Enter');await page.keyboard.type(content,{delay:10});await page.locator('.dirty-dot').waitFor();}
async function runFile(name,content,expected,args='',timeout=45000){
  const target=path.join(fixture,name);await fs.writeFile(target,content,'utf8');
  const session=await invoke('run.start',{path:target,args});terminalIds.add(session.id);
  const result=await waitBuffer(session.id,value=>value.exitCode!==undefined,timeout);
  assert.equal(result.exitCode,0,result.text);assert.match(result.text,expected);return {exitCode:result.exitCode,output:result.text.slice(-1800)};
}
function requestRaw(url,requestPath){return new Promise((resolve,reject)=>{const address=new URL(url);const request=http.request({hostname:address.hostname,port:address.port,path:requestPath,method:'GET'},response=>{let body='';response.setEncoding('utf8');response.on('data',chunk=>body+=chunk);response.on('end',()=>resolve({status:response.statusCode,body}));});request.on('error',reject);request.end();});}
async function focusedLifecycle(){
  await test('Focused: Projekt und synthetischen Offline-Verlauf öffnen',async()=>{
    await invoke('project.open',{path:fixture});const target=path.join(fixture,'vorschlag-ui.ts');await fs.writeFile(target,'export const wert = 1;\n');const original=await invoke('fs.read',{path:target});
    await invoke('ai.historySave',{root:fixture,messages:[{role:'assistant',id:'synthetic-offline-ui-proposal',state:'complete',contextSnapshot:[{path:target,hash:original.hash}],content:'Explizit synthetischer Offline-Test.\n\n```codestudio-file path="vorschlag-ui.ts"\nexport const wert = 2;\n```'}]});
    await page.locator('.recent').filter({hasText:'Projekt mit Leerzeichen und Umlauten ÄÖÜ'}).click();
  });
  await test('Focused: Diff öffnen, übernehmen und durch Rückgängig schließen',async()=>{
    await page.getByRole('button',{name:'KI-Assistent',exact:true}).click();await page.getByRole('button',{name:'Änderungsvorschläge prüfen',exact:true}).click();await page.locator('.diff-dialog .monaco-diff-editor').waitFor();await delay(300);
    await page.getByRole('button',{name:'Einzeln übernehmen',exact:true}).click();await page.waitForFunction(()=>[...document.querySelectorAll('.diff-dialog button')].find(button=>button.textContent.trim()==='Einzeln übernehmen')?.disabled===true);
    await page.getByRole('button',{name:'Änderungen rückgängig',exact:true}).click();await page.locator('.diff-dialog').waitFor({state:'hidden'});await delay(1000);if(await page.getByRole('button',{name:'Meldung schließen',exact:true}).count())await page.getByRole('button',{name:'Meldung schließen',exact:true}).click();
  });
  await test('Focused: YAML-Diagnose öffnen und Modell schließen',async()=>{
    await page.getByRole('button',{name:'Explorer',exact:true}).click();await fs.writeFile(path.join(fixture,'ungueltig.yaml'),'liste: [1, 2\n');await page.getByRole('treeitem',{name:'ungueltig.yaml',exact:true}).click();await page.locator('.panel-tabs button').filter({hasText:'PROBLEME'}).click();await page.locator('.problems button').filter({hasText:'ungueltig.yaml'}).first().waitFor();await page.getByRole('button',{name:'Datei schließen ungueltig.yaml',exact:true}).click();await page.locator('.problems button').filter({hasText:'ungueltig.yaml'}).waitFor({state:'hidden'});await delay(1000);
  });
  await test('Focused: Kontextdienste bleiben ohne asynchronen Rendererfehler',async()=>{await delay(1000);await capture('focused-lifecycle.png');assert.deepEqual(errors,[]);});
}
async function focusedLocalization(){
  report.previousFullSuite='.qa/integration-packaged-results.json';
  report.scope='Gezielte Prüfung nach der letzten Änderung: offizielles deutsches Monaco-Sprachpaket vor dem Editorimport. Der zuvor erfolgreiche vollständige Testbericht bleibt erhalten.';
  await test('Deutscher Editor startet verborgen und zeigt lokalisierte Suchsteuerung',async()=>{
    await invoke('project.open',{path:fixture});await fs.writeFile(path.join(fixture,'sprache.ts'),'export const wert = 1;\n');
    const target=path.join(fixture,'vorschlag-ui.ts');await fs.writeFile(target,'export const wert = 1;\n');const original=await invoke('fs.read',{path:target});
    await invoke('ai.historySave',{root:fixture,messages:[{role:'assistant',id:'synthetic-localization-regression',state:'complete',contextSnapshot:[{path:target,hash:original.hash}],content:'Explizit synthetischer Offline-Test.\n\n```codestudio-file path="vorschlag-ui.ts"\nexport const wert = 2;\n```'}]});
    await page.locator('.recent').filter({hasText:'Projekt mit Leerzeichen und Umlauten ÄÖÜ'}).click();await page.getByRole('treeitem',{name:'sprache.ts',exact:true}).click();
    await page.locator('.editor-host .view-lines').first().click({position:{x:30,y:10}});await page.keyboard.press('Control+f');await page.locator('.find-widget').first().waitFor({state:'visible'});
    const labels=await page.locator('.find-widget').first().evaluate(widget=>[...widget.querySelectorAll('[aria-label],input[placeholder]')].map(element=>({aria:element.getAttribute('aria-label'),placeholder:element.getAttribute('placeholder')})));
    assert.ok(labels.some(label=>/Groß-\/Kleinschreibung beachten|Nur ganzes Wort suchen|Regulären Ausdruck verwenden/.test(label.aria||'')),JSON.stringify(labels));
    await capture('localization-german-find.png');await page.locator('.find-widget [aria-label^="Schließen"]').first().click();await page.waitForFunction(()=>document.querySelector('.find-widget')?.getAttribute('aria-hidden')==='true');return {renderedGermanLabels:labels};
  });
  await test('Nach deutscher Lokalisierung im Monaco-Editor tippen und mit Strg+S speichern',async()=>{
    await app.evaluate(({ipcMain})=>{const original=ipcMain._invokeHandlers?.get('studio:invoke');globalThis.__qaLocalizedSaves=[];if(original){ipcMain.removeHandler('studio:invoke');ipcMain.handle('studio:invoke',(event,command,args)=>{if(command==='fs.save')globalThis.__qaLocalizedSaves.push({length:args?.content?.length,hasMarker:args?.content?.includes('CS_DE_LOCALE_SAVE'),tail:args?.content?.slice(-45)});return original(event,command,args);});}});
    await page.evaluate(()=>{window.__qaLocalizedKeys=[];window.addEventListener('keydown',event=>{if(event.ctrlKey)window.__qaLocalizedKeys.push({key:event.key,code:event.code,ctrl:event.ctrlKey,focus:document.hasFocus(),target:document.activeElement?.tagName});},true);});
    await appendInEditor('// CS_DE_LOCALE_SAVE');await page.keyboard.press('Control+s');
    try{await page.locator('.dirty-dot').waitFor({state:'hidden'});}catch(error){error.message+='\nSave trace: '+JSON.stringify(await app.evaluate(()=>globalThis.__qaLocalizedSaves))+'\nKeyboard trace: '+JSON.stringify(await page.evaluate(()=>window.__qaLocalizedKeys));throw error;}
    assert.match(await waitFile(path.join(fixture,'sprache.ts'),content=>content.includes('CS_DE_LOCALE_SAVE')),/CS_DE_LOCALE_SAVE/);
    for(let round=1;round<=3;round++){const marker=`CS_DE_RAPID_SAVE_${round}`;await appendInEditor('// '+marker);await page.keyboard.press('Control+s');await page.locator('.dirty-dot').waitFor({state:'hidden'});assert.match(await waitFile(path.join(fixture,'sprache.ts'),content=>content.includes(marker)),new RegExp(marker));}
    return {immediateSaveRounds:4,saveTrace:await app.evaluate(()=>globalThis.__qaLocalizedSaves),keyTrace:await page.evaluate(()=>window.__qaLocalizedKeys)};
  });
  await test('Lokalisiertes Diff öffnen, übernehmen und rückgängig schließen',async()=>{
    if(await page.getByRole('button',{name:'Meldung schließen',exact:true}).count())await page.getByRole('button',{name:'Meldung schließen',exact:true}).click();
    await page.getByRole('button',{name:'KI-Assistent',exact:true}).click();await page.getByRole('button',{name:'Änderungsvorschläge prüfen',exact:true}).click();await page.locator('.diff-dialog .monaco-diff-editor').waitFor();
    await page.getByRole('button',{name:'Einzeln übernehmen',exact:true}).click();await page.waitForFunction(()=>[...document.querySelectorAll('.diff-dialog button')].find(button=>button.textContent.trim()==='Einzeln übernehmen')?.disabled===true);assert.equal(await waitFile(path.join(fixture,'vorschlag-ui.ts'),content=>content.includes('wert = 2')),'export const wert = 2;\n');
    await page.getByRole('button',{name:'Änderungen rückgängig',exact:true}).click();await page.locator('.diff-dialog').waitFor({state:'hidden'});assert.equal(await fs.readFile(path.join(fixture,'vorschlag-ui.ts'),'utf8'),'export const wert = 1;\n');
  });
  await test('Lokalisierter Editor bleibt nach Diff-Schließen ohne Rendererfehler',async()=>{await delay(800);assert.deepEqual(errors,[]);await capture('localization-final.png');});
}
try{
  await launch();
  report.electron=await app.evaluate(()=>({electron:process.versions.electron,chrome:process.versions.chrome,node:process.versions.node}));
  if(process.env.CODESTUDIO_FOCUS==='lifecycle')await focusedLifecycle();
  else if(process.env.CODESTUDIO_FOCUS==='localization')await focusedLocalization();
  else {
  await test('Desktop startet mit gebauten Ressourcen ohne Entwicklungsserver',async()=>{
    assert.match(page.url(),/^file:\/\//);const bootstrap=await invoke('app.bootstrap');assert.equal(bootstrap.version,expectedVersion);assert.equal(bootstrap.settings.language,'de');assert.equal(await page.title(),'CodeStudio');return {url:page.url(),version:bootstrap.version};
  });
  await test('Renderer ist isoliert; Preload erlaubt nur freigegebene Befehle',async()=>{
    const prefs=await app.evaluate(({BrowserWindow})=>BrowserWindow.getAllWindows()[0].webContents.getLastWebPreferences());
    assert.equal(prefs.contextIsolation,true);assert.equal(prefs.sandbox,true);assert.equal(prefs.nodeIntegration,false);
    const globals=await page.evaluate(()=>({require:typeof window.require,process:typeof window.process,bridge:Object.isFrozen(window.studio)}));assert.deepEqual(globals,{require:'undefined',process:'undefined',bridge:true});
    await rejects('fs.arbitrary',{path:'C:\\Windows\\System32'},/Unbekannte Aktion/);
  });
  await test('Hauptprozess weist IPC aus fremdem Fenster zurück',async()=>{
    const result=await app.evaluate(async({app,BrowserWindow})=>{
      const probe=new BrowserWindow({show:false,webPreferences:{preload:app.getAppPath()+'\\dist-electron\\preload.cjs',sandbox:true,nodeIntegration:false,contextIsolation:true}});
      try{await probe.loadURL('data:text/html,<html><body>IPC-Prüfung</body></html>');return await probe.webContents.executeJavaScript("window.studio.invoke('app.bootstrap').then(()=> 'UNEXPECTED_SUCCESS',e=>e.message)");}finally{probe.destroy();}
    });assert.match(result,/Zugriff verweigert/);
  });
  await test('Projekt mit Leerzeichen und Umlauten öffnen; unbekannte Pfade ablehnen',async()=>{
    assert.equal(await invoke('project.open',{path:fixture}),await fs.realpath(fixture));
    const outside=path.join(runDir,'außerhalb.txt');await fs.writeFile(outside,'außerhalb');
    await rejects('fs.read',{path:outside},/außerhalb/);await rejects('project.open',{path:runDir},/Dateidialog/);
  });
  await test('Projekt über die sichtbare Liste zuletzt geöffneter Projekte öffnen',async()=>{
    const target=path.join(fixture,'vorschlag-ui.ts');await fs.writeFile(target,'export const wert = 1;\n');const original=await invoke('fs.read',{path:target});
    await invoke('ai.historySave',{root:fixture,messages:[{role:'assistant',id:'synthetic-offline-ui-proposal',state:'complete',contextSnapshot:[{path:target,hash:original.hash}],content:'Synthetischer Offline-Testvorschlag, keine echte KI-Antwort.\n\n```codestudio-file path="vorschlag-ui.ts"\nexport const wert = 2;\n```'}]});
    await page.locator('.recent').filter({hasText:'Projekt mit Leerzeichen und Umlauten ÄÖÜ'}).click();
    await page.getByRole('button',{name:'Neue Projektdatei',exact:true}).waitFor();assert.equal(await invoke('project.current'),await fs.realpath(fixture));
  });
  await test('Unterordner/Dateien erstellen, bearbeiten, speichern und erneut lesen',async()=>{
    const folder=await invoke('fs.create',{parent:fixture,name:'Unterordner Ü',directory:true});const created=await invoke('fs.create',{parent:folder.path,name:'Grüße.ts'});
    const opened=await invoke('fs.read',{path:created.path});const saved=await invoke('fs.save',{path:created.path,content:'export const grüße = "Hallo";\r\n',hash:opened.hash});
    const reread=await invoke('fs.read',{path:created.path});assert.equal(reread.content,saved.content);assert.equal(reread.eol,'CRLF');
    const list=await invoke('fs.list',{path:folder.path});assert.equal(list[0].name,'Grüße.ts');
  });
  await test('Explorer aufklappen, Datei per UI erstellen, Monaco bearbeiten und mit Strg+S speichern',async()=>{
    await page.getByRole('treeitem',{name:'Unterordner Ü',exact:true}).click();await page.getByRole('treeitem',{name:'Grüße.ts',exact:true}).click();
    await page.getByRole('tab').filter({hasText:'Grüße.ts'}).waitFor();
    await page.getByRole('button',{name:'Neue Projektdatei',exact:true}).click();await page.locator('.input-dialog input').fill('ui-smoke.ts');await page.getByRole('button',{name:'Bestätigen',exact:true}).click();
    await page.getByRole('tab').filter({hasText:'ui-smoke.ts'}).waitFor();
    await page.locator('.editor-host .view-lines').first().click({position:{x:30,y:10}});await page.keyboard.type('console.log("CS_UI_SAVE_OK");',{delay:12});await page.keyboard.press('Enter');
    await page.locator('.dirty-dot').waitFor();await page.keyboard.press('Control+s');
    await waitFile(path.join(fixture,'ui-smoke.ts'),content=>content.includes('CS_UI_SAVE_OK'));
    await page.locator('.dirty-dot').waitFor({state:'hidden'});assert.match(await fs.readFile(path.join(fixture,'ui-smoke.ts'),'utf8'),/CS_UI_SAVE_OK/);
    await capture('integration-dark.png');
  });
  await test('Drei schnelle UI-Tipprunden erhalten Cursorposition und sämtliche Zeichen beim Speichern',async()=>{
    for(let round=1;round<=3;round++){
      const name=`schnell-${round}.ts`,content=`// RAPID_PASS_${round}_abcdefghijklmnopqrstuvwxyz_ABCDEFGHIJKLMNOPQRSTUVWXYZ_0123456789_ENDE`;
      await page.getByRole('button',{name:'Neue Projektdatei',exact:true}).click();await page.locator('.input-dialog input').fill(name);await page.getByRole('button',{name:'Bestätigen',exact:true}).click();await page.getByRole('tab').filter({hasText:name}).waitFor();
      await page.locator('.editor-host .view-lines').first().click({position:{x:30,y:10}});
      await page.evaluate(()=>{window.__qaKeyEvents=[];if(window.__qaKeyListener)document.removeEventListener('keydown',window.__qaKeyListener,true);window.__qaKeyListener=event=>{if(event.key.length===1&&!event.ctrlKey&&!event.altKey)window.__qaKeyEvents.push({key:event.key,focus:document.hasFocus()});};document.addEventListener('keydown',window.__qaKeyListener,true);});
      await page.keyboard.type(content);await page.keyboard.press('Enter');await page.locator('.dirty-dot').waitFor();await page.keyboard.press('Control+s');await page.locator('.dirty-dot').waitFor({state:'hidden'});
      const keys=await page.evaluate(()=>window.__qaKeyEvents);const actual=(await fs.readFile(path.join(fixture,name),'utf8')).replace(/\r\n/g,'\n');
      assert.equal(actual,content+'\n',`Zeichenverlust in Tipprunde ${round}; erwartete Tastendrücke ${content.length}, empfangen ${keys.length}, ohne Fensterfokus ${keys.filter(key=>!key.focus).length}; empfangene Zeichen ${keys.map(key=>key.key).join('')}`);
    }
    await page.getByRole('treeitem',{name:'ui-smoke.ts',exact:true}).click();return {rapidTypingRounds:3,characterLoss:false};
  });
  await test('Ungespeicherte UI-Änderungen: Schließen abbrechen und anschließend speichern (kontrollierte Dialogantworten)',async()=>{
    const target=path.join(fixture,'ui-smoke.ts');const previous=await fs.readFile(target,'utf8');
    try{
      await page.getByRole('treeitem',{name:'ui-smoke.ts',exact:true}).click();
      await appendInEditor('// CS_UNSAVED_CLOSE');await dialogAnswers([2]);await page.getByRole('button',{name:'Datei schließen ui-smoke.ts',exact:true}).click();
      await delay(150);assert.ok(await page.getByRole('tab').filter({hasText:'ui-smoke.ts'}).count());assert.equal(await fs.readFile(target,'utf8'),previous);
      const cancelled=await app.evaluate(()=>globalThis.__qaNativeDialog.calls);assert.equal(cancelled.at(-1).title,'Ungespeicherte Änderungen');assert.deepEqual(cancelled.at(-1).buttons,['Speichern','Verwerfen','Abbrechen']);
      await dialogAnswers([0]);await page.getByRole('button',{name:'Datei schließen ui-smoke.ts',exact:true}).click();await page.getByRole('tab').filter({hasText:'ui-smoke.ts'}).waitFor({state:'hidden'});assert.match(await fs.readFile(target,'utf8'),/CS_UNSAVED_CLOSE/);
      await page.getByRole('treeitem',{name:'ui-smoke.ts',exact:true}).click();await page.getByRole('tab').filter({hasText:'ui-smoke.ts'}).waitFor();
      return {nativeDialogResponses:'Simulierte Benutzerauswahl im tatsächlichen Electron-Dialogaufruf; keine visuelle native Dialogbedienung.'};
    } finally {await restoreDialogs();}
  });
  await test('Externe Änderung bei schmutzigem UI-Tab: Warnung, Überschreiben abbrechen und bewusst übernehmen (kontrollierte Dialogantworten)',async()=>{
    const target=path.join(fixture,'ui-smoke.ts');
    try{
      await appendInEditor('// CS_EDITOR_DRAFT');await fs.writeFile(target,'console.log("CS_EXTERNAL_VERSION");\n');await page.locator('.external-banner').waitFor();
      await dialogAnswers([0]);await page.keyboard.press('Control+s');await page.getByRole('alert').filter({hasText:'Speichern abgebrochen'}).waitFor();assert.match(await fs.readFile(target,'utf8'),/CS_EXTERNAL_VERSION/);await page.getByRole('button',{name:'Meldung schließen',exact:true}).click();
      await dialogAnswers([1]);await page.locator('.editor-host .view-lines').first().click({position:{x:30,y:10}});await page.keyboard.press('Control+s');await page.locator('.dirty-dot').waitFor({state:'hidden'});assert.match(await fs.readFile(target,'utf8'),/CS_EDITOR_DRAFT/);
      const calls=await app.evaluate(()=>globalThis.__qaNativeDialog.calls);assert.equal(calls.length,2);assert.ok(calls.every(call=>call.title==='Externe Änderungen überschreiben?'));
      return {nativeDialogResponses:'Simulierte Antworten Abbrechen/Überschreiben; echte Dateiwächter, UI und Speicherkonfliktprüfung.'};
    } finally {await restoreDialogs();}
  });
  await test('Synthetischen Offline-Chatvorschlag als echtes Diff anzeigen, per UI übernehmen und rückgängig machen',async()=>{
    const target=path.join(fixture,'vorschlag-ui.ts');await page.getByRole('button',{name:'KI-Assistent',exact:true}).click();
    await page.getByRole('button',{name:'Änderungsvorschläge prüfen',exact:true}).click();await page.locator('.diff-dialog .monaco-diff-editor').waitFor();
    await capture('integration-diff.png');
    await page.getByRole('button',{name:'Einzeln übernehmen',exact:true}).click();await page.waitForFunction(()=>[...document.querySelectorAll('.diff-dialog button')].find(button=>button.textContent.trim()==='Einzeln übernehmen')?.disabled===true);assert.equal(await waitFile(target,content=>content.includes('wert = 2')),'export const wert = 2;\n');
    await page.getByRole('button',{name:'Änderungen rückgängig',exact:true}).click();await page.locator('.diff-dialog').waitFor({state:'hidden'});assert.equal(await fs.readFile(target,'utf8'),'export const wert = 1;\n');
    if(await page.getByRole('button',{name:'Meldung schließen',exact:true}).count())await page.getByRole('button',{name:'Meldung schließen',exact:true}).click();
    await page.getByRole('button',{name:'Explorer',exact:true}).click();return {source:'Explizit synthetischer lokaler Chatverlauf; keine API-Anfrage oder echte Modellantwort.'};
  });
  await test('Strg+P listet Dateien bereits ohne Suchtext und öffnet den gewählten Treffer',async()=>{
    await page.keyboard.press('Control+p');await page.locator('.quick-open').waitFor();await page.locator('.quick-open button').filter({hasText:'vorschlag-ui.ts'}).waitFor();
    await page.getByRole('textbox',{name:'Datei schnell öffnen',exact:true}).fill('vorschlag-ui');await page.locator('.quick-open button').filter({hasText:'vorschlag-ui.ts'}).click();await page.getByRole('tab').filter({hasText:'vorschlag-ui.ts'}).waitFor();
  });
  await test('YAML wird bereits beim Öffnen validiert; Schließen entfernt veraltete Diagnose',async()=>{
    await fs.writeFile(path.join(fixture,'ungueltig.yaml'),'liste: [1, 2\n');await page.getByRole('treeitem',{name:'ungueltig.yaml',exact:true}).click();await page.getByRole('tab').filter({hasText:'ungueltig.yaml'}).waitFor();
    await page.locator('.panel-tabs button').filter({hasText:'PROBLEME'}).click();await page.locator('.problems button').filter({hasText:'ungueltig.yaml'}).first().waitFor();
    await page.getByRole('button',{name:'Datei schließen ungueltig.yaml',exact:true}).click();await page.locator('.problems button').filter({hasText:'ungueltig.yaml'}).waitFor({state:'hidden'});
  });
  await test('Externe Änderungen verhindern stilles Überschreiben',async()=>{
    const target=path.join(fixture,'konflikt.txt');await fs.writeFile(target,'alter Stand');const opened=await invoke('fs.read',{path:target});await fs.writeFile(target,'externe Änderung');
    await rejects('fs.save',{path:target,content:'Editorentwurf',hash:opened.hash},/Dateikonflikt/);assert.equal(await fs.readFile(target,'utf8'),'externe Änderung');
  });
  await test('Projektweite Textsuche und Standardausschlüsse',async()=>{
    await fs.mkdir(path.join(fixture,'node_modules'));await fs.writeFile(path.join(fixture,'node_modules','intern.txt'),'QA_NUR_EIN_TREFFER');await fs.writeFile(path.join(fixture,'suche.txt'),'erste Zeile\nQA_NUR_EIN_TREFFER');
    const result=await invoke('fs.search',{query:'QA_NUR_EIN_TREFFER'});assert.equal(result.results.length,1);assert.equal(result.results[0].line,2);
  });
  await test('Diff-Vorschlag übernehmen, rückgängig machen und veraltete Vorschläge abweisen',async()=>{
    const target=path.join(fixture,'änderung.ts');await fs.writeFile(target,'const wert = 1;');
    const proposal=await invoke('fs.propose',{path:target,after:'const wert = 2;'});assert.equal(proposal.before,'const wert = 1;');await invoke('fs.apply',{ids:[proposal.id]});assert.equal(await fs.readFile(target,'utf8'),'const wert = 2;');await invoke('fs.undo');assert.equal(await fs.readFile(target,'utf8'),'const wert = 1;');
    const stale=await invoke('fs.propose',{path:target,after:'const wert = 3;'});await fs.writeFile(target,'const wert = 4;');await rejects('fs.apply',{ids:[stale.id]},/Dateikonflikt/);assert.equal(await fs.readFile(target,'utf8'),'const wert = 4;');
  });
  await test('KI-Kontext blockiert .env und private Schlüssel unter fremdem Namen',async()=>{
    const envFile=path.join(fixture,'.env');await fs.writeFile(envFile,'API_KEY=KEIN_ECHTER_SCHLUESSEL');await rejects('fs.context',{paths:[envFile]},/ausgeschlossen/);
    const privateFile=path.join(fixture,'notizen.txt');await fs.writeFile(privateFile,'-----BEGIN PRIVATE KEY-----\nQA_NO_REAL_KEY\n-----END PRIVATE KEY-----');await rejects('fs.context',{paths:[privateFile]},/privaten Schlüssel/);
  });
  let runtimes=[];
  await test('Laufzeiten tatsächlich erkennen und Versionen anzeigen',async()=>{
    runtimes=await invoke('runtime.list',{refresh:true});assert.ok(runtimes.some(item=>item.id==='node'));assert.ok(runtimes.every(item=>typeof item.available==='boolean'&&typeof item.version==='string'));return {runtimes};
  });
  const has=id=>runtimes.find(item=>item.id===id)?.available;
  if(has('node'))await test('JavaScript: echte Ausführung, Argumente/Umlaute und kein API-Key in Umgebung',()=>runFile('beispiel.js','console.log("CS_JS_OK",process.argv[2],process.argv[3],typeof process.env.OPENAI_API_KEY);',/CS_JS_OK mit Leerzeichen ÄÖÜ undefined/,'"mit Leerzeichen" "ÄÖÜ"'));
  else skip('JavaScript ausführen','Node.js nicht erkannt');
  if(has('node'))await test('TypeScript: mitgelieferter Compiler baut; erkannte Node-Laufzeit führt aus',()=>runFile('beispiel.ts','const wert: number = 42; console.log("CS_TS_OK",wert);',/CS_TS_OK\s*42/));
  else skip('TypeScript ausführen','Node.js nicht erkannt');
  if(has('python'))await test('Python: echtes Skript ausführen',()=>runFile('beispiel.py','print("CS_PYTHON_OK", 6 * 7)\n',/CS_PYTHON_OK 42/));
  else skip('Python ausführen','Python nicht erkannt');
  if(has('java')&&has('javac'))await test('Java: mit JDK kompilieren und starten',()=>runFile('Hallo.java','public class Hallo { public static void main(String[] args) { System.out.println("CS_JAVA_OK"); } }',/CS_JAVA_OK/));
  else skip('Java ausführen','Java-Laufzeit oder JDK-Compiler nicht erkannt');
  if(has('kotlinc')&&has('java'))await test('Kotlin: JAR kompilieren und starten',()=>runFile('Hallo.kt','fun main() { println("CS_KOTLIN_OK") }',/CS_KOTLIN_OK/,'',60000));
  else {skip('Kotlin ausführen','Kotlin-Compiler oder Java-Laufzeit nicht erkannt');if(!has('kotlinc'))await test('Fehlende Kotlin-Laufzeit verständlich melden',async()=>{const target=path.join(fixture,'Fehlt.kt');await fs.writeFile(target,'fun main() { println("Hallo") }');await rejects('run.start',{path:target},/Kotlin-Compiler wurde nicht gefunden/);});}
  if(has('node'))await test('Interaktive Programmeingabe und zuverlässiges Stoppen des Prozessbaums',async()=>{
    const target=path.join(fixture,'interaktiv.cjs');await fs.writeFile(target,'const cp=require("node:child_process");const child=cp.spawn(process.execPath,["-e","setInterval(()=>{},1000)"],{stdio:"ignore"});console.log("CS_CHILD_PID="+child.pid);process.stdin.setEncoding("utf8");process.stdin.on("data",value=>console.log("CS_ECHO="+value.trim()));console.log("CS_BEREIT");setInterval(()=>{},1000);');
    const session=await invoke('run.start',{path:target});terminalIds.add(session.id);await waitBuffer(session.id,value=>stripVT(value.data).includes('CS_BEREIT'));
    await invoke('terminal.write',{id:session.id,data:'Hallo interaktiv\r'});const output=await waitBuffer(session.id,value=>stripVT(value.data).includes('CS_ECHO=Hallo interaktiv'));
    const pid=Number(output.text.match(/CS_CHILD_PID=(\d+)/)?.[1]);assert.ok(pid>0);await invoke('run.stop',{id:session.id});await delay(500);
    let alive=true;try{process.kill(pid,0)}catch{alive=false}assert.equal(alive,false,'Kindprozess läuft nach Stoppen weiter');return {childPid:pid,stopped:true};
  });
  await test('Echte PowerShell- und cmd-Terminals, Größenänderung und mehrere Sitzungen',async()=>{
    const ps=await invoke('terminal.create',{shell:'powershell',cols:100,rows:24});const cmd=await invoke('terminal.create',{shell:'cmd',cols:90,rows:20});terminalIds.add(ps.id);terminalIds.add(cmd.id);assert.notEqual(ps.id,cmd.id);
    await invoke('terminal.write',{id:ps.id,data:"Write-Output ('CS_' + 'POWERSHELL_OK')\r"});await waitBuffer(ps.id,value=>/CS_POWERSHELL_OK/.test(stripVT(value.data)));
    await invoke('terminal.write',{id:cmd.id,data:'echo CS_CMD_OK\r'});await waitBuffer(cmd.id,value=>/CS_CMD_OK/.test(stripVT(value.data)));
    await invoke('terminal.resize',{id:ps.id,cols:120,rows:30});await invoke('terminal.close',{id:ps.id});await invoke('terminal.close',{id:cmd.id});terminalIds.delete(ps.id);terminalIds.delete(cmd.id);
  });
  await test('HTML/CSS-Vorschau liefert lokale Ressourcen; Traversal und .env sind gesperrt',async()=>{
    await fs.writeFile(path.join(fixture,'index.html'),'<!doctype html><html><head><link rel="stylesheet" href="stil.css"></head><body>CS_PREVIEW_OK<script src="app.js"></script><script type="module" src="modul.js"></script></body></html>');await fs.writeFile(path.join(fixture,'stil.css'),'body { color: rgb(20, 30, 40); }');await fs.writeFile(path.join(fixture,'app.js'),'document.body.dataset.ready="yes";document.body.dataset.classic="yes";');
    await fs.writeFile(path.join(fixture,'wert.js'),'export const wert="CS_MODULE_OK";');await fs.writeFile(path.join(fixture,'data.json'),JSON.stringify({sentinel:'CS_FETCH_OK'}));await fs.writeFile(path.join(fixture,'modul.js'),'import {wert} from "./wert.js"; const response=await fetch("./data.json");document.body.dataset.module=wert;document.body.dataset.fetched=(await response.json()).sentinel;');
    const result=await invoke('run.start',{path:path.join(fixture,'index.html')});assert.match(result.previewUrl,/^http:\/\/127\.0\.0\.1:\d+\/index\.html$/);
    const html=await fetch(result.previewUrl);assert.equal(html.status,200);assert.match(await html.text(),/CS_PREVIEW_OK/);assert.match(await (await fetch(new URL('stil.css',result.previewUrl))).text(),/rgb\(20, 30, 40\)/);
    const envResult=await requestRaw(result.previewUrl,'/.env');assert.equal(envResult.status,403);const traversal=await requestRaw(result.previewUrl,'/%2e%2e/au%C3%9Ferhalb.txt');assert.equal(traversal.status,403);
    const isolated=await app.evaluate(async({BrowserWindow},url)=>{const probe=new BrowserWindow({show:false,webPreferences:{sandbox:true,nodeIntegration:false,contextIsolation:true}});try{await probe.loadURL(url);return await probe.webContents.executeJavaScript('({studio:typeof window.studio,require:typeof window.require,ready:document.body.dataset.ready})');}finally{probe.destroy();}},result.previewUrl);assert.deepEqual(isolated,{studio:'undefined',require:'undefined',ready:'yes'});
    await invoke('preview.refresh');await page.waitForFunction(()=>window.__qa.previews.length>0);return {localResources:true,previewBridge:'undefined'};
  });
  await test('HTML über Ausführen-Schaltfläche: eingebettete Vorschau führt klassisches JS, Module und lokale fetch-Anfrage aus',async()=>{
    await page.getByRole('treeitem',{name:'index.html',exact:true}).click();await page.getByRole('tab').filter({hasText:'index.html'}).waitFor();await page.locator('.run-button').click();
    const iframe=page.frameLocator('iframe[title="Lokale Webvorschau"]');await iframe.locator('body[data-classic="yes"][data-module="CS_MODULE_OK"][data-fetched="CS_FETCH_OK"]').waitFor();
    const isolation=await iframe.locator('body').evaluate(()=>{let parentReadable=true;try{void window.parent.document.body}catch{parentReadable=false}return {studio:typeof window.studio,require:typeof window.require,parentReadable};});assert.deepEqual(isolation,{studio:'undefined',require:'undefined',parentReadable:false});
    await capture('integration-preview.png');
    return {classicScript:true,modules:true,localFetch:true,parentReadable:false,privilegedBridge:'undefined'};
  });
  await test('Windows safeStorage: Key speichern, ersetzen, entschlüsseln und löschen, ohne Klartextdatei',async()=>{
    const one='CODESTUDIO-INTEGRATION-ONLY-NOT-A-REAL-KEY-ONE';const two='CODESTUDIO-INTEGRATION-ONLY-NOT-A-REAL-KEY-TWO';
    await invoke('ai.keySet',{id:'openai',key:one});assert.equal(await invoke('ai.keyReveal',{id:'openai'}),one);
    let vault=await fs.readFile(path.join(profile,'credentials.safe.json'),'utf8');assert.equal(vault.includes(one),false);
    await invoke('ai.keySet',{id:'openai',key:two});assert.equal(await invoke('ai.keyReveal',{id:'openai'}),two);vault=await fs.readFile(path.join(profile,'credentials.safe.json'),'utf8');assert.equal(vault.includes(two),false);
    await invoke('ai.keyDelete',{id:'openai'});assert.equal(await invoke('ai.keyReveal',{id:'openai'}),'');const providers=await invoke('ai.providers');assert.equal(providers.find(p=>p.id==='openai').hasKey,false);
    assert.equal((await fs.readFile(path.join(profile,'settings.json'),'utf8')).includes(one),false);return {realWindowsEncryption:true,networkRequests:0};
  });
  skip('Live-KI-Verbindungstest und Chat mit echten Zugangsdaten','Keine echten Zugangsdaten bereitgestellt; keine Verbindungserfolge erfunden.');
  await test('Dark-/Light-Theme und Panelaufteilung speichern',async()=>{
    await page.keyboard.press('Control+,');await page.getByRole('dialog',{name:'Einstellungen',exact:true}).waitFor();await page.locator('.settings-content label').filter({hasText:'Farbschema'}).locator('select').selectOption('light');
    await page.waitForFunction(()=>document.documentElement.dataset.theme==='light');await page.getByRole('button',{name:'Fertig',exact:true}).click();
    await invoke('app.settings',{sidebarWidth:360,panelHeight:280,wordWrap:true});
    const saved=(await invoke('app.bootstrap')).settings;assert.equal(saved.theme,'light');assert.equal(saved.sidebarWidth,360);assert.equal(saved.panelHeight,280);
    await capture('integration-light.png');
  });
  await capture('integration-before-restart.png');
  await close();await launch();
  await test('Einstellungen und gespeicherte Projektdateien bleiben nach Neustart erhalten',async()=>{
    const saved=(await invoke('app.bootstrap')).settings;assert.equal(saved.language,'de');assert.equal(saved.theme,'light');assert.equal(saved.sidebarWidth,360);assert.equal(saved.panelHeight,280);assert.equal(saved.wordWrap,true);assert.ok(saved.recentProjects.includes(fixture));
    await invoke('project.open',{path:fixture});const file=await invoke('fs.read',{path:path.join(fixture,'Unterordner Ü','Grüße.ts')});assert.match(file.content,/grüße/);
  });
  await test('Oberfläche rendert nach Neustart ohne JavaScript-Absturz',async()=>{
    await page.waitForSelector('button');await capture('integration-after-restart.png');assert.deepEqual(errors,[]);
  });
  await close();
  const englishProfile=path.join(runDir,'profile-en-conflict');await fs.mkdir(englishProfile);await fs.writeFile(path.join(englishProfile,'settings.json'),JSON.stringify({language:'en',recentProjects:[fixture],lastProject:null,theme:'dark'}));env.CODESTUDIO_TEST_DATA=englishProfile;await launch();
  await test('Englischer IPC-Dateikonflikt behält stabilen FILE_CONFLICT-Code und schützt externe Änderungen',async()=>{
    const bootstrap=await invoke('app.bootstrap');assert.equal(bootstrap.settings.language,'en');assert.equal(bootstrap.version,expectedVersion);await invoke('project.open',{path:fixture});
    const target=path.join(fixture,'english-conflict.txt');await fs.writeFile(target,'original');const opened=await invoke('fs.read',{path:target});await fs.writeFile(target,'external content');
    const result=await page.evaluate(async({path,hash})=>{try{await window.studio.invoke('fs.save',{path,content:'editor draft',hash});return {unexpectedSuccess:true};}catch(error){return {code:error.code,message:error.message};}},{path:target,hash:opened.hash});
    assert.equal(result.unexpectedSuccess,undefined);assert.ok(result.code==='FILE_CONFLICT'||result.message.startsWith('[FILE_CONFLICT]'),JSON.stringify(result));assert.match(result.message,/File conflict:/);assert.doesNotMatch(result.message,/Dateikonflikt/);assert.equal(await fs.readFile(target,'utf8'),'external content');assert.deepEqual(errors,[]);return {code:result.code||'FILE_CONFLICT via preserved message prefix',localizedMessage:result.message,externalContentPreserved:true};
  });
  }
}catch(error){if(!failedTest)report.results.push({name:'Integrationstest starten/fortsetzen',status:'failed',error:error.stack||error.message});console.error(error);}
finally{
  await close();report.finishedAt=new Date().toISOString();report.rendererErrors=errors;report.counts=Object.fromEntries(['passed','failed','skipped'].map(status=>[status,report.results.filter(item=>item.status===status).length]));report.fixture=runDir;
  await fs.mkdir(qaDir,{recursive:true});const reportJSON=JSON.stringify(report,null,2);const mode=process.env.CODESTUDIO_FOCUS,focused=['lifecycle','localization'].includes(mode);await fs.writeFile(path.join(qaDir,mode==='localization'?'localization-results.json':mode==='lifecycle'?'focused-lifecycle-results.json':'integration-results.json'),reportJSON);await fs.writeFile(path.join(runDir,'report.json'),reportJSON);if(process.env.CODESTUDIO_EXE&&!focused){await fs.writeFile(path.join(qaDir,'integration-packaged-results.json'),reportJSON);await fs.writeFile(path.join(qaDir,`integration-packaged-${expectedVersion}-results.json`),reportJSON);}
  console.log(JSON.stringify(report.counts));process.exitCode=report.counts.failed?1:0;
}
