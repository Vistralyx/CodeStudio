import {describe,it,expect,afterEach} from 'vitest';
import {promises as fs} from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import {cleanEnvironment,parseArguments,psLiteral,createPowerShellScript,killProcessTree,isPreviewPathBlocked,startPreviewServer,createRuntimeService} from '../electron/runtime';
import type {Settings,Locale} from '../src/shared';

const cleanup:(()=>Promise<any>)[]=[];
afterEach(async()=>{for(const fn of cleanup.splice(0).reverse())await fn();});

describe('Ausführungsgrenzen',()=>{
  it('vererbt notwendige Betriebssystemvariablen, aber keine API-Zugänge',()=>{
    const env=cleanEnvironment({Path:'C:\\Werkzeuge',SystemRoot:'C:\\Windows',OPENAI_API_KEY:'secret',ANTHROPIC_API_KEY:'secret',CUSTOM_SECRET:'secret',CODESTUDIO_TOKEN:'secret',ELECTRON_RUN_AS_NODE:'1'});
    expect(env.Path).toBe('C:\\Werkzeuge');expect(env.SystemRoot).toBe('C:\\Windows');
    expect(Object.keys(env).some(key=>/KEY|SECRET|TOKEN|ELECTRON/i.test(key))).toBe(false);
  });
  it('übergibt Leerzeichen, Umlaute, leere und Shell-Zeichen als Daten',()=>{
    expect(parseArguments('"Ordner mit Umlauten äöü" --name "" \'O\' "a&b" "$(Get-Process)"')).toEqual(['Ordner mit Umlauten äöü','--name','','O','a&b','$(Get-Process)']);
    expect(psLiteral("C:\\Projekte\\O'Brien & Söhne\\hallo.py")).toBe("'C:\\Projekte\\O''Brien & Söhne\\hallo.py'");
    expect(()=>parseArguments('"offen')).toThrow(/nicht geschlossen/);
    expect(()=>parseArguments('a\nb')).toThrow(/Ungültige/);
  });
  it('führt metazeichenhaltige Argumente wirklich unverändert durch PowerShell',async()=>{
    if(process.platform!=='win32')return;
    const values=['Grüße aus einem Ordner','a&b',"O'Brien",'$(Get-Process)','; echo UNERWUENSCHT','a"b','C:\\Pfad mit Leerzeichen\\',''];
    const script=createPowerShellScript([{file:process.execPath,args:['-e','process.stdout.write(JSON.stringify(process.argv.slice(1)))',...values]}]);
    const ps=path.join(process.env.SystemRoot||'C:\\Windows','System32','WindowsPowerShell','v1.0','powershell.exe');
    const child=spawn(ps,['-NoLogo','-NoProfile','-EncodedCommand',Buffer.from(script,'utf16le').toString('base64')],{windowsHide:true,env:cleanEnvironment()});
    let output='';let errors='';child.stdout.on('data',data=>output+=data.toString());child.stderr.on('data',data=>errors+=data.toString());
    const [code]=await once(child,'close');expect(errors).toBe('');expect(code).toBe(0);expect(JSON.parse(output)).toEqual(values);
  },15000);
  it('beendet einen real gestarteten Prozess einschließlich seines Kindes',async()=>{
    const child=spawn(process.execPath,['-e',`const {spawn}=require('node:child_process');const c=spawn(process.execPath,['-e','setInterval(()=>{},1000)'],{stdio:'ignore'});console.log(c.pid);setInterval(()=>{},1000);`],{windowsHide:true,detached:process.platform!=='win32',env:cleanEnvironment()});
    cleanup.push(async()=>{if(child.pid)await killProcessTree(child.pid);});
    const childPid=await new Promise<number>((resolve,reject)=>{child.stdout.once('data',data=>resolve(Number(data.toString().trim())));child.once('error',reject);});
    expect(childPid).toBeGreaterThan(0);await killProcessTree(child.pid!);
    await new Promise(resolve=>setTimeout(resolve,250));
    expect(()=>process.kill(child.pid!,0)).toThrow();expect(()=>process.kill(childPid,0)).toThrow();
  },15000);
});

describe('Lokale HTML-Vorschau',()=>{
  it('übersetzt Vorschaufehler ohne Dateiinhalte oder Schutzgrenzen zu verändern',async()=>{
    const temp=await fs.mkdtemp(path.join(os.tmpdir(),'codestudio-preview-i18n-'));cleanup.push(()=>fs.rm(temp,{recursive:true,force:true}));await fs.writeFile(path.join(temp,'index.html'),'<h1>Inhalt unverändert: Grüße</h1>');
    let language:Locale='es';const {server,baseUrl}=await startPreviewServer(temp,async file=>fs.realpath(file),()=>language);cleanup.push(()=>new Promise<void>(resolve=>server.close(()=>resolve())));
    const denied=await fetch(baseUrl+'/.env');expect(denied.status).toBe(403);expect(await denied.text()).toBe('Este archivo no se ofrece en la vista previa.');
    language='fr';expect(await (await fetch(baseUrl+'/.env')).text()).toBe('Ce fichier n’est pas accessible dans l’aperçu.');expect(await (await fetch(baseUrl+'/index.html')).text()).toBe('<h1>Inhalt unverändert: Grüße</h1>');
  });
  it('liefert HTML und lokale CSS-Dateien, blockiert Traversal, Schlüssel und Projektflucht',async()=>{
    const temp=await fs.mkdtemp(path.join(os.tmpdir(),'codestudio-preview-test-'));cleanup.push(()=>fs.rm(temp,{recursive:true,force:true}));
    const root=path.join(temp,'Projekt mit Ümlauten');await fs.mkdir(root);
    await fs.writeFile(path.join(root,'index.html'),'<link rel="stylesheet" href="styles.css"><h1>Hallo</h1>');
    await fs.writeFile(path.join(root,'styles.css'),'h1 { color: gray; }');await fs.writeFile(path.join(root,'.env'),'SECRET=hidden');await fs.writeFile(path.join(temp,'outside.txt'),'outside');
    const authorize=async(file:string)=>{const resolved=await fs.realpath(file);const relative=path.relative(root,resolved);if(relative.startsWith('..')||path.isAbsolute(relative))throw new Error('outside');return resolved;};
    const {server,baseUrl}=await startPreviewServer(root,authorize);cleanup.push(()=>new Promise<void>(resolve=>server.close(()=>resolve())));
    expect(await (await fetch(baseUrl+'/index.html')).text()).toContain('<h1>Hallo</h1>');
    const css=await fetch(baseUrl+'/styles.css');expect(css.status).toBe(200);expect(css.headers.get('content-type')).toContain('text/css');
    expect((await fetch(baseUrl+'/.env')).status).toBe(403);
    expect((await fetch(baseUrl+'/%2e%2e%5coutside.txt')).status).toBe(403);
    expect((await fetch(baseUrl+'/styles.css',{method:'POST'})).status).toBe(405);
    if(process.platform==='win32'){
      await fs.mkdir(path.join(temp,'outside'));await fs.writeFile(path.join(temp,'outside','secret.txt'),'secret');
      await fs.symlink(path.join(temp,'outside'),path.join(root,'escape'),'junction');
      expect((await fetch(baseUrl+'/escape/secret.txt')).status).toBe(404);
    }
  },15000);
  it('schließt auch verschachtelte Zugangsdaten aus',()=>{
    for(const name of ['.env','.env.production','config/private.pem','keys/id_ed25519','.git/config','.npmrc','.aws/credentials','credentials.safe.json','a/../b'])expect(isPreviewPathBlocked(name)).toBe(true);
    expect(isPreviewPathBlocked('assets/logo.png')).toBe(false);
  });
});

describe('Laufzeit-Lokalisierung',()=>{
  it('lokalisiert auch zwischengespeicherte Erkennung und Aufgaben ohne IDs oder Pfade umzuschreiben',async()=>{
    const temp=await fs.mkdtemp(path.join(os.tmpdir(),'codestudio-runtime-i18n-'));cleanup.push(()=>fs.rm(temp,{recursive:true,force:true}));await fs.writeFile(path.join(temp,'pom.xml'),'<project/>');
    let language:Locale='en';const runtimePaths=Object.fromEntries(['node','python','java','javac','kotlinc','mvn','gradle'].map(id=>[id,path.join(temp,`Speichern-${id}.missing`)]));
    const instance=createRuntimeService({getWindow:()=>null,getRoot:()=>temp,authorize:async file=>file,getSettings:()=>({language,runtimePaths} as Settings),updateSettings:async()=>{},notify:()=>{}});cleanup.push(()=>instance.dispose());
    const english=await instance.handle('runtime.list',{}) as any[];expect(english.find((item:any)=>item.id==='java').label).toBe('Java runtime');expect(english[0].version).toContain('Not found');expect(english[0].path).toBe(runtimePaths.node);
    language='it';const italian=await instance.handle('runtime.list',{}) as any[];expect(italian.find((item:any)=>item.id==='javac').label).toBe('Compilatore Java (JDK)');expect(italian[0].version).toContain('Non trovato');expect(italian[0].path).toBe(runtimePaths.node);
    expect((await instance.handle('run.tasks',{}) as any[]).find((item:any)=>item.id==='maven:compile').label).toBe('Maven: compila');
  });
  it('lässt echte Versionsausgaben unverändert, auch wenn sie einem Katalogtext gleichen',async()=>{
    if(process.platform!=='win32')return;
    const temp=await fs.mkdtemp(path.join(os.tmpdir(),'codestudio-version-i18n-'));cleanup.push(()=>fs.rm(temp,{recursive:true,force:true}));const tool=path.join(temp,'runtime.cmd');await fs.writeFile(tool,'@echo off\r\necho Unbekannte Laufzeit.\r\nexit /b 0\r\n');
    const runtimePaths=Object.fromEntries(['node','python','java','javac','kotlinc','mvn','gradle'].map(id=>[id,id==='node'?tool:path.join(temp,id+'.missing')]));
    const instance=createRuntimeService({getWindow:()=>null,getRoot:()=>temp,authorize:async file=>file,getSettings:()=>({language:'es',runtimePaths} as Settings),updateSettings:async()=>{},notify:()=>{}});cleanup.push(()=>instance.dispose());
    const result=await instance.handle('runtime.list',{}) as any[];expect(result.find((item:any)=>item.id==='node').version).toBe('Unbekannte Laufzeit.');
  },15000);
});
