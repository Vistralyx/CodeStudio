import {afterAll,afterEach,describe,expect,it,vi} from 'vitest';
import {promises as fs} from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {runInNewContext} from 'node:vm';
import type {MessageCatalogue} from '../src/locales/types';
import type {Locale} from '../src/shared';

// Deliberate local test catalogue, not network responses or product copy.
vi.mock('../src/locales/app',()=>({messages:{
  'Speichern':{en:'Save',es:'Guardar',fr:'Enregistrer',it:'Salva'},
  'Datei „{name}“ wurde geändert.':{en:'File “{name}” was changed.',es:'El archivo «{name}» cambió.',fr:'Le fichier « {name} » a changé.',it:'Il file «{name}» è cambiato.'},
  'Fehler [A]. Datei {name}?':{en:'Error [A]. File {name}?',es:'Error [A]. Archivo {name}?',fr:'Erreur [A]. Fichier {name} ?',it:'Errore [A]. File {name}?'},
  '„{name}“ passt nicht zu „{name}“.':{en:'“{name}” does not match “{name}”.',es:'«{name}» no coincide con «{name}».',fr:'« {name} » ne correspond pas à « {name} ».',it:'«{name}» non corrisponde a «{name}».'},
}}));
vi.mock('../src/locales/panels',()=>({messages:{
  '{count} Dateien':{en:'{count} files',es:'{count} archivos',fr:'{count} fichiers',it:'{count} file'},
}}));
vi.mock('../src/locales/backend',()=>({messages:{
  'Der Pfad':{en:'The path',es:'La ruta',fr:'Le chemin',it:'Il percorso'},
  'Kotlin-Compiler':{en:'Kotlin compiler',es:'Compilador de Kotlin',fr:'Compilateur Kotlin',it:'Compilatore Kotlin'},
  '{label} ist ungültig.':{en:'{label} is invalid.',es:'{label} no es válido.',fr:'{label} est invalide.',it:'{label} non è valido.'},
  '{runtime} wurde nicht gefunden. Pfad: {path}.':{en:'{runtime} was not found. Path: {path}.',es:'No se encontró {runtime}. Ruta: {path}.',fr:'{runtime} est introuvable. Chemin : {path}.',it:'{runtime} non trovato. Percorso: {path}.'},
  'Dateikonflikt: {path}':{en:'File conflict: {path}',es:'Conflicto de archivo: {path}',fr:'Conflit de fichier : {path}',it:'Conflitto file: {path}'},
  'Dateikonflikt: {path}. Erwarteter Stand: {hash}.':{en:'Stale file: {path}. Expected version: {hash}.',es:'Archivo obsoleto: {path}. Versión esperada: {hash}.',fr:'Fichier obsolète : {path}. Version attendue : {hash}.',it:'File obsoleto: {path}. Versione prevista: {hash}.'},
}}));
import {catalogueConflicts,getLanguage,languages,localizeMessage,normalizeLocale,setLanguage,t,translate} from '../src/i18n';
import {loadMonacoLocale} from '../src/bootstrap';
import {cleanSettings,createSettingsStore,defaults} from '../electron/settings';

const temporary:string[]=[];
afterEach(async()=>{setLanguage('en');for(const directory of temporary.splice(0))await fs.rm(directory,{recursive:true,force:true})});
describe('Language settings and persistence',()=>{
  it('starts in English for a clean or legacy profile without a language',()=>{
    expect(defaults.language).toBe('en');expect(cleanSettings(undefined).language).toBe('en');expect(cleanSettings({theme:'light'}).language).toBe('en');
  });
  it.each<Locale>(['en','de','es','fr','it'])('keeps the selected %s locale and existing unrelated settings',language=>{
    const value=cleanSettings({language,theme:'light',fontSize:19,tabSize:4,insertSpaces:false,wordWrap:true,panelHeight:280,recentProjects:['C:\\Projekt Ä'],lastProject:'C:\\Projekt Ä',runtimePaths:{python:'C:\\Python\\python.exe'},runArgs:'"hello world"',providers:{openai:{model:'my-model'}},windowBounds:{width:1000,height:750,x:30,y:40}});
    expect(value).toMatchObject({language,theme:'light',fontSize:19,tabSize:4,insertSpaces:false,wordWrap:true,panelHeight:280,recentProjects:['C:\\Projekt Ä'],lastProject:'C:\\Projekt Ä',runtimePaths:{python:'C:\\Python\\python.exe'},runArgs:'"hello world"',providers:{openai:{model:'my-model'}},windowBounds:{width:1000,height:750,x:30,y:40}});
  });
  it.each([null,'pt','EN','de-DE',42,{},['fr']])('rejects unsupported settings language %j',language=>expect(cleanSettings({language}).language).toBe('en'));
  it('retains the chosen language after saving and opening the profile again',async()=>{
    const directory=await fs.mkdtemp(path.join(os.tmpdir(),'codestudio-i18n-'));temporary.push(directory);
    const first=await createSettingsStore(directory);expect(first.get().language).toBe('en');await first.update({language:'fr',theme:'light',fontSize:18});
    const restarted=await createSettingsStore(directory);expect(restarted.get()).toMatchObject({language:'fr',theme:'light',fontSize:18});
    const disk=JSON.parse(await fs.readFile(path.join(directory,'settings.json'),'utf8'));expect(disk.language).toBe('fr');
  });
});

describe('Translation engine',()=>{
  it('provides the five endonyms and a safe English fallback',()=>{
    expect(languages).toEqual([{id:'en',label:'English'},{id:'de',label:'Deutsch'},{id:'es',label:'Español'},{id:'fr',label:'Français'},{id:'it',label:'Italiano'}]);
    expect(normalizeLocale('invalid')).toBe('en');expect(setLanguage('es')).toBe('es');expect(getLanguage()).toBe('es');expect(t('Speichern')).toBe('Guardar');expect(catalogueConflicts).toEqual([]);
  });
  it('formats named parameters without replacement expansion or recursive interpolation',()=>{
    const name='C:\\Speichern\\Grüße $& ${value} {count}.ts';
    expect(translate('en','Datei „{name}“ wurde geändert.',{name})).toBe(`File “${name}” was changed.`);
    expect(translate('de','Datei „{name}“ wurde geändert.',{name})).toBe(`Datei „${name}“ wurde geändert.`);
    expect(translate('fr','{count} Dateien',{count:3})).toBe('3 fichiers');
    expect(translate('en','Datei „{name}“ wurde geändert.',Object.create({name:'inherited'}))).toBe('File “{name}” was changed.');
  });
  it('matches formatted German templates while preserving paths and user names',()=>{
    expect(localizeMessage('en','Datei „Speichern“ wurde geändert.')).toBe('File “Speichern” was changed.');
    const file='C:\\Projekt mit Ümlauten\\[abc].py';
    expect(localizeMessage('en',`Kotlin-Compiler wurde nicht gefunden. Pfad: ${file}.`)).toBe(`Kotlin compiler was not found. Path: ${file}.`);
    expect(localizeMessage('en','Der Pfad ist ungültig.')).toBe('The path is invalid.');
  });
  it('escapes template metacharacters and enforces repeated placeholder values',()=>{
    expect(localizeMessage('en','Fehler [A]. Datei hello.ts?')).toBe('Error [A]. File hello.ts?');
    expect(localizeMessage('en','Fehler A. Datei hello.ts?')).toBe('Fehler A. Datei hello.ts?');
    expect(localizeMessage('en','„x“ passt nicht zu „x“.')).toBe('“x” does not match “x”.');
    expect(localizeMessage('en','„x“ passt nicht zu „y“.')).toBe('„x“ passt nicht zu „y“.');
  });
  it('prefers specific templates and leaves uncatalogued OS/API output unchanged',()=>{
    expect(localizeMessage('en','Dateikonflikt: C:\\a.ts. Erwarteter Stand: ABC.')).toBe('Stale file: C:\\a.ts. Expected version: ABC.');
    const original='HTTP 429: quota exhausted {"model":"private-name"}\ncompiler: unexpected token';
    expect(localizeMessage('it',original)).toBe(original);expect(translate('en','__proto__')).toBe('__proto__');
  });
});

describe('Real product catalogue integrity',()=>{
  it('has complete, nonempty translations and preserves every named placeholder',async()=>{
    const modules=await Promise.all([
      vi.importActual<{messages:MessageCatalogue}>('../src/locales/app'),
      vi.importActual<{messages:MessageCatalogue}>('../src/locales/panels'),
      vi.importActual<{messages:MessageCatalogue}>('../src/locales/backend'),
    ]);
    const seen=new Map<string,unknown>();
    const placeholders=(value:string)=>[...new Set([...value.matchAll(/\{([A-Za-z][A-Za-z0-9_]*)\}/g)].map(match=>match[1]))].sort();
    for(const [index,{messages}] of modules.entries()){
      expect(Object.keys(messages).length,`catalogue ${index} must contain product strings`).toBeGreaterThan(0);
      for(const [source,translations] of Object.entries(messages)){
        expect(source.trim(),`empty source key in catalogue ${index}`).not.toBe('');
        expect(Object.keys(translations).sort(),source).toEqual(['en','es','fr','it']);
        for(const language of ['en','es','fr','it'] as const){expect(translations[language].trim(),`${language}: ${source}`).not.toBe('');expect(placeholders(translations[language]),`${language}: ${source}`).toEqual(placeholders(source));}
        if(seen.has(source))expect(translations,`conflicting duplicate: ${source}`).toEqual(seen.get(source));else seen.set(source,translations);
      }
    }
    // Every literal explicitly marked for UI translation needs an entry. This
    // catches forgotten labels; unknown external OS/API strings may still fall
    // back unchanged through localizeMessage by design.
    const missing:Array<{file:string;source:string}>=[];
    for(const file of ['App.tsx','Settings.tsx','Chat.tsx','Explorer.tsx','Editor.tsx','Terminal.tsx','Markup.tsx','main.tsx']){
      const source=await fs.readFile(new URL('../src/'+file,import.meta.url),'utf8');
      for(const match of source.matchAll(/(?:^|[^.\w])t\(\s*("(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*')/g)){
        const key=runInNewContext(match[1],Object.create(null),{timeout:100}) as string;
        if(!seen.has(key))missing.push({file,source:key});
      }
    }
    expect(missing,'literal t() calls missing from the product catalogues').toEqual([]);
  });
});

describe('Monaco locale bootstrap resources',()=>{
  const globals=globalThis as typeof globalThis&{_VSCODE_NLS_MESSAGES?:Array<string|null>;_VSCODE_NLS_LANGUAGE?:string};
  const original={messages:globals._VSCODE_NLS_MESSAGES,language:globals._VSCODE_NLS_LANGUAGE};
  afterAll(()=>{if(original.messages)globals._VSCODE_NLS_MESSAGES=original.messages;else delete globals._VSCODE_NLS_MESSAGES;if(original.language)globals._VSCODE_NLS_LANGUAGE=original.language;else delete globals._VSCODE_NLS_LANGUAGE});
  it.each<['de'|'es'|'fr'|'it',string,string]>([['de','Suchen','Ersetzen'],['es','Buscar','Reemplazar'],['fr','Rechercher','Remplacer'],['it','Trova','Sostituisci']])('loads the installed %s resource before UI creation',async(language,find,replace)=>{
    await loadMonacoLocale(language);expect(globals._VSCODE_NLS_LANGUAGE).toBe(language);expect(globals._VSCODE_NLS_MESSAGES?.length).toBeGreaterThan(2000);expect(globals._VSCODE_NLS_MESSAGES?.[1019]).toBe(find);expect(globals._VSCODE_NLS_MESSAGES?.[1025]).toBe(replace);
  });
  it('clears German/global locale state for English and can restore a cached resource',async()=>{
    await loadMonacoLocale('de');await loadMonacoLocale('en');expect(globals._VSCODE_NLS_MESSAGES).toBeUndefined();expect(globals._VSCODE_NLS_LANGUAGE).toBeUndefined();await loadMonacoLocale('de');expect(globals._VSCODE_NLS_MESSAGES?.[1019]).toBe('Suchen');
  });
});
