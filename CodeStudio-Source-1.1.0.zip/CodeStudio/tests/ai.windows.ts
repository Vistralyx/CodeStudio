/** Actual Windows/Electron safeStorage smoke test. Uses generated dummy values, no API call.
 * Build: node node_modules/esbuild/bin/esbuild tests/ai.windows.ts --bundle --platform=node --format=cjs --external:electron --outfile=.qa/ai.windows.cjs
 * Run: .\node_modules\electron\dist\electron.exe .qa/ai.windows.cjs
 */
import {app,safeStorage} from 'electron';
import {mkdtempSync} from 'node:fs';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {CredentialVault} from '../electron/ai';

const profile=mkdtempSync(path.join(os.tmpdir(),'CodeStudio-APIKey-Pruefung-'));
app.setPath('userData',profile);
app.whenReady().then(async()=>{
  try{
    assert.equal(process.platform,'win32','This is a Windows-only test.');
    assert.equal(await safeStorage.isAsyncEncryptionAvailable(),true,'Windows encryption must be available.');
    const filename=path.join(profile,'credentials.safe.json'),vault=new CredentialVault(filename);
    const first=`CodeStudio-Dummy-${randomUUID()}`,second=`CodeStudio-Dummy-${randomUUID()}`;
    await vault.set('test:local-protector',first);
    assert.equal(await vault.has('test:local-protector'),true);
    assert.equal(await vault.get('test:local-protector'),first);
    assert.equal((await fs.readFile(filename,'utf8')).includes(first),false);
    await vault.set('test:local-protector',second);
    assert.equal(await vault.get('test:local-protector'),second);
    assert.equal((await fs.readFile(filename,'utf8')).includes(second),false);
    await vault.delete('test:local-protector');
    assert.equal(await vault.has('test:local-protector'),false);
    assert.equal(await vault.get('test:local-protector'),'');
    assert.deepEqual(JSON.parse(await fs.readFile(filename,'utf8')).entries,{});
    console.log(JSON.stringify({ok:true,test:'Windows Electron safeStorage: speichern, lesen, ersetzen, löschen; kein Klartext in Datei',electron:process.versions.electron,platform:process.platform,osRelease:os.release(),dummyKeys:true,apiRequests:0}));
    await fs.rm(profile,{recursive:true,force:true});app.exit(0);
  }catch(error){console.error(error instanceof Error?error.message:'Windows safeStorage test failed');await fs.rm(profile,{recursive:true,force:true}).catch(()=>{});app.exit(1);}
});
