/** Provider tests use simulated HTTP responses and a simulated credential protector.
 * No paid API request and no assertion about a real provider account is made here.
 */
import {afterEach,beforeEach,describe,expect,it,vi} from 'vitest';
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import {createHash} from 'node:crypto';
import type {Settings} from '../src/shared';

const storage=vi.hoisted(()=>({
  isAsyncEncryptionAvailable:vi.fn(async()=>true),
  encryptStringAsync:vi.fn(async(value:string)=>Buffer.from(`MOCK-CIPHERTEXT:${Buffer.from(value).toString('base64')}`)),
  decryptStringAsync:vi.fn(async(value:Buffer)=>({result:Buffer.from(value.toString().replace('MOCK-CIPHERTEXT:',''),'base64').toString(),shouldReEncrypt:false})),
}));
vi.mock('electron',()=>({safeStorage:storage}));
import {assistantSystem,buildProviderRequest,CredentialVault,createAIService,decodeContextFile,decodeProviderEvent,parseSSE,PROVIDERS,redact,requestProvider,sensitiveContextPath,validateEndpoint} from '../electron/ai';

let temporary:string;
beforeEach(async()=>{temporary=await fs.mkdtemp(path.join(os.tmpdir(),'CodeStudio-KI-'));vi.clearAllMocks();storage.isAsyncEncryptionAvailable.mockResolvedValue(true);});
afterEach(async()=>{vi.unstubAllGlobals();await fs.rm(temporary,{recursive:true,force:true});});
function config(id:any){return {...PROVIDERS[id as keyof typeof PROVIDERS],id,model:'test-model',...(id==='custom'?{baseUrl:'https://example.test/v1'}:{})} as any;}
function sse(text:string,split=0){
  const raw=new TextEncoder().encode(text);return new ReadableStream<Uint8Array>({start(controller){if(split){for(let i=0;i<raw.length;i+=split)controller.enqueue(raw.slice(i,i+split));}else controller.enqueue(raw);controller.close();}});
}
function streamResponse(body:string){return new Response(sse(body,3),{headers:{'content-type':'text/event-stream'}});}
function service(){
  let settings={language:'de',providers:{},activeProvider:'openai'} as unknown as Settings;let root:string|null=temporary;
  const notify=vi.fn();
  const instance=createAIService({getSettings:()=>settings,updateSettings:async patch=>{settings={...settings,...patch};},dataDir:path.join(temporary,'userdata'),getRoot:()=>root,authorize:async filename=>{
    const target=path.resolve(filename);if(!target.startsWith(temporary+path.sep))throw new Error('Nicht freigegeben.');return target;
  },notify});
  return {instance,notify,setRoot:(value:string|null)=>{root=value;},settings:()=>settings};
}

describe('KI-Lokalisierung ohne echte API-Verbindung',()=>{
  it('wählt die Antwortsprache und erhält das vollständige Änderungsprotokoll in allen fünf Sprachen',()=>{
    for(const [language,phrase] of [['en','Respond in English'],['de','Antworte auf Deutsch'],['es','Responde en español'],['fr','Réponds en français'],['it','Rispondi in italiano']] as const){const prompt=assistantSystem(language);expect(prompt).toContain(phrase);expect(prompt).toContain('```codestudio-file path="relative/path.ext"');expect(prompt).toContain('../');}
    expect(assistantSystem()).toContain('Respond in English');
  });
  it('lokalisiert Anbieterstatus beim Sprachwechsel und bewahrt Chat-Inhalte',async()=>{
    const {instance,settings}=service();settings().language='en';let providers=await instance.handle('ai.providers',{});expect(providers.find((p:any)=>p.id==='custom').label).toBe('Custom (Chat Completions)');expect(providers.find((p:any)=>p.id==='openai').status).toBe('Not tested yet');
    await instance.handle('ai.historySave',{messages:[{role:'assistant',content:'Diese Datei ist meine unveränderte Antwort.'}]});settings().language='it';providers=await instance.handle('ai.providers',{});expect(providers.find((p:any)=>p.id==='custom').label).toBe('Personalizzato (Chat Completions)');expect(providers.find((p:any)=>p.id==='openai').status).toBe('Non ancora verificato');expect((await instance.handle('ai.history',{}))[0].content).toBe('Diese Datei ist meine unveränderte Antwort.');instance.dispose();
  });
  it('sendet die gewählte Sprache im Systemprompt und übersetzt keine Modellantworten (HTTP simuliert)',async()=>{
    const {instance,settings,notify}=service();settings().language='es';await instance.handle('ai.configure',{id:'custom',baseUrl:'https://example.test/v1',model:'modelo-literal'});await instance.handle('ai.keySet',{id:'custom',key:'INERT_TEST_KEY'});
    const response='Diese Datei wurde nicht gefunden.';const fetcher=vi.fn(async(_url:unknown,_options:any)=>streamResponse(`data: ${JSON.stringify({choices:[{delta:{content:response}}]})}\n\ndata: [DONE]\n\n`));vi.stubGlobal('fetch',fetcher);
    await instance.handle('ai.send',{requestId:'locale-test',provider:'custom',messages:[{role:'user',content:'KEEP_USER_CONTENT_EXACT'}],context:[]});await vi.waitFor(()=>expect(notify).toHaveBeenCalledWith('ai.done',expect.objectContaining({requestId:'locale-test'})));
    const body=JSON.parse(fetcher.mock.calls[0][1].body);expect(body.messages[0].content).toContain('Responde en español');expect(body.messages[1].content).toBe('KEEP_USER_CONTENT_EXACT');expect(body.model).toBe('modelo-literal');expect(notify).toHaveBeenCalledWith('ai.delta',{requestId:'locale-test',text:response});settings().language='fr';const providers=await instance.handle('ai.providers',{});expect(providers.find((p:any)=>p.id==='custom').status).toBe('Connexion testée avec succès');instance.dispose();
  });
  it('übersetzt asynchrone API-Fehler und erhält die rohe Anbieter-Ergänzung (HTTP simuliert)',async()=>{
    const {instance,settings,notify}=service();settings().language='fr';await instance.handle('ai.configure',{id:'custom',baseUrl:'https://example.test/v1',model:'literal-model'});await instance.handle('ai.keySet',{id:'custom',key:'INERT_TEST_KEY'});vi.stubGlobal('fetch',vi.fn(async()=>new Response(JSON.stringify({error:{message:'RAW_PROVIDER_DETAIL_123'}}),{status:401})));
    await instance.handle('ai.send',{requestId:'failure-locale',provider:'custom',messages:[{role:'user',content:'Question'}],context:[]});await vi.waitFor(()=>expect(notify).toHaveBeenCalledWith('ai.error',expect.objectContaining({requestId:'failure-locale',message:'La clé API n’est pas valide. (HTTP 401) RAW_PROVIDER_DETAIL_123'})));instance.dispose();
  });
});

describe('API-Ziele und Kontextgrenzen',()=>{
  it('akzeptiert HTTPS und explizites loopback HTTP, ohne Query/Passwörter',()=>{
    expect(validateEndpoint('https://example.test/v1/')).toBe('https://example.test/v1');
    expect(validateEndpoint('http://127.0.0.1:11434/v1')).toBe('http://127.0.0.1:11434/v1');
    expect(validateEndpoint('http://[::1]:11434/v1')).toBe('http://[::1]:11434/v1');
    for(const value of ['http://example.test/v1','https://user:password@example.test','https://example.test?key=secret','file:///C:/secret','javascript:alert(1)','https://example.test/#secret'])expect(()=>validateEndpoint(value)).toThrow();
  });
  it('blockiert typische Geheimnisdateien einschließlich Windows-Pfaden',()=>{
    for(const value of ['C:\\Projekt\\.env','C:\\Projekt\\.env.local','/project/.ssh/id_ed25519','/project/cert.pem','/project/service.key','/project/.aws/config','/project/credentials.json','/project/.npmrc'])expect(sensitiveContextPath(value),value).toBe(true);
    expect(sensitiveContextPath('C:\\Projekt\\src\\main.ts')).toBe(false);
    expect(sensitiveContextPath('/project/environment.ts')).toBe(false);
  });
  it('entfernt bekannte Schlüssel aus Fehlern und verhindert Bearer-Ausgaben',()=>{
    expect(redact('secret abcdefghijklmnop', ['abcdefghijklmnop'])).not.toContain('abcdefghijklmnop');
    expect(redact('Authorization: Bearer xyzabc123')).not.toContain('xyzabc123');
    expect(redact('sk-ant-abcdefghijklmnop')).toBe('[API-Key entfernt]');
  });
  it('dekodiert UTF-8 und UTF-16 Kontextdateien mit Umlauten und blockiert Binärdaten',()=>{
    expect(decodeContextFile(Buffer.from('\uFEFFGrüße','utf8'))).toBe('Grüße');
    expect(decodeContextFile(Buffer.concat([Buffer.from([0xff,0xfe]),Buffer.from('Grüße','utf16le')]))).toBe('Grüße');
    const be=Buffer.from('Grüße','utf16le');be.swap16();expect(decodeContextFile(Buffer.concat([Buffer.from([0xfe,0xff]),be]))).toBe('Grüße');
    expect(()=>decodeContextFile(Buffer.from([0,1,2]))).toThrow('Binärdateien');
  });
});

describe('Getrennte Provideradapter (simuliert)',()=>{
  it('verwendet native Anfrageformate und hält Keys aus URL/Body',()=>{
    const chat=[{role:'user' as const,content:'Hallo'}];
    const openai=buildProviderRequest(config('openai'),'TESTKEY',chat,'system',true);
    expect(openai.url).toBe('https://api.openai.com/v1/responses');expect(openai.body.store).toBe(false);expect(openai.body.input).toEqual(chat);expect(openai.headers.Authorization).toBe('Bearer TESTKEY');
    const claude=buildProviderRequest(config('anthropic'),'TESTKEY',chat,'system',true);
    expect(claude.url).toBe('https://api.anthropic.com/v1/messages');expect(claude.headers['x-api-key']).toBe('TESTKEY');expect(claude.headers['anthropic-version']).toBe('2026-10-21');expect(claude.body.system).toBe('system');
    const gemini=buildProviderRequest(config('gemini'),'TESTKEY',chat,'system',true);
    expect(gemini.url).toContain(':streamGenerateContent?alt=sse');expect(gemini.body.contents[0]).toEqual({role:'user',parts:[{text:'Hallo'}]});expect(gemini.headers['x-goog-api-key']).toBe('TESTKEY');
    const xai=buildProviderRequest(config('xai'),'TESTKEY',chat,'system',true);
    expect(xai.url).toBe('https://api.x.ai/v1/chat/completions');expect(xai.body.messages[0].role).toBe('system');
    for(const r of [openai,claude,gemini,xai]){expect(r.url).not.toContain('TESTKEY');expect(JSON.stringify(r.body)).not.toContain('TESTKEY');}
  });
  it('verarbeitet SSE mit beliebigen UTF-8- und CRLF-Chunkgrenzen',async()=>{
    const frames=[];
    for await(const frame of parseSSE(sse(': keepalive\r\nevent: delta\r\ndata: {"text":"Grüße"}\r\n\r\ndata: erste\r\ndata: zweite\r\n\r\ndata: ende',1)))frames.push(frame);
    expect(frames).toEqual([{event:'delta',data:'{"text":"Grüße"}'},{event:'message',data:'erste\nzweite'},{event:'message',data:'ende'}]);
  });
  it.each([
    ['openai','data: {"type":"response.output_text.delta","delta":"Hallo"}\n\ndata: {"type":"response.completed","response":{"usage":{"input_tokens":2,"output_tokens":1,"total_tokens":3}}}\n\n'],
    ['anthropic','event: message_start\ndata: {"type":"message_start","message":{"usage":{"input_tokens":2}}}\n\nevent: content_block_delta\ndata: {"type":"content_block_delta","delta":{"type":"text_delta","text":"Hallo"}}\n\nevent: message_delta\ndata: {"type":"message_delta","usage":{"output_tokens":1}}\n\nevent: message_stop\ndata: {"type":"message_stop"}\n\n'],
    ['gemini','data: {"candidates":[{"content":{"parts":[{"text":"Hallo"}]},"finishReason":"STOP"}],"usageMetadata":{"promptTokenCount":2,"candidatesTokenCount":1,"totalTokenCount":3}}\n\n'],
    ['xai','data: {"choices":[{"delta":{"content":"Hallo"}}]}\n\ndata: {"choices":[],"usage":{"prompt_tokens":2,"completion_tokens":1,"total_tokens":3}}\n\ndata: [DONE]\n\n'],
  ])('streamt %s-Text und echte Antwort-Metadaten (HTTP simuliert)',async(id,body)=>{
    const chunks:string[]=[];const fetcher=vi.fn(async()=>streamResponse(body)) as unknown as typeof fetch;
    const usage=await requestProvider(config(id),'key',[{role:'user',content:'Hi'}],'sys',new AbortController().signal,t=>chunks.push(t),false,fetcher);
    expect(chunks.join('')).toBe('Hallo');expect(usage?.inputTokens).toBe(2);expect(usage?.outputTokens).toBe(1);expect(usage?.source).toBe('API');
    expect(fetcher).toHaveBeenCalledWith(expect.any(String),expect.objectContaining({redirect:'error'}));
  });
  it('meldet einen abgebrochenen OpenAI-Stream als unvollständig',async()=>{
    const fetcher=vi.fn(async()=>streamResponse('data: {"type":"response.output_text.delta","delta":"teil"}\n\n')) as unknown as typeof fetch;
    await expect(requestProvider(config('openai'),'key',[{role:'user',content:'Hi'}],'sys',new AbortController().signal,()=>{},false,fetcher)).rejects.toThrow('vor Abschluss');
  });
  it('meldet auch einen kompatiblen Stream ohne Ende-Marker als unvollständig',async()=>{
    const fetcher=vi.fn(async()=>streamResponse('data: {"choices":[{"delta":{"content":"Teilantwort"}}]}\n\n')) as unknown as typeof fetch;
    await expect(requestProvider(config('xai'),'key',[{role:'user',content:'Hi'}],'sys',new AbortController().signal,()=>{},false,fetcher)).rejects.toThrow('vor Abschluss');
  });
  it('zeigt HTTP 401 als Key-Fehler, ohne den vom Server reflektierten Key',async()=>{
    const key='test-sensitive-key-123456789';const fetcher=vi.fn(async()=>new Response(JSON.stringify({error:{message:`invalid ${key}`}}),{status:401})) as unknown as typeof fetch;
    try{await requestProvider(config('xai'),key,[{role:'user',content:'Hi'}],'sys',new AbortController().signal,()=>{},true,fetcher);throw new Error('expected failure');}catch(error:any){expect(error.message).toContain('ungültig');expect(error.message).not.toContain(key);}
  });
  it('erkennt API-Fehler mitten im Stream und verweigert leere Erfolge',async()=>{
    const fetcher=vi.fn(async()=>streamResponse('data: {"error":{"message":"quota exceeded"}}\n\n')) as unknown as typeof fetch;
    await expect(requestProvider(config('gemini'),'key',[{role:'user',content:'Hi'}],'sys',new AbortController().signal,()=>{},false,fetcher)).rejects.toThrow('quota exceeded');
    expect(decodeProviderEvent('gemini',{promptFeedback:{blockReason:'SAFETY'}}).error).toContain('SAFETY');
  });
});

describe('Geschützter Schlüsselspeicher (Windows-Verschlüsselung simuliert)',()=>{
  it('speichert nur Chiffretext, ersetzt und löscht einen Key',async()=>{
    const filename=path.join(temporary,'protected.json');const vault=new CredentialVault(filename,storage as any);
    await vault.set('openai:target','first-secret-123');expect(await vault.has('openai:target')).toBe(true);expect(await vault.get('openai:target')).toBe('first-secret-123');expect(await fs.readFile(filename,'utf8')).not.toContain('first-secret-123');
    await vault.set('openai:target','second-secret-456');expect(await vault.get('openai:target')).toBe('second-secret-456');await vault.delete('openai:target');expect(await vault.has('openai:target')).toBe(false);expect(await vault.get('openai:target')).toBe('');
  });
  it('verweigert unverschlüsselte Speicherung bei fehlendem Schutz',async()=>{
    const filename=path.join(temporary,'protected.json');const vault=new CredentialVault(filename,storage as any);storage.isAsyncEncryptionAvailable.mockResolvedValue(false);
    await expect(vault.set('slot','secret')).rejects.toThrow('kein unverschlüsselter');await expect(fs.stat(filename)).rejects.toThrow();
  });
  it('bindet Keys an die sichtbare Zieladresse und löscht sie beim Betreiberwechsel',async()=>{
    const {instance}=service();
    let providers=await instance.handle('ai.providers');expect(providers.find((p:any)=>p.id==='llama').baseUrl).toBe('');
    await expect(instance.handle('ai.keySet',{id:'llama',key:'secret'})).rejects.toThrow('zuerst');
    await instance.handle('ai.configure',{id:'llama',operator:'groq',model:'llama-example'});await instance.handle('ai.keySet',{id:'llama',key:'groq-key-example'});
    providers=await instance.handle('ai.providers');expect(providers.find((p:any)=>p.id==='llama').hasKey).toBe(true);expect(providers.find((p:any)=>p.id==='llama').baseUrl).toBe('https://api.groq.com/openai/v1');
    await instance.handle('ai.configure',{id:'llama',operator:'together',model:'different-model'});expect(await instance.handle('ai.keyReveal',{id:'llama'})).toBe('');
    await instance.handle('ai.configure',{id:'llama',operator:'groq',model:'llama-example'});expect(await instance.handle('ai.keyReveal',{id:'llama'})).toBe('');
    instance.dispose();
  });
});

describe('Chat-Dienst und ausdrücklicher Kontext',()=>{
  it('trennt Verläufe nach Projekt und erlaubt Löschen ohne Key',async()=>{
    const {instance,setRoot}=service();await instance.handle('ai.historySave',{messages:[{role:'user',content:'Projekt A'}]});expect((await instance.handle('ai.history'))[0].content).toBe('Projekt A');setRoot(path.join(temporary,'other'));expect(await instance.handle('ai.history')).toEqual([]);await instance.handle('ai.historySave',{messages:[{role:'assistant',content:'Projekt B'}]});await instance.handle('ai.historyClear');expect(await instance.handle('ai.history')).toEqual([]);setRoot(temporary);expect((await instance.handle('ai.history'))[0].content).toBe('Projekt A');instance.dispose();
  });
  it('verhindert verspätete Verlaufsänderungen im falschen Projekt und erhält Vorschlags-Hashes',async()=>{
    const {instance,setRoot}=service();const snapshot={path:path.join(temporary,'main.ts'),hash:'a'.repeat(64)};
    await instance.handle('ai.historySave',{root:temporary,messages:[{role:'assistant',content:'Vorschlag',id:'answer',state:'complete',contextSnapshot:[snapshot]}]});
    expect((await instance.handle('ai.history',{root:temporary}))[0].contextSnapshot).toEqual([snapshot]);
    setRoot(path.join(temporary,'other-project'));
    await expect(instance.handle('ai.historySave',{root:temporary,messages:[{role:'user',content:'verspätet'}]})).rejects.toThrow('Projekt wurde gewechselt');
    await expect(instance.handle('ai.historyClear',{root:temporary})).rejects.toThrow('Projekt wurde gewechselt');
    expect(await instance.handle('ai.history')).toEqual([]);setRoot(temporary);expect((await instance.handle('ai.history'))[0].content).toBe('Vorschlag');instance.dispose();
  });
  it('prüft Datei-Hash und Geheimnispfad vor jeder API-Anfrage',async()=>{
    const {instance}=service();await instance.handle('ai.configure',{id:'custom',model:'example',baseUrl:'https://example.test/v1'});await instance.handle('ai.keySet',{id:'custom',key:'private-custom-key'});
    const filename=path.join(temporary,'Grüße Datei.ts');await fs.writeFile(filename,'const value=1;');
    await expect(instance.handle('ai.send',{requestId:'one',provider:'custom',messages:[{role:'user',content:'Erklären'}],context:[{path:filename,content:'const value=1;',hash:'wrong'}]})).rejects.toThrow('verändert');
    await expect(instance.handle('ai.send',{requestId:'two',provider:'custom',messages:[{role:'user',content:'Erklären'}],context:[{path:path.join(temporary,'.env'),content:'secret',hash:'wrong'}]})).rejects.toThrow('Zugangsdaten');
    const fetcher=vi.fn(async(_input:any,_init:any)=>streamResponse('data: {"choices":[{"delta":{"content":"Erklärung"}}]}\n\ndata: [DONE]\n\n'));vi.stubGlobal('fetch',fetcher);
    await instance.handle('ai.send',{requestId:'three',provider:'custom',messages:[{role:'user',content:'Erklären'}],context:[{path:filename,content:'value',selection:true,hash:createHash('sha256').update('const value=1;').digest('hex')} ]});
    await vi.waitFor(()=>expect(fetcher).toHaveBeenCalledOnce());const requestBody=JSON.parse(fetcher.mock.calls[0][1].body);expect(JSON.stringify(requestBody)).toContain('value');expect(JSON.stringify(requestBody)).not.toContain('const value=1;');instance.dispose();
  });
  it('liefert ohne Key keinen erfundenen Verbindungserfolg',async()=>{
    const {instance}=service();await expect(instance.handle('ai.test',{id:'openai'})).rejects.toThrow('kein API-Key');instance.dispose();
  });
  it('blockiert private Schlüssel unabhängig vom Dateinamen',async()=>{
    const {instance}=service();await instance.handle('ai.configure',{id:'custom',model:'example',baseUrl:'https://example.test/v1'});await instance.handle('ai.keySet',{id:'custom',key:'private-custom-key'});
    const filename=path.join(temporary,'notes.txt'),content='-----BEGIN RSA PRIVATE KEY-----\nsecret\n-----END RSA PRIVATE KEY-----';await fs.writeFile(filename,content);
    const fetcher=vi.fn();vi.stubGlobal('fetch',fetcher);
    await expect(instance.handle('ai.send',{requestId:'blocked',provider:'custom',messages:[{role:'user',content:'Erklären'}],context:[{path:filename,content,hash:createHash('sha256').update(content).digest('hex')}]})).rejects.toThrow('privaten Schlüsseln');
    expect(fetcher).not.toHaveBeenCalled();instance.dispose();
  });
  it('bricht bei Projektwechsel ab und liefert keine alten Events ins neue Projekt',async()=>{
    const {instance,notify,setRoot}=service();await instance.handle('ai.configure',{id:'custom',model:'example',baseUrl:'https://example.test/v1'});await instance.handle('ai.keySet',{id:'custom',key:'private-custom-key'});
    let signal:AbortSignal|undefined;
    const fetcher=vi.fn(async(_url:any,init:any)=>new Promise<Response>((_resolve,reject)=>{signal=init.signal;signal!.addEventListener('abort',()=>reject(new DOMException('Abgebrochen','AbortError')),{once:true});}));vi.stubGlobal('fetch',fetcher);
    await instance.handle('ai.send',{requestId:'old-project',provider:'custom',messages:[{role:'user',content:'Frage'}],context:[]});
    await vi.waitFor(()=>expect(fetcher).toHaveBeenCalledOnce());setRoot(path.join(temporary,'other-project'));instance.cancelAll();
    await vi.waitFor(()=>expect(signal?.aborted).toBe(true));await new Promise(resolve=>setTimeout(resolve,10));
    expect(notify).not.toHaveBeenCalled();instance.dispose();
  });
});
