import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import * as fs from 'node:fs/promises';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
vi.mock('electron',()=>({dialog:{},shell:{}}));
import { createFileService, digest, isInside, isSensitiveFile, replaceFileWithRetry, validName } from '../electron/files';
import type { Settings, Suggestion } from '../src/shared';

const QA_ROOT=path.resolve('.qa/files-tests');
let base:string, project:string, external:string, service:ReturnType<typeof createFileService>, settings:Settings;
let openPaths:string[], savePath:string|undefined, response:number;
let nativeOpenOptions:any[],nativeMessageOptions:any[];
const notification=vi.fn();
beforeEach(async()=>{
  base=path.join(QA_ROOT,randomUUID());project=path.join(base,'Mein Projekt mit Umlauten ÄÖÜ');external=path.join(base,'Außerhalb');
  await fs.mkdir(project,{recursive:true});await fs.mkdir(external);
  settings={language:'de',theme:'dark',fontSize:14,tabSize:2,insertSpaces:true,wordWrap:false,minimap:false,sidebarWidth:300,panelHeight:220,panelVisible:true,shell:'powershell',recentProjects:[],lastProject:null,runtimePaths:{},runArgs:'',searchExcluded:[],providers:{},activeProvider:'openai'};
  openPaths=[project];response=0;savePath=undefined;nativeOpenOptions=[];nativeMessageOptions=[];notification.mockClear();
  service=createFileService({getWindow:()=>null,onProject:()=>{},notify:notification,getSettings:()=>settings,updateSettings:async patch=>{settings={...settings,...patch}},native:{open:async options=>{nativeOpenOptions.push(options);return {canceled:!openPaths.length,filePaths:openPaths}},save:async()=>({canceled:!savePath,filePath:savePath}),message:async options=>{nativeMessageOptions.push(options);return {response}},trash:async target=>{if(!isInside(base,target))throw new Error('Unexpected fixture path');await fs.rm(target,{recursive:true});}}});
  await service.handle('project.open',{});
});
afterEach(async()=>{
  service.dispose();
  const resolved=path.resolve(base);if(!isInside(QA_ROOT,resolved)||resolved===QA_ROOT)throw new Error('Refusing unsafe fixture cleanup');
  await fs.rm(resolved,{recursive:true,force:true});
});

describe('Pfadgrenzen',()=>{
  it('lokalisiert native Dialoge, bewahrt Dateinamen und liefert sprachunabhängigen Konfliktcode',async()=>{
    settings.language='en';await service.handle('project.open',{});expect(nativeOpenOptions.at(-1).title).toBe('Open project folder');
    settings.language='es';await service.handle('project.open',{});expect(nativeOpenOptions.at(-1).title).toBe('Abrir carpeta de proyecto');
    const target=path.join(project,'Speichern');await fs.writeFile(target,'old');const opened=await service.handle('fs.read',{path:target});await fs.writeFile(target,'external');
    await expect(service.handle('fs.save',{path:target,content:'mine',hash:opened.hash})).rejects.toMatchObject({code:'FILE_CONFLICT'});
    await expect(service.handle('fs.save',{path:target,content:'mine',hash:opened.hash,force:true})).rejects.toThrow('abgebrochen');
    expect(nativeMessageOptions.at(-1).title).toBe('¿Sobrescribir los cambios externos?');expect(nativeMessageOptions.at(-1).message).toBe('«Speichern» cambió fuera de CodeStudio.');expect(nativeMessageOptions.at(-1).buttons).toEqual(['Cancelar','Confirmar sobrescritura']);
    expect(await fs.readFile(target,'utf8')).toBe('external');
  });
  it('öffnet echte Ordner mit Leerzeichen und Umlauten und behält letzte Projekte',async()=>{
    expect(service.getRoot()).toBe(await fs.realpath(project));expect(settings.recentProjects).toContain(service.getRoot());
    expect(await service.handle('fs.list',{})).toEqual([]);
  });
  it('weist relative Pfade, Traversal, Gerätepfade und alternative Datenströme zurück',async()=>{
    const outside=path.join(external,'secret.txt');await fs.writeFile(outside,'secret');
    await expect(service.authorize(outside)).rejects.toThrow('außerhalb');
    await expect(service.authorize(path.join(project,'..','Außerhalb','secret.txt'))).rejects.toThrow('außerhalb');
    await expect(service.authorize('relative.txt')).rejects.toThrow('absoluter');
    await expect(service.authorize(path.join(project,'test.txt:secret'),true)).rejects.toThrow('Datenströme');
    await expect(service.authorize('\\\\?\\C:\\Windows\\test.txt',true)).rejects.toThrow();
  });
  it('weist Junctions nach außerhalb zurück und erlaubt normale Unterordner',async()=>{
    await fs.writeFile(path.join(external,'privat.txt'),'privat');
    const junction=path.join(project,'Verknüpfung');await fs.symlink(external,junction,process.platform==='win32'?'junction':'dir');
    await expect(service.authorize(path.join(junction,'privat.txt'))).rejects.toThrow('außerhalb');
    await expect(service.authorize(path.join(junction,'neu.txt'),true)).rejects.toThrow('außerhalb');
    const sub=path.join(project,'Unterordner');await fs.mkdir(sub);expect(await service.authorize(sub)).toBe(await fs.realpath(sub));
  });
  it('gibt nur explizit ausgewählte externe Dateien frei und entzieht bei Projektschluss den Zugriff',async()=>{
    const file=path.join(external,'offen.txt'),other=path.join(external,'privat.txt');await fs.writeFile(file,'offen');await fs.writeFile(other,'privat');
    openPaths=[file];const selected=await service.handle('fs.pickFiles',{});expect(selected[0].content).toBe('offen');expect(await service.authorize(file)).toBe(await fs.realpath(file));
    await expect(service.authorize(other)).rejects.toThrow('außerhalb');await service.handle('project.close',{});await expect(service.authorize(file)).rejects.toThrow('außerhalb');
  });
  it('lässt rendererübergebene unbekannte Projektpfade nicht zu',async()=>{
    await expect(service.handle('project.open',{path:external})).rejects.toThrow('Dateidialog');
    expect(service.getRoot()).toBe(await fs.realpath(project));
  });
  it.each(['..','a/b','a\\b','a:stream','CON','nul.txt','LPT1.txt','trailing.','name ','a\0b'])('verweigert Windows-Problemnamen %s',name=>{
    expect(()=>validName(name)).toThrow();
  });
});

describe('Echte Dateiverwaltung und Konflikte',()=>{
  it('wiederholt kurz gesperrtes atomisches Ersetzen und prüft vor jedem Versuch erneut den Dateistand',async()=>{
    const verify=vi.fn(async()=>{}),pause=vi.fn(async()=>{});let attempts=0;
    const rename=vi.fn(async()=>{attempts++;if(attempts<3)throw Object.assign(new Error('locked'),{code:'EPERM'});});
    await replaceFileWithRetry('quelle.tmp','ziel.txt',verify,rename,pause);
    expect(rename).toHaveBeenCalledTimes(3);expect(verify).toHaveBeenCalledTimes(3);expect(pause).toHaveBeenCalledTimes(2);
  });
  it('bricht Sperrwiederholung bei zwischenzeitlichem Dateikonflikt ab und löscht kein Ziel',async()=>{
    let checks=0;const verify=vi.fn(async()=>{if(++checks===2)throw new Error('Dateikonflikt');});
    const rename=vi.fn(async()=>{throw Object.assign(new Error('locked'),{code:'EBUSY'});});
    await expect(replaceFileWithRetry('quelle.tmp','ziel.txt',verify,rename,async()=>{})).rejects.toThrow('Dateikonflikt');expect(rename).toHaveBeenCalledTimes(1);
  });
  it('begrenzt wiederholte Sperren und nennt die betroffene Datei ohne Löschersatz',async()=>{
    const rename=vi.fn(async()=>{throw Object.assign(new Error('locked'),{code:'EACCES'});});
    await expect(replaceFileWithRetry('quelle.tmp','Grüße.ts',async()=>{},rename,async()=>{})).rejects.toThrow('„Grüße.ts“ konnte nicht gespeichert werden (EACCES)');expect(rename).toHaveBeenCalledTimes(7);
  });
  it('erstellt, bearbeitet, speichert, benennt um und verschiebt verschachtelte Dateien',async()=>{
    const folder=await service.handle('fs.create',{name:'Unterordner Ö',directory:true});
    const created=await service.handle('fs.create',{parent:folder.path,name:'Grüße.ts',directory:false});
    const original=await service.handle('fs.read',{path:created.path});
    const saved=await service.handle('fs.save',{path:created.path,content:'console.log("Hallo");\r\n',hash:original.hash});
    expect(saved.content).toContain('Hallo');expect(saved.eol).toBe('CRLF');
    const renamed=await service.handle('fs.rename',{path:saved.path,name:'Neu.ts'});expect(await fs.readFile(renamed.path,'utf8')).toBe(saved.content);
    const moved=await service.handle('fs.move',{path:renamed.path,destination:path.join(project,'Verschoben.ts')});
    expect(moved.path).toBe(path.join(await fs.realpath(project),'Verschoben.ts'));expect((await service.handle('fs.list',{})).map((x:any)=>x.name)).toContain('Verschoben.ts');
  });
  it('überschreibt beim Erstellen oder Umbenennen keine vorhandene Datei',async()=>{
    const one=path.join(project,'eins.txt'),two=path.join(project,'zwei.txt');await fs.writeFile(one,'eins');await fs.writeFile(two,'zwei');
    await expect(service.handle('fs.create',{parent:project,name:'eins.txt'})).rejects.toThrow();
    await expect(service.handle('fs.rename',{path:one,name:'zwei.txt'})).rejects.toThrow('existiert');
    expect(await fs.readFile(one,'utf8')).toBe('eins');expect(await fs.readFile(two,'utf8')).toBe('zwei');
  });
  it('erkennt externe Änderung vor Speichern und benötigt auch bei force native Zustimmung',async()=>{
    const file=path.join(project,'konflikt.txt');await fs.writeFile(file,'alt');const opened=await service.handle('fs.read',{path:file});await fs.writeFile(file,'extern');
    await expect(service.handle('fs.save',{path:file,content:'mein Entwurf',hash:opened.hash})).rejects.toThrow('Dateikonflikt');
    await expect(service.handle('fs.save',{path:file,content:'mein Entwurf',hash:opened.hash,force:true})).rejects.toThrow('abgebrochen');expect(await fs.readFile(file,'utf8')).toBe('extern');
    response=1;await service.handle('fs.save',{path:file,content:'mein Entwurf',hash:opened.hash,force:true});expect(await fs.readFile(file,'utf8')).toBe('mein Entwurf');
  });
  it('serialisiert konkurrierende Speichervorgänge und weist veralteten Dateistand zurück',async()=>{
    const file=path.join(project,'parallel.txt');await fs.writeFile(file,'alt');const opened=await service.handle('fs.read',{path:file});
    const results=await Promise.allSettled([service.handle('fs.save',{path:file,content:'neu 1',hash:opened.hash}),service.handle('fs.save',{path:file,content:'neu 2',hash:opened.hash})]);
    expect(results.map(x=>x.status)).toEqual(['fulfilled','rejected']);expect(await fs.readFile(file,'utf8')).toBe('neu 1');
  });
  it('gibt Speichern unter nur für die ausgewählte externe Datei frei',async()=>{
    savePath=path.join(external,'gespeichert.md');const saved=await service.handle('fs.saveAs',{content:'# Hallo'});expect(saved.path).toBe(savePath);expect(await fs.readFile(savePath,'utf8')).toBe('# Hallo');
    const changed=await service.handle('fs.save',{path:savePath,content:'# Neu',hash:saved.hash});expect(changed.content).toBe('# Neu');await expect(service.authorize(path.join(external,'noch.md'),true)).rejects.toThrow('außerhalb');
  });
  it('erhält UTF-16 BOM beim gewöhnlichen Speichern',async()=>{
    const file=path.join(project,'utf16.txt');await fs.writeFile(file,Buffer.concat([Buffer.from([0xff,0xfe]),Buffer.from('ÄÖÜ\r\n','utf16le')]));
    const opened=await service.handle('fs.read',{path:file});expect(opened.encoding).toBe('UTF-16 LE');expect(opened.content).toBe('ÄÖÜ\r\n');
    await service.handle('fs.save',{path:file,content:'Überarbeitet\r\n',hash:opened.hash});const bytes=await fs.readFile(file);expect(bytes.subarray(0,2)).toEqual(Buffer.from([0xff,0xfe]));expect(bytes.subarray(2).toString('utf16le')).toBe('Überarbeitet\r\n');
  });
  it('verweigert Binärdateien und defektes UTF-8 verständlich',async()=>{
    const binary=path.join(project,'bild.bin'),invalid=path.join(project,'kaputt.txt');await fs.writeFile(binary,Buffer.from([1,0,2]));await fs.writeFile(invalid,Buffer.from([0xc3,0x28]));
    await expect(service.handle('fs.read',{path:binary})).rejects.toThrow('Binärdaten');await expect(service.handle('fs.read',{path:invalid})).rejects.toThrow('UTF-8');
  });
  it('weist zu große Dateien vor dem Einlesen ab',async()=>{
    const file=path.join(project,'zu-groß.txt');const handle=await fs.open(file,'wx');await handle.truncate(8*1024*1024+1);await handle.close();
    await expect(service.handle('fs.read',{path:file})).rejects.toThrow('8 MiB');
  });
  it('bestätigt Papierkorbaktion und meldet Änderungen',async()=>{
    const file=path.join(project,'löschen.txt');await fs.writeFile(file,'x');expect(await service.handle('fs.trash',{path:file})).toBe(false);expect(await fs.readFile(file,'utf8')).toBe('x');
    response=1;expect(await service.handle('fs.trash',{path:file})).toBe(true);await expect(fs.stat(file)).rejects.toThrow();expect(notification).toHaveBeenCalledWith('fs.changed',expect.objectContaining({path:file,kind:'rename'}));
  });
});

describe('Suche und freigegebener KI-Kontext',()=>{
  it('sucht echte Dateien und Text, lässt node_modules, Binärdaten und Zugangsdaten aus',async()=>{
    await fs.mkdir(path.join(project,'node_modules'));await fs.writeFile(path.join(project,'node_modules','intern.js'),'suchwort');await fs.writeFile(path.join(project,'.env'),'suchwort');await fs.writeFile(path.join(project,'main.ts'),'erste Zeile\nsuchwort ÄÖÜ\n');await fs.writeFile(path.join(project,'bin.bin'),Buffer.from([0,1,2]));
    const found=await service.handle('fs.search',{query:'suchwort'});expect(found.results).toHaveLength(1);expect(found.results[0].line).toBe(2);expect(found.results[0].path).toBe(path.join(project,'main.ts'));
    const files=await service.handle('fs.search',{query:'main',filesOnly:true});expect(files.results).toHaveLength(1);
  });
  it('zeigt bei leerer Schnellöffnen-Abfrage die begrenzte Dateiliste und verweigert leere Textsuche',async()=>{
    await fs.writeFile(path.join(project,'sichtbar.ts'),'export {};');
    const files=await service.handle('fs.search',{query:'',filesOnly:true});expect(files.results.map((r:any)=>r.text)).toContain('sichtbar.ts');
    await expect(service.handle('fs.search',{query:''})).rejects.toThrow('Suchanfrage');
  });
  it('prüft Kontextpfade, Schlüsseldateien und Gesamtgröße',async()=>{
    const allowed=path.join(project,'main.ts');await fs.writeFile(allowed,'const x = 1;');const context=await service.handle('fs.context',{paths:[allowed]});expect(context[0].hash).toBe(digest('const x = 1;'));
    const env=path.join(project,'.env.local');await fs.writeFile(env,'API_KEY=secret');await expect(service.handle('fs.context',{paths:[env]})).rejects.toThrow('ausgeschlossen');
    const huge=path.join(project,'groß.txt');await fs.writeFile(huge,'x'.repeat(160001));await expect(service.handle('fs.context',{paths:[huge]})).rejects.toThrow('zu groß');
  });
  it('blockiert private Schlüssel auch unter unauffälligen Dateinamen',async()=>{
    const file=path.join(project,'notizen.txt');await fs.writeFile(file,'-----BEGIN RSA PRIVATE KEY-----\nprivate\n-----END RSA PRIVATE KEY-----');
    await expect(service.handle('fs.context',{paths:[file]})).rejects.toThrow('privaten Schlüssel');
    await expect(service.handle('fs.propose',{path:file,after:'neu'})).rejects.toThrow('privaten Schlüsseln');
  });
  it.each(['.env','.env.production','id_rsa','privat.pem','credentials.json','secret.key','x/.ssh/config'])('erkennt sensible Datei %s',name=>expect(isSensitiveFile(name)).toBe(true));
});

describe('KI-Dateivorschläge und Rückgängig',()=>{
  it('übernimmt einen Vorschlag und stellt Originalbytes wieder her',async()=>{
    const file=path.join(project,'main.ts');await fs.writeFile(file,'const x = 1;');const proposal:Suggestion=await service.handle('fs.propose',{path:'main.ts',after:'const x = 2;'});expect(proposal.before).toBe('const x = 1;');
    const applied=await service.handle('fs.apply',{ids:[proposal.id]});expect(applied[0].content).toBe('const x = 2;');expect(await fs.readFile(file,'utf8')).toBe('const x = 2;');
    await service.handle('fs.undo',{});expect(await fs.readFile(file,'utf8')).toBe('const x = 1;');
  });
  it('nimmt neue Dateien beim Rückgängigmachen wieder weg',async()=>{
    const proposal=await service.handle('fs.propose',{path:'neu.ts',after:'export const x = 1;'});expect(proposal.hash).toBeNull();await service.handle('fs.apply',{ids:[proposal.id]});
    const reverted=await service.handle('fs.undo',{});expect(reverted[0].hash).toBe('');await expect(fs.stat(path.join(project,'neu.ts'))).rejects.toThrow();
  });
  it('prüft alle Vorschläge vor gemeinsamer Übernahme und bewahrt Zwischenänderungen',async()=>{
    const one=path.join(project,'eins.txt'),two=path.join(project,'zwei.txt');await fs.writeFile(one,'alt 1');await fs.writeFile(two,'alt 2');
    const first=await service.handle('fs.propose',{path:one,after:'KI 1'}),second=await service.handle('fs.propose',{path:two,after:'KI 2'});await fs.writeFile(two,'extern');
    await expect(service.handle('fs.apply',{ids:[first.id,second.id]})).rejects.toThrow('Dateikonflikt');expect(await fs.readFile(one,'utf8')).toBe('alt 1');expect(await fs.readFile(two,'utf8')).toBe('extern');
  });
  it('verhindert Rückgängig über neue Änderungen und lehnt veralteten expliziten Hash ab',async()=>{
    const file=path.join(project,'stand.txt');await fs.writeFile(file,'alt');await expect(service.handle('fs.propose',{path:file,after:'KI',hash:digest('falsch')})).rejects.toThrow('Dateikonflikt');
    const proposal=await service.handle('fs.propose',{path:file,after:'KI'});await service.handle('fs.apply',{ids:[proposal.id]});await fs.writeFile(file,'manuell');await expect(service.handle('fs.undo',{})).rejects.toThrow('Dateikonflikt');expect(await fs.readFile(file,'utf8')).toBe('manuell');
  });
});
