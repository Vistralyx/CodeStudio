import { promises as fs } from 'node:fs';
import path from 'node:path';
import type { Settings } from '../src/shared';
export const defaults:Settings={language:'en',theme:'dark',fontSize:14,tabSize:2,insertSpaces:true,wordWrap:false,minimap:false,sidebarWidth:290,panelHeight:220,panelVisible:true,shell:'powershell',recentProjects:[],lastProject:null,runtimePaths:{},runArgs:'',searchExcluded:['node_modules','.git','dist','build','target','.gradle','.venv','venv'],providers:{openai:{model:''},xai:{model:''},anthropic:{model:''},gemini:{model:''},llama:{model:''},custom:{model:'',baseUrl:''}},activeProvider:'openai'};
export function cleanSettings(raw:unknown):Settings {
  const value=raw && typeof raw==='object'?raw as Record<string,any>:{};
  const out:Settings=structuredClone(defaults);
  if(['en','de','es','fr','it'].includes(value.language))out.language=value.language;
  if(value.theme==='light'||value.theme==='dark')out.theme=value.theme;
  for(const [key,min,max] of [['fontSize',10,32],['tabSize',1,8],['sidebarWidth',220,700],['panelHeight',100,700]] as const)if(Number.isFinite(value[key]))out[key]=Math.round(Math.min(max,Math.max(min,value[key])));
  for(const key of ['insertSpaces','wordWrap','minimap','panelVisible'] as const)if(typeof value[key]==='boolean')out[key]=value[key];
  if(value.shell==='cmd'||value.shell==='powershell')out.shell=value.shell;
  if(Array.isArray(value.recentProjects))out.recentProjects=value.recentProjects.filter((x:any)=>typeof x==='string'&&x.length<32768).slice(0,12);
  if(typeof value.lastProject==='string'&&out.recentProjects.includes(value.lastProject))out.lastProject=value.lastProject;
  if(typeof value.runArgs==='string')out.runArgs=value.runArgs.slice(0,8192);
  if(Array.isArray(value.searchExcluded))out.searchExcluded=value.searchExcluded.filter((x:any)=>typeof x==='string'&&x.length<100).slice(0,100);
  if(value.runtimePaths&&typeof value.runtimePaths==='object')for(const [id,p] of Object.entries(value.runtimePaths))if(['node','python','java','javac','kotlinc','mvn','gradle'].includes(id)&&typeof p==='string')out.runtimePaths[id]=p.slice(0,32768);
  if(value.providers&&typeof value.providers==='object')for(const id of Object.keys(out.providers)) {
    const p=value.providers[id]; if(p&&typeof p==='object')out.providers[id]={model:typeof p.model==='string'?p.model.slice(0,200):'',...(typeof p.baseUrl==='string'?{baseUrl:p.baseUrl.slice(0,2000)}:{}),...(typeof p.operator==='string'?{operator:p.operator.slice(0,100)}:{})};
  }
  if(Object.keys(out.providers).includes(value.activeProvider))out.activeProvider=value.activeProvider;
  const b=value.windowBounds;if(b&&Number.isFinite(b.width)&&Number.isFinite(b.height))out.windowBounds={width:Math.max(850,Math.min(3840,b.width)),height:Math.max(600,Math.min(2160,b.height)),...(Number.isFinite(b.x)?{x:b.x}:{}),...(Number.isFinite(b.y)?{y:b.y}:{})};
  return out;
}
export async function createSettingsStore(dataDir:string) {
  await fs.mkdir(dataDir,{recursive:true}); const target=path.join(dataDir,'settings.json'); let settings:Settings;
  try{settings=cleanSettings(JSON.parse(await fs.readFile(target,'utf8')))}catch{settings=structuredClone(defaults)}
  let pending=Promise.resolve();
  return {get:()=>structuredClone(settings),update:async(patch:Partial<Settings>)=>{
    settings=cleanSettings({...settings,...patch}); const snapshot=JSON.stringify(settings,null,2);
    pending=pending.catch(()=>{}).then(async()=>{const tmp=target+'.tmp';await fs.writeFile(tmp,snapshot,'utf8');await fs.rename(tmp,target)});await pending;return structuredClone(settings);
  }};
}
