import { contextBridge, ipcRenderer } from "electron";
import { translate } from "../src/i18n";
import type { Locale } from "../src/shared";
let language: Locale = "en";
const allowed = new Set([
  "app.bootstrap",
  "app.settings",
  "app.menu",
  "app.close",
  "app.about",
  "app.openHelp",
  "app.openExternal",
  "app.confirm",
  "app.unsaved",
  "project.open",
  "project.create",
  "project.close",
  "project.current",
  "fs.list",
  "fs.read",
  "fs.save",
  "fs.saveAs",
  "fs.create",
  "fs.rename",
  "fs.move",
  "fs.trash",
  "fs.search",
  "fs.pickFiles",
  "fs.context",
  "fs.propose",
  "fs.apply",
  "fs.undo",
  "runtime.list",
  "runtime.pick",
  "terminal.create",
  "terminal.write",
  "terminal.resize",
  "terminal.close",
  "terminal.interrupt",
  "run.start",
  "run.stop",
  "run.tasks",
  "preview.refresh",
  "ai.providers",
  "ai.configure",
  "ai.keySet",
  "ai.keyDelete",
  "ai.keyReveal",
  "ai.models",
  "ai.test",
  "ai.send",
  "ai.cancel",
  "ai.history",
  "ai.historySave",
  "ai.historyClear",
]);
allowed.add("terminal.buffer");
allowed.add("preview.close");
allowed.add("app.clipboardRead");
allowed.add("app.clipboardWrite");
allowed.add("app.restart");
const events = new Set([
  "app.closeRequested",
  "menu.action",
  "project.changed",
  "fs.changed",
  "fs.watchError",
  "terminal.data",
  "terminal.exit",
  "run.output",
  "run.exit",
  "preview.updated",
  "ai.delta",
  "ai.done",
  "ai.error",
]);
contextBridge.exposeInMainWorld(
  "studio",
  Object.freeze({
    invoke: async (command: string, args: unknown) => {
      if (!allowed.has(command))
        throw new Error(translate(language, "Unbekannte Aktion."));
      const reply = await ipcRenderer.invoke("studio:invoke", command, args);
      if (!reply.ok) {
        // ContextBridge does not guarantee custom Error properties. Keep the
        // machine-readable conflict code in a stable prefix as well.
        const error = new Error(
          reply.code ? `[${reply.code}] ${reply.error}` : reply.error,
        );
        Object.assign(error, { code: reply.code });
        throw error;
      }
      if (command === "app.bootstrap") language = reply.value.settings.language;
      return reply.value;
    },
    on: (event: string, callback: (data: unknown) => void) => {
      if (!events.has(event) || typeof callback !== "function")
        throw new Error(translate(language, "Unbekanntes Ereignis."));
      const listener = (_e: unknown, data: unknown) => callback(data);
      ipcRenderer.on(event, listener);
      return () => ipcRenderer.removeListener(event, listener);
    },
  }),
);
