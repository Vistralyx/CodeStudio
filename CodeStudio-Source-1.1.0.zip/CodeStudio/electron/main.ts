import {
  app,
  BrowserWindow,
  ipcMain,
  dialog,
  Menu,
  nativeTheme,
  shell,
  screen,
  clipboard,
} from "electron";
import path from "node:path";
import { pathToFileURL } from "node:url";
import { createSettingsStore } from "./settings";
import { createFileService } from "./files";
import { createRuntimeService } from "./runtime";
import { createAIService } from "./ai";
import { languages, localizeMessage, translate } from "../src/i18n";
import type { Locale } from "../src/shared";

app.setName("CodeStudio");
const profile = process.env.CODESTUDIO_TEST_DATA;
if (profile && path.isAbsolute(profile)) app.setPath("userData", profile);
const dev = !app.isPackaged && process.env.CODESTUDIO_DEV === "1";
let win: BrowserWindow | null = null;
let mayClose = false;
let closing = false;
const notify = (event: string, data: any) => {
  if (win && !win.isDestroyed()) win.webContents.send(event, data);
};
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) app.quit();
else
  app.whenReady().then(async () => {
    const store = await createSettingsStore(app.getPath("userData"));
    const ui = (message: string) =>
      localizeMessage(store.get().language, message);
    const tr = (message: string, params?: Record<string, string | number>) =>
      translate(store.get().language, message, params);
    const messageBox = (options: Electron.MessageBoxOptions) =>
      dialog.showMessageBox(win!, {
        ...options,
        title: options.title ? ui(options.title) : undefined,
        message: ui(options.message),
        detail: options.detail ? ui(options.detail) : undefined,
        buttons: options.buttons?.map(ui),
      });
    nativeTheme.themeSource = store.get().theme;
    let ai: ReturnType<typeof createAIService> | undefined;
    const files = createFileService({
      getWindow: () => win,
      notify,
      getSettings: store.get,
      updateSettings: store.update,
      onProject: (root) => {
        ai?.cancelAll();
        notify("project.changed", { root });
      },
    });
    const runtime = createRuntimeService({
      getWindow: () => win,
      notify,
      authorize: files.authorize,
      getRoot: files.getRoot,
      getSettings: store.get,
      updateSettings: store.update,
    });
    ai = createAIService({
      getSettings: store.get,
      updateSettings: store.update,
      dataDir: app.getPath("userData"),
      notify,
      getRoot: files.getRoot,
      authorize: files.authorize,
    });
    const url = dev
      ? "http://127.0.0.1:5178/"
      : pathToFileURL(path.join(__dirname, "../dist/index.html")).href;
    let bounds = store.get().windowBounds;
    if (
      bounds &&
      bounds.x !== undefined &&
      bounds.y !== undefined &&
      !screen
        .getAllDisplays()
        .some(
          (d) =>
            bounds!.x! + 100 > d.workArea.x &&
            bounds!.x! < d.workArea.x + d.workArea.width - 100 &&
            bounds!.y! + 50 > d.workArea.y &&
            bounds!.y! < d.workArea.y + d.workArea.height - 50,
        )
    )
      bounds = { width: bounds.width, height: bounds.height };
    win = new BrowserWindow({
      width: bounds?.width ?? 1380,
      height: bounds?.height ?? 900,
      ...(bounds?.x !== undefined ? { x: bounds.x, y: bounds.y } : {}),
      minWidth: 850,
      minHeight: 600,
      show: false,
      title: "CodeStudio",
      backgroundColor: store.get().theme === "dark" ? "#111315" : "#fafafa",
      autoHideMenuBar: true,
      webPreferences: {
        preload: path.join(__dirname, "preload.cjs"),
        contextIsolation: true,
        nodeIntegration: false,
        sandbox: true,
        webSecurity: true,
        allowRunningInsecureContent: false,
        spellcheck: false,
      },
    });
    Menu.setApplicationMenu(null);
    win.webContents.setWindowOpenHandler(() => ({ action: "deny" }));
    win.webContents.on("will-navigate", (event, target) => {
      if (target !== url) event.preventDefault();
    });
    win.webContents.on("will-attach-webview", (event) =>
      event.preventDefault(),
    );
    win.webContents.session.setPermissionRequestHandler(
      (_wc, _permission, callback) => callback(false),
    );
    win.webContents.session.setPermissionCheckHandler(() => false);
    const menus: Record<string, any[]> = {
      Datei: [
        ["Neue Datei", "new", "Ctrl+N"],
        ["Datei öffnen …", "open-file", "Ctrl+O"],
        ["Projekt öffnen …", "open-project", "Ctrl+K"],
        ["Neues Projekt …", "new-project"],
        ["Projekt schließen", "close-project"],
        null,
        ["Speichern", "save", "Ctrl+S"],
        ["Speichern unter …", "save-as", "Ctrl+Shift+S"],
        ["Alle speichern", "save-all"],
        null,
        ["Beenden", "quit", "Alt+F4"],
      ],
      Bearbeiten: [
        ["Rückgängig", "undo", "Ctrl+Z"],
        ["Wiederholen", "redo", "Ctrl+Y"],
        null,
        ["Ausschneiden", "cut", "Ctrl+X"],
        ["Kopieren", "copy", "Ctrl+C"],
        ["Einfügen", "paste", "Ctrl+V"],
        null,
        ["Suchen", "find", "Ctrl+F"],
        ["Ersetzen", "replace", "Ctrl+H"],
        ["Kommentar umschalten", "comment", "Ctrl+/"],
        ["Dokument formatieren", "format", "Shift+Alt+F"],
      ],
      Auswahl: [
        ["Alles auswählen", "select-all", "Ctrl+A"],
        ["Nächstes Vorkommen hinzufügen", "multi-cursor", "Ctrl+D"],
        ["Zeile duplizieren", "duplicate"],
        ["Alle Vorkommen auswählen", "select-occurrences"],
      ],
      Ansicht: [
        ["Explorer", "explorer"],
        ["Projektsuche", "search", "Ctrl+Shift+F"],
        ["KI-Assistent", "chat"],
        ["Seitenleiste ein/aus", "toggle-sidebar", "Ctrl+B"],
        ["Unterer Bereich ein/aus", "toggle-panel", "Ctrl+J"],
        ["Zeilenumbruch", "word-wrap", "Alt+Z"],
        ["Minimap", "minimap"],
        ["Theme wechseln", "theme"],
        ["Einstellungen", "settings", "Ctrl+,"],
      ],
      Ausführen: [
        ["Aktive Datei ausführen", "run", "F5"],
        ["Stoppen", "stop", "Shift+F5"],
        ["Projektaufgaben …", "tasks"],
      ],
      Terminal: [
        ["Neues PowerShell-Terminal", "terminal"],
        ["Neues cmd-Terminal", "terminal-cmd"],
        ["Aktiven Prozess abbrechen", "interrupt"],
      ],
      Hilfe: [
        ["Bedienungsanleitung", "help"],
        ["Sprachunterstützung", "languages"],
        ["Über CodeStudio", "about"],
      ],
    };
    ipcMain.handle("studio:invoke", async (event, command, args) => {
      try {
        if (
          !win ||
          event.sender !== win.webContents ||
          event.senderFrame !== win.webContents.mainFrame ||
          event.senderFrame.url !== url
        )
          throw new Error("Zugriff verweigert.");
        if (typeof command !== "string" || command.length > 80)
          throw new Error("Ungültige Aktion.");
        const size =
          args === undefined ? 0 : Buffer.byteLength(JSON.stringify(args));
        if (size > 16 * 1024 * 1024)
          throw new Error("Die Anfrage ist zu groß.");
        let value: any;
        if (command === "app.bootstrap")
          value = {
            settings: store.get(),
            version: app.getVersion(),
            platform: process.platform,
          };
        else if (command === "app.settings") {
          if (!args || typeof args !== "object" || Array.isArray(args))
            throw new Error("Ungültige Einstellungen.");
          const allowed = [
            "theme",
            "fontSize",
            "tabSize",
            "insertSpaces",
            "wordWrap",
            "minimap",
            "sidebarWidth",
            "panelHeight",
            "panelVisible",
            "shell",
            "runArgs",
            "searchExcluded",
            "activeProvider",
          ];
          const patch = Object.fromEntries(
            Object.entries(args).filter(([k]) => allowed.includes(k)),
          );
          value = await store.update(patch);
          nativeTheme.themeSource = value.theme;
        } else if (command === "app.menu") {
          const menuKey = Object.keys(menus).find(
            (key) => key === args?.name || ui(key) === args?.name,
          );
          const items = menuKey ? menus[menuKey] : undefined;
          if (!items) throw new Error("Unbekanntes Menü.");
          Menu.buildFromTemplate(
            items.map((item) =>
              item
                ? {
                    label: ui(item[0]),
                    accelerator: item[2],
                    click: () => notify("menu.action", item[1]),
                  }
                : { type: "separator" },
            ),
          ).popup({
            window: win,
            x: Math.max(0, Math.round(args.x || 0)),
            y: Math.max(0, Math.round(args.y || 30)),
          });
        } else if (command === "app.unsaved") {
          const result = await messageBox({
            type: "warning",
            title: "Ungespeicherte Änderungen",
            message: `„${String(args?.name || "Datei").slice(0, 500)}“ wurde geändert.`,
            detail: "Möchten Sie die Änderungen vor dem Schließen speichern?",
            buttons: ["Speichern", "Verwerfen", "Abbrechen"],
            defaultId: 0,
            cancelId: 2,
            noLink: true,
          });
          value = ["save", "discard", "cancel"][result.response];
        } else if (command === "app.confirm") {
          const r = await messageBox({
            type: "question",
            title: "CodeStudio",
            message: String(args?.message || "Fortfahren?").slice(0, 2000),
            detail: String(args?.detail || "").slice(0, 4000),
            buttons: ["Fortfahren", "Abbrechen"],
            defaultId: 1,
            cancelId: 1,
            noLink: true,
          });
          value = r.response === 0;
        } else if (command === "app.restart") {
          if (
            typeof args?.language !== "string" ||
            !languages.some((language) => language.id === args.language)
          )
            throw new Error("Ungültige Sprache.");
          await store.update({ language: args.language as Locale });
          ai?.cancelAll();
          app.relaunch();
          mayClose = true;
          setTimeout(() => win?.close(), 50);
          value = true;
        } else if (command === "app.close") {
          mayClose = true;
          win.close();
        } else if (command === "app.clipboardRead") {
          value = clipboard.readText();
        } else if (command === "app.clipboardWrite") {
          if (
            typeof args?.text !== "string" ||
            args.text.length > 8 * 1024 * 1024
          )
            throw new Error("Der Zwischenablagetext ist ungültig.");
          clipboard.writeText(args.text);
        } else if (command === "app.about") {
          await messageBox({
            type: "info",
            title: "Über CodeStudio",
            message: `CodeStudio ${app.getVersion()}`,
            detail: [
              tr("Lokaler Code-Editor"),
              tr("Lizenz: MIT"),
              `Electron ${process.versions.electron} · Chromium ${process.versions.chrome}`,
              tr("Windows x64 · Setup ohne Herausgebersignatur"),
              tr(
                "KI ist optional. Lokale Programme laufen mit Ihren Benutzerrechten.",
              ),
            ].join("\n"),
          });
        } else if (command === "app.openExternal") {
          const target = String(args?.url || "");
          const parsed = new URL(target);
          if (
            !["https:", "http:"].includes(parsed.protocol) ||
            parsed.username ||
            parsed.password
          )
            throw new Error("Diese Adresse ist nicht erlaubt.");
          if (
            await messageBox({
              type: "question",
              message: "Link im Standardbrowser öffnen?",
              detail: target,
              buttons: ["Öffnen", "Abbrechen"],
              cancelId: 1,
              defaultId: 1,
            }).then((r) => r.response === 0)
          )
            await shell.openExternal(target);
        } else if (
          command.startsWith("project.") ||
          command.startsWith("fs.")
        ) {
          value = await files.handle(command, args || {});
          if (
            ["project.open", "project.create", "project.close"].includes(
              command,
            ) &&
            (value !== null || command === "project.close")
          )
            await runtime.dispose();
          if (["fs.save", "fs.saveAs", "fs.apply", "fs.undo"].includes(command))
            await runtime.handle("preview.refresh", {}).catch(() => {});
        } else if (
          command.startsWith("runtime.") ||
          command.startsWith("terminal.") ||
          command.startsWith("run.") ||
          command === "preview.refresh" ||
          command === "preview.close"
        )
          value = await runtime.handle(command, args || {});
        else if (command.startsWith("ai."))
          value = await ai!.handle(command, args || {});
        else throw new Error("Unbekannte Aktion.");
        return { ok: true, value };
      } catch (error) {
        const message =
          error instanceof Error
            ? error.message
            : "Die Aktion konnte nicht ausgeführt werden.";
        const code =
          (error as { code?: string })?.code === "FILE_CONFLICT" ||
          message.startsWith("Dateikonflikt")
            ? "FILE_CONFLICT"
            : undefined;
        return { ok: false, error: ui(message).slice(0, 3000), code };
      }
    });
    win.on("close", (event) => {
      if (!mayClose) {
        event.preventDefault();
        notify("app.closeRequested", {});
      } else if (!closing) {
        event.preventDefault();
        closing = true;
        (async () => {
          if (win) await store.update({ windowBounds: win.getBounds() });
          files.dispose();
          ai?.dispose();
          await runtime.dispose();
          win?.destroy();
          app.quit();
        })().catch(() => {
          win?.destroy();
          app.quit();
        });
      }
    });
    win.once("ready-to-show", () => {
      if (!(profile && process.env.CODESTUDIO_BACKGROUND_TEST === "1"))
        win?.show();
    });
    await win.loadURL(url);
    if (process.env.CODESTUDIO_DEBUG === "1" && !app.isPackaged)
      win.webContents.openDevTools({ mode: "detach" });
  });
app.on("second-instance", () => {
  if (win) {
    if (win.isMinimized()) win.restore();
    win.show();
    win.focus();
  }
});
app.on("window-all-closed", () => app.quit());
