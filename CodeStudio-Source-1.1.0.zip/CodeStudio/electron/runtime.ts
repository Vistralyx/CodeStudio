import { spawn as spawnChild, type ChildProcess } from 'node:child_process';
import { promises as fs, watch, type FSWatcher } from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import http from 'node:http';
import { randomUUID } from 'node:crypto';
import { createRequire } from 'node:module';
import type { BrowserWindow } from 'electron';
import type { Settings } from '../src/shared';
import type { IPty } from 'node-pty';
import {localizeMessage,translate,type Locale} from '../src/i18n';

type RuntimeId = 'node' | 'python' | 'java' | 'javac' | 'kotlinc' | 'mvn' | 'gradle';
interface RuntimeInfo { id: RuntimeId; label: string; path: string; available: boolean; version: string; versionMessage?:boolean }
interface Command { file: string; args: string[] }
interface Session { id: string; title: string; pty: IPty; run: boolean; buffer: string; sequence: number; exitCode?: number; temp?: string; stopped?: boolean; exiting?: boolean }
interface Deps {
  getWindow: () => BrowserWindow | null;
  notify: (event: string, data: any) => void;
  authorize: (file: string, allowMissing?: boolean) => Promise<string>;
  getRoot: () => string | null;
  getSettings: () => Settings;
  updateSettings: (patch: Partial<Settings>) => Promise<any>;
}

const definitions: {id: RuntimeId; label: string; candidates: string[]; version: string[]}[] = [
  {id:'node',label:'Node.js',candidates:['node.exe','node'],version:['--version']},
  {id:'python',label:'Python',candidates:['python.exe','python3.exe','python3','python'],version:['--version']},
  {id:'java',label:'Java-Laufzeit',candidates:['java.exe','java'],version:['-version']},
  {id:'javac',label:'Java-Compiler (JDK)',candidates:['javac.exe','javac'],version:['-version']},
  {id:'kotlinc',label:'Kotlin-Compiler',candidates:['kotlinc.bat','kotlinc.cmd','kotlinc'],version:['-version']},
  {id:'mvn',label:'Maven',candidates:['mvn.cmd','mvn.bat','mvn'],version:['--version']},
  {id:'gradle',label:'Gradle',candidates:['gradle.bat','gradle.cmd','gradle'],version:['--version']},
];

/** Only OS / toolchain variables are inherited. App/API credentials never enter user processes. */
export function cleanEnvironment(source: NodeJS.ProcessEnv = process.env): Record<string,string> {
  const allowed = new Set(['path','pathext','systemroot','windir','comspec','temp','tmp','userprofile','homedrive','homepath','username','userdomain','appdata','localappdata','programfiles','programfiles(x86)','programw6432','commonprogramfiles','commonprogramfiles(x86)','java_home','jdk_home','pythonhome','pythonpath','lang','lc_all','number_of_processors','processor_architecture','os','public','allusersprofile']);
  const result: Record<string,string> = {};
  for (const [key,value] of Object.entries(source)) if (value !== undefined && allowed.has(key.toLowerCase())) result[key] = value;
  result.TERM = 'xterm-256color'; result.COLORTERM = 'truecolor'; result.PYTHONUNBUFFERED = '1';
  return result;
}

/** Small argument parser: quoted strings are one argument; it never interprets shell expressions. */
export function parseArguments(value: unknown): string[] {
  if (value === undefined || value === '') return [];
  if (typeof value !== 'string' || value.length > 16_384 || /[\0\r\n]/.test(value)) throw new Error('Ungültige Programmargumente.');
  const result: string[] = []; let current = ''; let quote: string | null = null; let started = false;
  for (let i=0; i<value.length; i++) {
    const ch=value[i];
    if (ch==='"' || ch==="'") {
      if (!quote) {quote=ch; started=true; continue;}
      if (quote===ch) {quote=null; continue;}
    }
    if (ch==='\\' && value[i+1] === quote && quote) {current+=quote; i++; started=true; continue;}
    if (/\s/.test(ch) && !quote) {if(started){result.push(current);current='';started=false;} continue;}
    current+=ch; started=true;
  }
  if(quote) throw new Error('Ein Anführungszeichen in den Programmargumenten ist nicht geschlossen.');
  if(started) result.push(current);
  if(result.length>256) throw new Error('Zu viele Programmargumente.');
  return result;
}

export function psLiteral(value: string): string {
  if (/[\0\r\n]/.test(value)) throw new Error('Zeilenumbrüche und Nullzeichen sind in Ausführungsargumenten nicht erlaubt.');
  return "'" + value.replaceAll("'", "''") + "'";
}

/** Quote one argv element for the Windows CRT CommandLineToArgvW convention. */
export function windowsArgument(value: string): string {
  if(/[\0\r\n]/.test(value))throw new Error('Ungültiges Ausführungsargument.');
  return '"'+value.replace(/(\\*)"/g,'$1$1\\"').replace(/(\\+)$/,'$1$1')+'"';
}

export function createPowerShellScript(commands: Command[]): string {
  const body=commands.map(command=>{
    let executable=command.file;let argumentsText=command.args.map(windowsArgument).join(' ');
    if(/\.(cmd|bat)$/i.test(executable)){
      // Batch tools require cmd.exe. Reject the two forms which cannot be preserved
      // as literal batch arguments instead of letting cmd expand/inject them.
      if([executable,...command.args].some(value=>/["%\r\n\0]/.test(value)))throw new Error('Batch-Werkzeuge unterstützen hier keine Anführungszeichen oder Prozentzeichen in Pfaden/Argumenten. Verwende dafür das Terminal.');
      argumentsText='/d /v:off /s /c "'+[executable,...command.args].map(value=>'"'+value+'"').join(' ')+'"';executable=commandShellPath();
    }
    return `$si = [System.Diagnostics.ProcessStartInfo]::new(); $si.FileName = ${psLiteral(executable)}; $si.Arguments = ${psLiteral(argumentsText)}; $si.UseShellExecute = $false; $si.CreateNoWindow = $false; $p = [System.Diagnostics.Process]::Start($si); $p.WaitForExit(); if ($p.ExitCode -ne 0) { exit $p.ExitCode }`;
  }).join('\n');
  return `$ErrorActionPreference = 'Stop'\n$OutputEncoding = [Console]::OutputEncoding = [System.Text.UTF8Encoding]::new()\ntry {\n${body}\nexit 0\n} catch { [Console]::Error.WriteLine($_.Exception.Message); exit 1 }`;
}

function powershellPath(): string { return path.join(process.env.SystemRoot || process.env.WINDIR || 'C:\\Windows','System32','WindowsPowerShell','v1.0','powershell.exe'); }
function commandShellPath(): string { return path.join(process.env.SystemRoot || process.env.WINDIR || 'C:\\Windows','System32','cmd.exe'); }
function encodedArgs(script: string) {return ['-NoLogo','-NoProfile','-ExecutionPolicy','Bypass','-EncodedCommand',Buffer.from(script,'utf16le').toString('base64')];}
const exists=async(file:string)=>fs.stat(file).then(s=>s.isFile()).catch(()=>false);

async function findExecutable(candidates: string[], configured?: string): Promise<string | null> {
  if(configured) return await exists(configured) ? path.resolve(configured) : null;
  const pathValue=Object.entries(process.env).find(([key])=>key.toLowerCase()==='path')?.[1] || '';
  for(const directory of pathValue.split(path.delimiter)) {
    if(!directory) continue;
    for(const name of candidates) {
      const file=path.join(directory.replace(/^"|"$/g,''),name);
      // Windows' Python Store aliases may launch the Store instead of an interpreter.
      if(/^python(?:3)?\.exe$/i.test(name)&&/[\\/]Microsoft[\\/]WindowsApps[\\/]/i.test(file))continue;
      if(await exists(file)) return file;
    }
  }
  return null;
}

async function executeCaptured(file:string,args:string[],timeout=6000):Promise<{code:number;output:string}> {
  const batch=/\.(cmd|bat)$/i.test(file);
  return await new Promise(resolve=>{
    let output=''; let complete=false;
    const child=spawnChild(batch?powershellPath():file,batch?encodedArgs(createPowerShellScript([{file,args}])):args,{windowsHide:true,env:cleanEnvironment(),stdio:['ignore','pipe','pipe']});
    const finish=(code:number)=>{if(complete)return;complete=true;clearTimeout(timer);resolve({code,output:output.slice(0,20_000)});};
    child.stdout?.on('data',part=>{output=(output+part.toString()).slice(0,20_000);}); child.stderr?.on('data',part=>{output=(output+part.toString()).slice(0,20_000);});
    child.on('error',err=>{output+=err.message;finish(-1);}); child.on('close',code=>finish(code??-1));
    const timer=setTimeout(()=>{if(child.pid)void killProcessTree(child.pid);finish(-1);},timeout);
  });
}

/** The PID is from a process created by this service, never supplied by the renderer. */
export async function killProcessTree(pid: number): Promise<void> {
  if(!Number.isSafeInteger(pid)||pid<=0) throw new Error('Ungültige Prozess-ID.');
  if(process.platform !== 'win32') {try{process.kill(-pid,'SIGKILL');}catch{try{process.kill(pid,'SIGKILL');}catch{}} return;}
  await new Promise<void>(resolve=>{
    const killer=spawnChild(path.join(process.env.SystemRoot || 'C:\\Windows','System32','taskkill.exe'),['/PID',String(pid),'/T','/F'],{windowsHide:true,env:cleanEnvironment(),stdio:'ignore'});
    const timer=setTimeout(()=>{killer.kill();resolve();},5000);
    killer.once('error',()=>{clearTimeout(timer);resolve();}); killer.once('close',()=>{clearTimeout(timer);resolve();});
  });
}

const mime: Record<string,string>={'.html':'text/html; charset=utf-8','.htm':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.gif':'image/gif','.webp':'image/webp','.ico':'image/x-icon','.woff':'font/woff','.woff2':'font/woff2','.ttf':'font/ttf','.txt':'text/plain; charset=utf-8','.wasm':'application/wasm','.mp4':'video/mp4','.mp3':'audio/mpeg'};
export function isPreviewPathBlocked(relative: string): boolean {
  return relative.split(/[\\/]/).some(part=>part==='..'||['.git','node_modules','.ssh','.aws','.azure','.kube','.npmrc','.pypirc','.netrc','credentials.json','credentials.safe.json','secrets.json'].includes(part.toLowerCase())||/^\.env(?:\.|$)/i.test(part)||/\.(pem|key|pfx|p12|keystore)$/i.test(part)||/^id_(rsa|ed25519|ecdsa)$/i.test(part));
}

export async function startPreviewServer(root:string,authorize:(file:string)=>Promise<string>,getLocale:()=>Locale=()=> 'en'):Promise<{server:http.Server;baseUrl:string}> {
  const canonicalRoot=await fs.realpath(root);
  const server=http.createServer(async(req,res)=>{
    const deny=(code:number,message:string)=>{res.writeHead(code,{'Content-Type':'text/plain; charset=utf-8'});res.end(localizeMessage(getLocale(),message));};
    try {
      if(req.method!=='GET'&&req.method!=='HEAD')return deny(405,'Nur lesender Zugriff.');
      if(!/^127\.0\.0\.1(?::\d+)?$/.test(req.headers.host||''))return deny(403,'Ungültige Vorschauadresse.');
      const pathname=decodeURIComponent((req.url||'/').split('?')[0]);
      if(pathname.includes('\\')||pathname.includes('\0'))return deny(403,'Ungültiger Pfad.');
      const relative=pathname.replace(/^\/+/, '') || 'index.html';
      if(isPreviewPathBlocked(relative))return deny(403,'Diese Datei wird nicht in der Vorschau bereitgestellt.');
      let file=path.resolve(canonicalRoot,relative);
      const rel=path.relative(canonicalRoot,file);
      if(rel.startsWith('..')||path.isAbsolute(rel))return deny(403,'Pfad außerhalb des Projekts.');
      file=await authorize(file);
      const canonical=await fs.realpath(file); const realRelative=path.relative(canonicalRoot,canonical);
      if(realRelative.startsWith('..')||path.isAbsolute(realRelative)||isPreviewPathBlocked(realRelative))return deny(403,'Verknüpfung außerhalb der Vorschau.');
      const stat=await fs.stat(canonical);
      if(!stat.isFile())return deny(404,'Datei nicht gefunden.');
      if(stat.size>32*1024*1024)return deny(413,'Vorschaudatei ist größer als 32 MiB.');
      res.writeHead(200,{'Content-Type':mime[path.extname(file).toLowerCase()]||'application/octet-stream','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'self' data: blob:; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline'; connect-src 'self'; object-src 'none'; base-uri 'self'",'Referrer-Policy':'no-referrer'});
      res.end(req.method==='HEAD'?undefined:await fs.readFile(canonical));
    } catch {deny(404,'Datei nicht gefunden oder nicht für die Vorschau freigegeben.');}
  });
  await new Promise<void>((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',()=>resolve());});
  const address=server.address();if(!address||typeof address==='string')throw new Error('Die lokale Vorschau konnte nicht gestartet werden.');
  return {server,baseUrl:`http://127.0.0.1:${address.port}`};
}

export function createRuntimeService(deps:Deps) {
  const locale=()=>deps.getSettings().language??'en';
  const ui=(source:string)=>localizeMessage(locale(),source);
  const tr=(source:string,params:Record<string,string|number>)=>translate(locale(),source,params);
  const sessions=new Map<string,Session>(); const archives=new Map<string,Session>(); let runtimeCache:RuntimeInfo[]|null=null; let runtimeCacheTime=0;
  let preview:{server:http.Server;baseUrl:string;root:string;entry:string;watcher?:FSWatcher;revision:number}|null=null;
  let previewTimer:ReturnType<typeof setTimeout>|undefined;
  const notify=deps.notify;
  const ensureRoot=()=>{const root=deps.getRoot();if(!root)throw new Error('Öffne zuerst einen Projektordner.');return root;};
  const runtimeView=(items:RuntimeInfo[]):RuntimeInfo[]=>items.map(({versionMessage,...item})=>({...item,label:ui(item.label),version:versionMessage?ui(item.version):item.version}));

  async function listRuntimes(force=false):Promise<RuntimeInfo[]> {
    if(!force&&runtimeCache&&Date.now()-runtimeCacheTime<15000)return runtimeView(runtimeCache);
    const settings=deps.getSettings();
    const result=await Promise.all(definitions.map(async definition=>{
      const file=await findExecutable(definition.candidates,settings.runtimePaths[definition.id]);
      if(!file)return {id:definition.id,label:definition.label,path:settings.runtimePaths[definition.id]||'',available:false,version:'Nicht gefunden – Pfad auswählen oder Laufzeit selbst installieren.',versionMessage:true};
      try{
        const checked=await executeCaptured(file,definition.version);
        return {id:definition.id,label:definition.label,path:file,available:checked.code===0,version:checked.output.trim().split(/\r?\n/).filter(Boolean).slice(0,3).join(' · ')||'Keine Versionsausgabe',versionMessage:!checked.output.trim()};
      }catch(error){return {id:definition.id,label:definition.label,path:file,available:false,version:error instanceof Error?error.message:'Versionsprüfung fehlgeschlagen.',versionMessage:true};}
    }));
    runtimeCache=result;runtimeCacheTime=Date.now();return runtimeView(result);
  }
  async function requireRuntime(id:RuntimeId):Promise<string> {
    const definition=definitions.find(item=>item.id===id)!;
    const file=await findExecutable(definition.candidates,deps.getSettings().runtimePaths[id]);
    if(!file)throw new Error(`${definition.label} wurde nicht gefunden. Unter Einstellungen → Laufzeiten und Ausführung kannst du den Pfad auswählen. Der Editor bleibt ohne diese Laufzeit benutzbar.`);
    return file;
  }
  async function createSession(title:string,commands?:Command[],temp?:string,cols=100,rows=24,shellKind?:'powershell'|'cmd'):Promise<Session> {
    if(sessions.size>=20)throw new Error('Es sind bereits 20 Terminals oder Programme geöffnet. Schließe zuerst eine Sitzung.');
    const cwd=await deps.authorize(ensureRoot()); const run=!!commands;
    const pty=await import('node-pty');
    const shell=commands?powershellPath():((shellKind||deps.getSettings().shell)==='cmd'?commandShellPath():powershellPath());
    if(!await exists(shell))throw new Error('Die Windows-Shell wurde nicht gefunden. PowerShell oder cmd.exe muss verfügbar sein.');
    const args=commands?encodedArgs(createPowerShellScript(commands)):(path.basename(shell).toLowerCase()==='cmd.exe'?['/d']:['-NoLogo','-NoProfile']);
    const env=cleanEnvironment(); if(commands)env.NODE_PATH=path.join(cwd,'node_modules');
    const processPty=pty.spawn(shell,args,{name:'xterm-256color',cols,rows,cwd,env,useConpty:true});
    const id=randomUUID(); const session:Session={id,title,pty:processPty,run,temp,buffer:'',sequence:0}; sessions.set(id,session);
    processPty.onData(data=>{session.buffer=(session.buffer+data).slice(-262144);session.sequence++;notify('terminal.data',{id,data,sequence:session.sequence});if(run)notify('run.output',{id,data,stream:'combined'});});
    processPty.onExit(({exitCode})=>{
      session.exiting=true;session.exitCode=exitCode;sessions.delete(id);archives.set(id,session);if(archives.size>30)archives.delete(archives.keys().next().value!);notify('terminal.exit',{id,exitCode});
      if(run)notify('run.exit',{id,exitCode,stopped:!!session.stopped});
      if(temp)void fs.rm(temp,{recursive:true,force:true}).catch(()=>{});
    });
    if(run)notify('run.output',{id,data:`\r\n▶ ${title}\r\n${tr('Arbeitsordner: {path}',{path:cwd})}\r\n`,stream:'info'});
    return session;
  }
  async function stopSession(session:Session) {
    session.stopped=true;
    if(session.exiting)return;
    // Keep the root alive until taskkill has enumerated and terminated its descendants.
    await killProcessTree(session.pty.pid);try{session.pty.kill();}catch{}
    sessions.delete(session.id);
    if(session.temp)await fs.rm(session.temp,{recursive:true,force:true}).catch(()=>{});
  }
  function getSession(id:unknown):Session {
    if(typeof id!=='string'||!sessions.has(id))throw new Error('Diese Terminalsitzung ist bereits beendet.');
    return sessions.get(id)!;
  }
  async function closePreview() {
    if(previewTimer){clearTimeout(previewTimer);previewTimer=undefined;}
    if(preview){preview.watcher?.close();await new Promise<void>(resolve=>preview!.server.close(()=>resolve()));preview=null;}
  }
  function refreshPreview() {
    if(!preview)return;
    preview.revision++;
    const url=`${preview.baseUrl}/${path.relative(preview.root,preview.entry).split(path.sep).map(encodeURIComponent).join('/')}?v=${preview.revision}`;
    notify('preview.updated',{url});
  }
  async function showPreview(entry:string):Promise<{id:string;title:string;previewUrl:string}> {
    const root=await deps.authorize(ensureRoot()); entry=await deps.authorize(entry);
    if(preview?.root!==root){await closePreview();const started=await startPreviewServer(root,deps.authorize,locale);preview={...started,root,entry,revision:0};
      try{preview.watcher=watch(root,{recursive:true},(_type,name)=>{if(name&&name.toString().split(/[\\/]/).some(part=>['node_modules','.git','dist','build'].includes(part)))return;if(previewTimer)clearTimeout(previewTimer);previewTimer=setTimeout(refreshPreview,250);});}catch{}
    }
    preview!.entry=entry;const previewUrl=`${preview!.baseUrl}/${path.relative(root,entry).split(path.sep).map(encodeURIComponent).join('/')}`;
    return {id:'preview',title:path.basename(entry),previewUrl};
  }
  async function tasks():Promise<{id:string;label:string}[]> {
    const root=deps.getRoot();if(!root)return [];
    const result:{id:string;label:string}[]=[];
    if(await exists(path.join(root,'pom.xml')))result.push({id:'maven:compile',label:'Maven: kompilieren'},{id:'maven:test',label:'Maven: Tests'},{id:'maven:package',label:'Maven: Paket bauen'},{id:'maven:exec',label:'Maven: starten (exec.mainClass konfigurieren)'});
    if(await exists(path.join(root,'build.gradle'))||await exists(path.join(root,'build.gradle.kts'))||await exists(path.join(root,'settings.gradle'))||await exists(path.join(root,'settings.gradle.kts')))result.push({id:'gradle:build',label:'Gradle: bauen'},{id:'gradle:test',label:'Gradle: Tests'},{id:'gradle:run',label:'Gradle: starten (application-Plugin)'});
    return result.map(task=>({...task,label:ui(task.label)}));
  }
  async function runTask(task:string,args:string[]):Promise<{id:string;title:string}> {
    const root=ensureRoot();const taskInfo=(await tasks()).find(item=>item.id===task);if(!taskInfo)throw new Error('Diese Projektaufgabe ist nicht verfügbar.');
    let command:Command;
    if(task.startsWith('gradle:')){
      const wrapper=path.join(root,'gradlew.bat');const tool=await exists(wrapper)?await deps.authorize(wrapper):await requireRuntime('gradle');
      command={file:tool,args:[task.slice(7),'--console=plain',...args]};
    }else{
      const wrapper=path.join(root,'mvnw.cmd');const tool=await exists(wrapper)?await deps.authorize(wrapper):await requireRuntime('mvn');
      command={file:tool,args:[task==='maven:exec'?'exec:java':task.slice(6),...args]};
    }
    const session=await createSession(taskInfo.label,[command]);return {id:session.id,title:session.title};
  }
  async function runFile(file:string,args:string[]):Promise<{id:string;title:string;previewUrl?:string}> {
    file=await deps.authorize(file);const root=ensureRoot();const extension=path.extname(file).toLowerCase();
    if(['.html','.htm','.css'].includes(extension)){
      let entry=file;
      if(extension==='.css'){
        const candidates=[path.join(path.dirname(file),'index.html'),path.join(root,'index.html')]; entry='';
        for(const candidate of candidates)if(await exists(candidate)){entry=candidate;break;}
        if(!entry)throw new Error('CSS benötigt eine HTML-Datei. Erstelle eine index.html, die diese CSS-Datei einbindet, und starte die Vorschau erneut.');
      }
      return showPreview(entry);
    }
    const commands:Command[]=[];let temp:string|undefined;
    try{
      if(['.js','.mjs','.cjs'].includes(extension))commands.push({file:await requireRuntime('node'),args:[file,...args]});
      else if(extension==='.py')commands.push({file:await requireRuntime('python'),args:['-u',file,...args]});
      else if(['.ts','.mts','.cts'].includes(extension)){
        const node=await requireRuntime('node');temp=await fs.mkdtemp(path.join(os.tmpdir(),'codestudio-ts-'));
        const resourcesPath=(process as NodeJS.Process&{resourcesPath?:string}).resourcesPath;
        const resourceCompiler=resourcesPath?path.join(resourcesPath,'compiler','typescript','lib','tsc.js'):'';
        let tsc:string;
        if(resourceCompiler&&await exists(resourceCompiler)){
          // electron-builder's dependency filtering omits declaration files.
          // The complete compiler is copied as resources so native tsc can read
          // its own lib.d.ts and resolve its sibling platform package normally.
          const standardLibrary=path.join(resourcesPath!,'compiler','node_modules','@typescript',`typescript-${process.platform}-${process.arch}`,'lib','lib.d.ts');
          if(!await exists(standardLibrary))throw new Error('Der mitgelieferte TypeScript-Compiler ist unvollständig: lib.d.ts fehlt. Bitte CodeStudio erneut installieren.');
          tsc=resourceCompiler;
        }else{
          const require=createRequire(path.join(__dirname,'main.cjs'));
          tsc=path.join(path.dirname(require.resolve('typescript')),'tsc.js').replace(/\.asar([\\/])/g,'.asar.unpacked$1');
        }
        // Node16 mode supports modern Node imports and the file's package type.
        let packageDirectory=path.dirname(file);
        while(true){
          const packageFile=path.join(packageDirectory,'package.json');
          if(await exists(packageFile)){try{const type=JSON.parse(await fs.readFile(packageFile,'utf8')).type;if(type==='module')await fs.writeFile(path.join(temp,'package.json'),JSON.stringify({type:'module'}));}catch{}break;}
          if(packageDirectory===root||path.dirname(packageDirectory)===packageDirectory)break;packageDirectory=path.dirname(packageDirectory);
        }
        commands.push({file:node,args:[tsc,file,'--ignoreConfig','--target','ES2022','--module','Node16','--moduleResolution','Node16','--esModuleInterop','--skipLibCheck','--outDir',temp,'--rootDir',root,'--noEmitOnError']});
        const relative=path.relative(root,file).replace(/\.(?:mts|cts|ts)$/i,extension==='.mts'?'.mjs':extension==='.cts'?'.cjs':'.js');
        commands.push({file:node,args:[path.join(temp,relative),...args]});
      }
      else if(extension==='.java'){
        const javac=await requireRuntime('javac');const java=await requireRuntime('java');temp=await fs.mkdtemp(path.join(os.tmpdir(),'codestudio-java-'));
        const source=await fs.readFile(file,'utf8');const packageName=source.match(/^\s*package\s+([A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)*)\s*;/m)?.[1];
        const className=(packageName?packageName+'.':'')+path.basename(file,'.java');
        commands.push({file:javac,args:['-encoding','UTF-8','-d',temp,'-sourcepath',root,file]},{file:java,args:['-cp',temp,className,...args]});
      }
      else if(extension==='.kt'||extension==='.kts'){
        const kotlin=await requireRuntime('kotlinc');const java=await requireRuntime('java');
        if(extension==='.kts')commands.push({file:kotlin,args:['-script',file,'--',...args]});
        else{temp=await fs.mkdtemp(path.join(os.tmpdir(),'codestudio-kotlin-'));const jar=path.join(temp,'program.jar');commands.push({file:kotlin,args:[file,'-include-runtime','-d',jar]},{file:java,args:['-jar',jar,...args]});}
      }
      else if(extension==='.ps1')commands.push({file:powershellPath(),args:['-NoLogo','-NoProfile','-File',file,...args]});
      else throw new Error('Für diese Sprache ist keine direkte Ausführung eingerichtet. HTML/CSS: Vorschau; JavaScript/TypeScript: Node.js; Python, Java, Kotlin und PowerShell: passende Laufzeit. JSON, YAML und Markdown werden im Editor validiert bzw. als Vorschau angezeigt.');
      const session=await createSession(path.basename(file),commands,temp);return {id:session.id,title:session.title};
    }catch(error){if(temp)await fs.rm(temp,{recursive:true,force:true}).catch(()=>{});throw error;}
  }

  return {
    refreshPreview,
    async handle(command:string,args:any={}) {
      if(!args||typeof args!=='object'||Array.isArray(args))throw new Error('Ungültige Ausführungsanfrage.');
      switch(command){
        case 'runtime.list':return listRuntimes(!!args.refresh);
        case 'runtime.pick':{
          if(!definitions.some(item=>item.id===args.id))throw new Error('Unbekannte Laufzeit.');
          const {dialog}=await import('electron');const options={title:ui('Interpreter oder Compiler auswählen'),properties:['openFile'] as ('openFile')[],filters:[{name:ui('Programme und Skripte'),extensions:['exe','cmd','bat']},{name:ui('Alle Dateien'),extensions:['*']}]};
          const window=deps.getWindow();const result=window?await dialog.showOpenDialog(window,options):await dialog.showOpenDialog(options);
          if(!result.canceled&&result.filePaths[0]){const file=result.filePaths[0];if(!await exists(file))throw new Error('Die ausgewählte Laufzeitdatei existiert nicht.');await deps.updateSettings({runtimePaths:{...deps.getSettings().runtimePaths,[args.id]:file}});runtimeCache=null;}
          return listRuntimes(true);
        }
        case 'terminal.create':{
          const cols=Number(args.cols||100),rows=Number(args.rows||24);if(!Number.isInteger(cols)||cols<10||cols>500||!Number.isInteger(rows)||rows<2||rows>200)throw new Error('Ungültige Terminalgröße.');
          if(args.shell!==undefined&&!['powershell','cmd'].includes(args.shell))throw new Error('Unbekannte Shell.');
          const selectedShell=args.shell||deps.getSettings().shell;const session=await createSession(selectedShell==='cmd'?ui('Eingabeaufforderung'):'PowerShell',undefined,undefined,cols,rows,selectedShell);return {id:session.id,title:session.title};
        }
        case 'terminal.write':{if(typeof args.data!=='string'||args.data.length>1_048_576)throw new Error('Ungültige Terminaleingabe.');getSession(args.id).pty.write(args.data);return true;}
        case 'terminal.buffer':{const session=sessions.get(args.id)||archives.get(args.id);if(!session)throw new Error('Terminalsitzung nicht gefunden.');return {data:session.buffer,sequence:session.sequence,exitCode:session.exitCode};}
        case 'terminal.resize':{const cols=Number(args.cols),rows=Number(args.rows);if(!Number.isInteger(cols)||cols<2||cols>500||!Number.isInteger(rows)||rows<1||rows>200)throw new Error('Ungültige Terminalgröße.');getSession(args.id).pty.resize(cols,rows);return true;}
        case 'terminal.interrupt':getSession(args.id).pty.write('\x03');return true;
        case 'terminal.close':if(sessions.has(args.id))await stopSession(getSession(args.id));archives.delete(args.id);return true;
        case 'run.tasks':return tasks();
        case 'run.start':{
          const parsed=parseArguments(args.args??deps.getSettings().runArgs);if(typeof args.task==='string')return runTask(args.task,parsed);
          if(typeof args.path!=='string'||args.path.length>32768)throw new Error('Wähle zuerst eine gespeicherte Datei zum Ausführen aus.');return runFile(args.path,parsed);
        }
        case 'run.stop':{
          const active=[...sessions.values()].filter(session=>session.run&&(!args.id||session.id===args.id));await Promise.all(active.map(stopSession));return true;
        }
        case 'preview.refresh':refreshPreview();return true;
        case 'preview.close':await closePreview();return true;
        default:throw new Error('Unbekannte Terminal- oder Ausführungsaktion.');
      }
    },
    async dispose(){await closePreview();await Promise.all([...sessions.values()].map(stopSession));sessions.clear();archives.clear();},
  };
}
