import * as fs from 'node:fs/promises';
import { watch, type FSWatcher } from 'node:fs';
import path from 'node:path';
import { createHash, randomUUID } from 'node:crypto';
import { dialog, shell, type BrowserWindow, type OpenDialogOptions, type SaveDialogOptions, type MessageBoxOptions } from 'electron';
import type { Settings, TreeEntry, OpenFile, ContextFile, Suggestion } from '../src/shared';
import {localizeMessage,translate} from '../src/i18n';

const MAX_FILE = 8 * 1024 * 1024;
const MAX_CONTEXT = 100_000;
const DEFAULT_EXCLUDES = ['node_modules', '.git', 'dist', 'build', '.gradle', '.idea', 'target', '.next', '.venv', 'venv', 'coverage', 'release'];
const key = (value: string) => process.platform === 'win32' ? value.toLowerCase() : value;
export const digest = (value: Buffer | string) => createHash('sha256').update(value).digest('hex');
const isMissing = (error: unknown) => (error as NodeJS.ErrnoException)?.code === 'ENOENT';
const fileConflict = (message:string) => Object.assign(new Error(message),{code:'FILE_CONFLICT'});
function readableFileError(error: unknown): never {
  const code=(error as NodeJS.ErrnoException)?.code;
  const messages:Record<string,string>={ENOENT:'Die Datei oder der Ordner wurde nicht gefunden. Möglicherweise wurde das Element außerhalb von CodeStudio verschoben oder gelöscht.',EACCES:'Windows verweigert den Dateizugriff. Prüfen Sie die Zugriffsrechte.',EPERM:'Windows konnte die Dateiaktion nicht erlauben. Möglicherweise ist das Element geschützt oder in einem anderen Programm geöffnet.',EEXIST:'Eine Datei oder ein Ordner mit diesem Namen existiert bereits. Es wurde nichts überschrieben.',ENOTDIR:'Ein Teil des Pfads ist kein Ordner.',EISDIR:'Der ausgewählte Pfad ist ein Ordner und keine Textdatei.',ENOSPC:'Auf dem Laufwerk ist nicht genug Speicherplatz verfügbar.',EBUSY:'Die Datei wird gerade von einem anderen Programm verwendet. Versuchen Sie es nach dem Schließen erneut.',EXDEV:'Dieses Verschieben zwischen unterschiedlichen Laufwerken wird hier nicht unterstützt. Verwenden Sie den Windows-Explorer.'};
  if(code&&messages[code])throw new Error(messages[code]);
  throw error;
}
function text(value: unknown, label: string, max = 32767): string {
  if (typeof value !== 'string' || !value.length || value.length > max || value.includes('\0')) throw new Error(`${label} ist ungültig.`);
  return value;
}
export function validName(value: unknown): string {
  const name = text(value, 'Der Name', 255);
  if (name === '.' || name === '..' || /[<>:"/\\|?*\x00-\x1f]/.test(name) || /[. ]$/.test(name) || /^(con|prn|aux|nul|com[0-9]|lpt[0-9])(?:\.|$)/i.test(name)) throw new Error('Bitte einen gültigen Windows-Dateinamen verwenden.');
  return name;
}
function validatePath(value: unknown): string {
  const input = text(value, 'Der Pfad');
  if (!path.isAbsolute(input)) throw new Error('Ein absoluter Dateipfad ist erforderlich.');
  // Reject Windows alternate streams and device namespaces, even when exercised on another host.
  if (/^(?:\\\\[.?]\\|\\\?\?\\)/.test(input) || input.replace(/^[A-Za-z]:/, '').includes(':')) throw new Error('Gerätepfade und alternative Datenströme werden nicht unterstützt.');
  return path.resolve(input);
}
export function isInside(root: string, candidate: string): boolean {
  const relative = path.relative(key(root), key(candidate));
  return relative === '' || (!relative.startsWith(`..${path.sep}`) && relative !== '..' && !path.isAbsolute(relative));
}
export function isSensitiveFile(filePath: string): boolean {
  const parts = filePath.replace(/\\/g, '/').split('/');
  return parts.some(part => /^(?:\.env(?:\..*)?|\.ssh|\.aws|\.azure|\.gnupg|\.git|\.npmrc|\.pypirc|\.netrc|credentials(?:\..*)?|secrets?(?:\..*)?|id_(?:rsa|dsa|ecdsa|ed25519)(?:\..*)?)$/i.test(part)) || /\.(?:pem|key|p12|pfx|keystore|jks|kdbx)$/i.test(filePath);
}
export const containsPrivateKey = (content:string) => /-----BEGIN (?:[A-Z0-9]+ )*PRIVATE KEY-----/.test(content);
/** Windows readers and virus scanners can briefly deny a replacement. Never
 * remove the destination to work around this: every retry checks its snapshot. */
export async function replaceFileWithRetry(source:string,target:string,verify:()=>Promise<void>,rename:(source:string,target:string)=>Promise<void>=fs.rename,pause:(ms:number)=>Promise<void>=ms=>new Promise(resolve=>setTimeout(resolve,ms))) {
  const waits=[0,40,80,140,240,400,600];
  for(let attempt=0;attempt<waits.length;attempt++){
    if(waits[attempt])await pause(waits[attempt]);
    try{await verify();await rename(source,target);return;}
    catch(error){
      const code=(error as NodeJS.ErrnoException)?.code;
      if(!code||!['EPERM','EBUSY','EACCES'].includes(code))throw error;
      if(attempt===waits.length-1)throw new Error(`„${path.basename(target)}“ konnte nicht gespeichert werden (${code}). Windows oder ein anderes Programm hält die Datei gesperrt. Die vorhandene Datei wurde nicht gelöscht; schließen Sie das andere Programm und speichern Sie erneut.`);
    }
  }
}
async function limitedBytes(target:string, limit=MAX_FILE):Promise<Buffer> {
  const handle=await fs.open(target,'r');
  try {
    const stat=await handle.stat();
    if(!stat.isFile())throw new Error('Der ausgewählte Pfad ist keine Datei.');
    if(stat.size>limit)throw new Error(`Die Datei ist größer als ${limit===MAX_FILE?'8 MiB':'die erlaubte Suchgröße'}. Bitte mit einem Werkzeug für große Dateien öffnen.`);
    const chunks:Buffer[]=[];let total=0;
    while(total<=limit){
      const buffer=Buffer.alloc(Math.min(65536,limit+1-total));const {bytesRead}=await handle.read(buffer,0,buffer.length,total);
      if(!bytesRead)break;total+=bytesRead;if(total>limit)throw new Error('Die Datei wurde beim Lesen vergrößert und überschreitet die erlaubte Größe.');chunks.push(buffer.subarray(0,bytesRead));
    }
    return Buffer.concat(chunks,total);
  } finally {await handle.close();}
}
export class PathAccess {
  root: string | null = null;
  private selected = new Set<string>();
  async setRoot(input: string | null) {
    this.selected.clear();
    this.root = input ? await fs.realpath(validatePath(input)) : null;
    if (this.root && !(await fs.stat(this.root)).isDirectory()) throw new Error('Der Projektpfad ist kein Ordner.');
    return this.root;
  }
  async selectFile(input: string, missing = false) {
    const resolved = await this.canonical(input, missing);
    this.selected.add(key(resolved));
    return resolved;
  }
  private async canonical(input: string, allowMissing: boolean): Promise<string> {
    const resolved = validatePath(input);
    try { return await fs.realpath(resolved); }
    catch (error) {
      if (!allowMissing || !isMissing(error)) throw error;
      const parent = path.dirname(resolved);
      if (parent === resolved) throw error;
      const canonicalParent = await this.canonical(parent, true);
      return path.join(canonicalParent, validName(path.basename(resolved)));
    }
  }
  async authorize(input: string, allowMissing = false) {
    const resolved = validatePath(input);
    const canonical = await this.canonical(resolved, allowMissing);
    const lexicalAllowed = (this.root && isInside(this.root, resolved)) || this.selected.has(key(resolved));
    const canonicalAllowed = (this.root && isInside(this.root, canonical)) || this.selected.has(key(canonical));
    if (!lexicalAllowed || !canonicalAllowed) throw new Error('Zugriff verweigert: Der Pfad liegt außerhalb des bewusst geöffneten Projekts oder der ausgewählten Datei.');
    return canonical;
  }
}

type Native = {
  open(options: OpenDialogOptions): Promise<{canceled:boolean;filePaths:string[]}>;
  save(options: SaveDialogOptions): Promise<{canceled:boolean;filePath?:string}>;
  message(options: MessageBoxOptions): Promise<{response:number}>;
  trash(filePath: string): Promise<void>;
};
export interface FileDependencies {
  getWindow: () => BrowserWindow | null;
  onProject: (root: string | null) => void;
  notify: (event: string, data: unknown) => void;
  getSettings: () => Settings;
  updateSettings: (patch: Partial<Settings>) => Promise<unknown>;
  native?: Native;
}
type Encoding = 'UTF-8' | 'UTF-8 BOM' | 'UTF-16 LE' | 'UTF-16 BE';
function decode(buffer: Buffer): {content: string; encoding: Encoding} {
  if (buffer.length >= 2 && buffer[0] === 0xff && buffer[1] === 0xfe) return {content: buffer.subarray(2).toString('utf16le'), encoding:'UTF-16 LE'};
  if (buffer.length >= 2 && buffer[0] === 0xfe && buffer[1] === 0xff) { const data=Buffer.from(buffer.subarray(2)); if(data.length % 2) throw new Error('Ungültige UTF-16-Datei.'); data.swap16(); return {content:data.toString('utf16le'),encoding:'UTF-16 BE'}; }
  if (buffer.subarray(0, 3).equals(Buffer.from([0xef,0xbb,0xbf]))) return {content:new TextDecoder('utf-8',{fatal:true}).decode(buffer.subarray(3)),encoding:'UTF-8 BOM'};
  if (buffer.includes(0)) throw new Error('Diese Datei enthält Binärdaten und kann nicht im Texteditor geöffnet werden.');
  try { return {content:new TextDecoder('utf-8',{fatal:true}).decode(buffer),encoding:'UTF-8'}; }
  catch { throw new Error('Die Datei ist kein gültiges UTF-8 oder UTF-16. Bitte vor dem Bearbeiten in UTF-8 konvertieren.'); }
}
function encode(content:string,encoding:Encoding = 'UTF-8') {
  if (encoding === 'UTF-16 LE' || encoding === 'UTF-16 BE') {
    const bytes=Buffer.from(content,'utf16le');
    if(encoding === 'UTF-16 BE') bytes.swap16();
    return Buffer.concat([Buffer.from(encoding === 'UTF-16 BE' ? [0xfe,0xff] : [0xff,0xfe]),bytes]);
  }
  return Buffer.concat([encoding === 'UTF-8 BOM' ? Buffer.from([0xef,0xbb,0xbf]) : Buffer.alloc(0),Buffer.from(content,'utf8')]);
}
function contentArg(value: unknown) {
  if (typeof value !== 'string' || Buffer.byteLength(value,'utf8') > MAX_FILE) throw new Error('Der Dateiinhalt fehlt oder ist größer als 8 MiB.');
  return value;
}
export function createFileService(deps: FileDependencies) {
  const ui=(source:string)=>localizeMessage(deps.getSettings().language??'en',source);
  const access=new PathAccess();
  const encodings=new Map<string,Encoding>();
  const proposals=new Map<string,Suggestion>();
  const undo: Array<Array<{path:string;before:Buffer|null;afterHash:string}>>=[];
  let watcher: FSWatcher | null=null;
  let searchGeneration=0;
  let mutation=Promise.resolve<unknown>(undefined);
  const rawNative:Native=deps.native ?? {
    open: options => {const win=deps.getWindow();return win ? dialog.showOpenDialog(win,options) : dialog.showOpenDialog(options)},
    save: options => {const win=deps.getWindow();return win ? dialog.showSaveDialog(win,options) : dialog.showSaveDialog(options)},
    message: options => {const win=deps.getWindow();return win ? dialog.showMessageBox(win,options) : dialog.showMessageBox(options)},
    trash: target => shell.trashItem(target)
  };
  const native:Native={
    open: options=>rawNative.open({...options,...(options.title?{title:ui(options.title)}:{}),...(options.buttonLabel?{buttonLabel:ui(options.buttonLabel)}:{}),...(options.filters?{filters:options.filters.map(filter=>({...filter,name:ui(filter.name)}))}:{})}),
    save: options=>rawNative.save({...options,...(options.title?{title:ui(options.title)}:{}),...(options.buttonLabel?{buttonLabel:ui(options.buttonLabel)}:{}),...(options.filters?{filters:options.filters.map(filter=>({...filter,name:ui(filter.name)}))}:{})}),
    message: options=>rawNative.message({...options,...(options.title?{title:ui(options.title)}:{}),...(options.message?{message:ui(options.message)}:{}),...(options.detail?{detail:ui(options.detail)}:{}),...(options.buttons?{buttons:options.buttons.map(ui)}:{})}),
    trash: target=>rawNative.trash(target)
  };
  const rootRequired=() => {if(!access.root)throw new Error('Bitte zuerst einen Projektordner öffnen.'); return access.root};
  const notify=(filePath:string,kind='change')=>deps.notify('fs.changed',{path:filePath,kind});
  async function snapshot(input:string):Promise<OpenFile> {
    const target=await access.authorize(input);
    const buffer=await limitedBytes(target);
    const decoded=decode(buffer); encodings.set(key(target),decoded.encoding);
    return {path:target,content:decoded.content,hash:digest(buffer),encoding:decoded.encoding,eol:decoded.content.includes('\r\n')?'CRLF':'LF'};
  }
  async function currentHash(target:string) {
    try { return digest(await limitedBytes(target)); }
    catch(error) {if(isMissing(error)) return null; throw error;}
  }
  async function checkedWrite(target:string,buffer:Buffer,expected:string|null) {
    target=await access.authorize(target,true);
    if(await currentHash(target)!==expected)throw fileConflict('Dateikonflikt: Die Datei wurde außerhalb des Editors geändert. Bitte neu laden oder die Änderungen vergleichen.');
    if(expected===null) { await fs.writeFile(target,buffer,{flag:'wx'}); notify(target); return; }
    const temp=path.join(path.dirname(target),`.codestudio-${randomUUID()}.tmp`);
    try {
      await fs.writeFile(temp,buffer,{flag:'wx'});
      await replaceFileWithRetry(temp,target,async()=>{
        await access.authorize(target);
        if(await currentHash(target)!==expected)throw fileConflict('Dateikonflikt: Die Datei wurde während des Speicherns geändert. Die neue Fassung wurde nicht überschrieben.');
      });
    } finally { await fs.unlink(temp).catch(()=>undefined); }
    notify(target);
  }
  async function setProject(root:string|null) {
    watcher?.close(); watcher=null; searchGeneration++;
    const canonical=await access.setRoot(root); proposals.clear(); undo.length=0;
    if(canonical) {
      const settings=deps.getSettings();
      await deps.updateSettings({lastProject:canonical,recentProjects:[canonical,...settings.recentProjects.filter(item=>key(item)!==key(canonical))].slice(0,12)});
      try {
        watcher=watch(canonical,{recursive:true},(kind,name)=>{
          if(name) { const target=path.resolve(canonical,name.toString()); if(isInside(canonical,target) && !target.includes('.codestudio-')) notify(target,kind); }
        });
        watcher.on('error',()=>deps.notify('fs.watchError',{message:ui('Externe Dateiänderungen können derzeit nicht überwacht werden. Beim Speichern werden Konflikte weiterhin geprüft.')}));
      } catch { deps.notify('fs.watchError',{message:ui('Die Dateiüberwachung ist nicht verfügbar. Beim Speichern werden Konflikte weiterhin geprüft.')}); }
    } else await deps.updateSettings({lastProject:null});
    deps.onProject(canonical); return canonical;
  }
  async function list(input?:string):Promise<TreeEntry[]> {
    const target=await access.authorize(input ?? rootRequired());
    const entries=await fs.readdir(target,{withFileTypes:true});
    return entries.filter(entry=>!entry.name.startsWith('.codestudio-')).map(entry=>({name:entry.name,path:path.join(target,entry.name),directory:entry.isDirectory(),symlink:entry.isSymbolicLink()})).sort((a,b)=>Number(b.directory)-Number(a.directory)||a.name.localeCompare(b.name,'de',{numeric:true}));
  }
  async function search(args:any) {
    const query=args.filesOnly===true && args.query==='' ? '' : text(args.query,'Die Suchanfrage',500);
    const root=rootRequired(), generation=++searchGeneration;
    const excluded=new Set([...DEFAULT_EXCLUDES,...deps.getSettings().searchExcluded].map(item=>item.toLowerCase()));
    const results:Array<{path:string;line?:number;text?:string}>=[];
    const queue=[root]; let visited=0,truncated=false;
    const needle=args.caseSensitive?query:query.toLocaleLowerCase();
    while(queue.length && results.length<500 && visited<30000) {
      if(generation!==searchGeneration) return {results,truncated:true};
      const dir=queue.pop()!;
      let entries;try {entries=await fs.readdir(dir,{withFileTypes:true})}catch{continue;}
      for(const entry of entries) {
        if(results.length>=500 || visited++>=30000){truncated=true;break;}
        if(excluded.has(entry.name.toLowerCase()) || entry.isSymbolicLink() || entry.name.startsWith('.codestudio-'))continue;
        const target=path.join(dir,entry.name);
        if(entry.isDirectory()){queue.push(target);continue;}
        if(!entry.isFile())continue;
        if(args.filesOnly){const candidate=path.relative(root,target);if((args.caseSensitive?candidate:candidate.toLocaleLowerCase()).includes(needle))results.push({path:target,text:candidate});continue;}
        if(isSensitiveFile(target))continue;
        try {
          const authorized=await access.authorize(target),stat=await fs.stat(authorized);
          if(stat.size>1024*1024)continue;
          const content=decode(await limitedBytes(authorized,1024*1024)).content;
          const lines=content.split(/\r?\n/);
          for(let i=0;i<lines.length && results.length<500;i++)if((args.caseSensitive?lines[i]:lines[i].toLocaleLowerCase()).includes(needle))results.push({path:target,line:i+1,text:lines[i].slice(0,800)});
        } catch { /* Unreadable and binary files do not interrupt a project search. */ }
      }
      // Yield to the event loop between directories; all filesystem work is asynchronous.
      await new Promise<void>(resolve=>setImmediate(resolve));
    }
    return {results,truncated:truncated||queue.length>0||results.length>=500};
  }
  async function apply(ids:unknown) {
    if(!Array.isArray(ids)||!ids.length||ids.length>30||ids.some(id=>typeof id!=='string'))throw new Error('Bitte gültige Änderungsvorschläge auswählen.');
    const selected=ids.map(id=>{const p=proposals.get(id);if(!p||p.applied)throw new Error('Dieser Vorschlag ist nicht mehr verfügbar.');return p});
    if(new Set(selected.map(p=>key(p.path))).size!==selected.length)throw new Error('Bitte pro Datei nur einen Vorschlag gleichzeitig übernehmen.');
    const records:Array<{path:string;before:Buffer|null;afterHash:string}>=[];
    for(const p of selected){await access.authorize(p.path,true);if(await currentHash(p.path)!==p.hash)throw fileConflict(`Dateikonflikt in ${path.basename(p.path)}: Seit dem Vorschlag wurde die Datei verändert.`);}
    try {
      for(const p of selected){
        const before=p.hash===null?null:await limitedBytes(p.path);
        const encoded=encode(p.after,encodings.get(key(p.path)));
        // New file proposals may target existing subdirectories; directory creation stays an explicit Explorer action.
        await checkedWrite(p.path,encoded,p.hash);
        records.push({path:p.path,before,afterHash:digest(encoded)});
      }
    } catch(error) {
      for(const record of records.reverse())if(await currentHash(record.path)===record.afterHash){if(record.before===null)await fs.unlink(record.path);else await checkedWrite(record.path,record.before,record.afterHash);}
      throw error;
    }
    undo.push(records);if(undo.length>30)undo.shift();selected.forEach(p=>p.applied=true);
    return Promise.all(selected.map(p=>snapshot(p.path)));
  }
  async function undoLast() {
    const records=undo.at(-1);if(!records)throw new Error('Keine übernommene KI-Änderung zum Rückgängigmachen.');
    for(const r of records){await access.authorize(r.path);if(await currentHash(r.path)!==r.afterHash)throw fileConflict(`Dateikonflikt in ${path.basename(r.path)}: Die Datei wurde seit der Übernahme geändert. Rückgängig würde neue Änderungen überschreiben.`);}
    const snapshots:OpenFile[]=[];
    for(const record of [...records].reverse()) {
      if(record.before===null){await fs.unlink(record.path);notify(record.path,'rename');snapshots.push({path:record.path,content:'',hash:'',encoding:'UTF-8',eol:'LF'});}
      else {await checkedWrite(record.path,record.before,record.afterHash);snapshots.push(await snapshot(record.path));}
    }
    undo.pop();return snapshots;
  }
  async function execute(command:string,args:any={}):Promise<any> {
    if(args===null||typeof args!=='object'||Array.isArray(args))throw new Error('Ungültige Dateianfrage.');
    switch(command) {
      case 'project.current':return access.root;
      case 'project.open': {
        let target:string|undefined;
        if(args.path!==undefined) {
          const requested=validatePath(args.path);
          if(!deps.getSettings().recentProjects.some(item=>key(path.resolve(item))===key(requested)) && (!access.root||key(requested)!==key(access.root)))throw new Error('Dieser Projektordner wurde nicht über einen Dateidialog freigegeben.');
          target=requested;
        } else {const result=await native.open({title:'Projektordner öffnen',buttonLabel:'Projekt öffnen',properties:['openDirectory']});if(result.canceled)return null;target=result.filePaths[0];}
        return target?setProject(target):null;
      }
      case 'project.create': {
        const name=validName(args.name);
        const result=await native.open({title:'Übergeordneten Ordner für das neue Projekt wählen',buttonLabel:'Hier erstellen',properties:['openDirectory']});if(result.canceled||!result.filePaths[0])return null;
        const parent=await fs.realpath(validatePath(result.filePaths[0]));const target=path.join(parent,name);
        await fs.mkdir(target);return setProject(target);
      }
      case 'project.close':return setProject(null);
      case 'fs.list':return list(args.path);
      case 'fs.read':return snapshot(text(args.path,'Der Dateipfad'));
      case 'fs.save': {
        const target=await access.authorize(text(args.path,'Der Dateipfad'),true),content=contentArg(args.content);
        const expected=args.hash===null?null:text(args.hash,'Der Dateistand',128);
        let actual=await currentHash(target);
        if(actual!==expected) {
          if(!args.force)throw fileConflict('Dateikonflikt: Die Datei wurde außerhalb des Editors geändert. Neu laden oder bewusst überschreiben.');
          const choice=await native.message({type:'warning',title:'Externe Änderungen überschreiben?',message:`„${path.basename(target)}“ wurde außerhalb von CodeStudio verändert.`,detail:'Die externe Fassung wird durch Ihren Editorinhalt ersetzt. Abbrechen und die Datei neu laden erhält die externe Fassung.',buttons:['Abbrechen','Bewusst überschreiben'],defaultId:0,cancelId:0,noLink:true});
          if(choice.response!==1)throw new Error('Speichern abgebrochen. Die externe Datei bleibt unverändert.');
          actual=await currentHash(target);
        }
        await checkedWrite(target,encode(content,encodings.get(key(target))),actual);return snapshot(target);
      }
      case 'fs.saveAs': {
        const content=contentArg(args.content);
        const untitled=translate(deps.getSettings().language??'en','Unbenannt.txt');
        const result=await native.save({title:'Datei speichern unter',defaultPath:typeof args.path==='string'?args.path:access.root?path.join(access.root,untitled):untitled,buttonLabel:'Speichern',properties:['showOverwriteConfirmation','createDirectory']});
        if(result.canceled||!result.filePath)return null;
        const target=await access.selectFile(result.filePath,true);let expected=await currentHash(target);
        if(expected!==null){const choice=await native.message({type:'warning',title:'Datei ersetzen?',message:`„${path.basename(target)}“ existiert bereits.`,buttons:['Abbrechen','Ersetzen'],defaultId:0,cancelId:0,noLink:true});if(choice.response!==1)return null;expected=await currentHash(target);}
        await checkedWrite(target,encode(content),expected);return snapshot(target);
      }
      case 'fs.create': {
        const parent=await access.authorize(typeof args.parent==='string'?args.parent:rootRequired()),name=validName(args.name),target=await access.authorize(path.join(parent,name),true);
        if(args.directory===true)await fs.mkdir(target);else await fs.writeFile(target,'',{flag:'wx'});
        notify(target,'rename');return {name,path:target,directory:args.directory===true};
      }
      case 'fs.rename':case 'fs.move': {
        const source=await access.authorize(text(args.path,'Der Dateipfad'));
        if(access.root && key(source)===key(access.root))throw new Error('Der geöffnete Projektordner selbst kann hier nicht verschoben werden.');
        const target=command==='fs.rename'?path.join(path.dirname(source),validName(args.name)):args.destination!==undefined?validatePath(args.destination):path.join(await access.authorize(text(args.target,'Der Zielordner')),path.basename(source));
        const destination=await access.authorize(target,true);
        if(key(source)===key(destination))throw new Error('Bitte einen anderen Namen oder Zielordner wählen.');
        try{await fs.lstat(destination);throw new Error('Am Ziel existiert bereits eine Datei oder ein Ordner. Es wurde nichts überschrieben.');}catch(error){if(!isMissing(error))throw error;}
        if(isInside(source,destination))throw new Error('Ein Ordner kann nicht in sich selbst verschoben werden.');
        await fs.rename(source,destination);notify(source,'rename');notify(destination,'rename');return {oldPath:source,path:destination};
      }
      case 'fs.trash': {
        const target=await access.authorize(text(args.path,'Der Dateipfad'));
        if(access.root&&key(target)===key(access.root))throw new Error('Der geöffnete Projektordner selbst kann hier nicht gelöscht werden.');
        const choice=await native.message({type:'question',title:'In den Papierkorb verschieben',message:`„${path.basename(target)}“ in den Windows-Papierkorb verschieben?`,detail:'Bei einem Ordner werden auch seine Unterordner und Dateien verschoben.',buttons:['Abbrechen','In Papierkorb'],defaultId:0,cancelId:0,noLink:true});
        if(choice.response!==1)return false;
        await native.trash(target);notify(target,'rename');return true;
      }
      case 'fs.search':return search(args);
      case 'fs.pickFiles': {
        const result=await native.open({title:'Dateien auswählen',defaultPath:access.root??undefined,properties:['openFile','multiSelections']});if(result.canceled)return [];
        if(result.filePaths.length>30)throw new Error('Bitte höchstens 30 Dateien gleichzeitig auswählen.');
        return Promise.all(result.filePaths.map(async input=>snapshot(await access.selectFile(input))));
      }
      case 'fs.context': {
        if(!Array.isArray(args.paths)||args.paths.length>30||args.paths.some((p:unknown)=>typeof p!=='string'))throw new Error('Bitte höchstens 30 Kontextdateien auswählen.');
        const context:ContextFile[]=[];let size=0;
        for(const input of args.paths){const target=await access.authorize(input);if(isSensitiveFile(target))throw new Error(`„${path.basename(target)}“ ist als Zugangsdaten- oder Schlüsseldatei vom KI-Kontext ausgeschlossen.`);const file=await snapshot(target);if(containsPrivateKey(file.content))throw new Error('Die ausgewählte Datei enthält einen privaten Schlüssel und ist vom KI-Kontext ausgeschlossen.');size+=file.content.length;if(size>MAX_CONTEXT)throw new Error('Der ausgewählte Kontext ist zu groß (maximal 100.000 Zeichen). Bitte weniger Dateien anheften.');context.push({path:file.path,content:file.content,hash:file.hash});}
        return context;
      }
      case 'fs.propose': {
        const input=text(args.path,'Der Vorschlagspfad');const target=await access.authorize(path.isAbsolute(input)?input:path.resolve(rootRequired(),input),true);
        if(isSensitiveFile(target))throw new Error('Zugangsdaten und private Schlüssel sind von KI-Dateivorschlägen ausgeschlossen.');
        let before='',hash:string|null=null;try{const existing=await snapshot(target);before=existing.content;hash=existing.hash;}catch(error){if(!isMissing(error))throw error;}
        if(containsPrivateKey(before)||containsPrivateKey(contentArg(args.after)))throw new Error('Dateien mit privaten Schlüsseln sind von KI-Dateivorschlägen ausgeschlossen.');
        if(args.hash!==undefined && args.hash!==hash)throw fileConflict('Dateikonflikt: Der vom Assistenten verwendete Dateistand ist inzwischen veraltet.');
        const proposal:Suggestion={id:randomUUID(),path:target,before,after:contentArg(args.after),hash};
        if(proposals.size>=100)proposals.delete(proposals.keys().next().value!);proposals.set(proposal.id,proposal);return proposal;
      }
      case 'fs.apply':return apply(args.ids);
      case 'fs.undo':return undoLast();
      default:throw new Error('Unbekannte Dateifunktion.');
    }
  }
  const mutations=new Set(['project.open','project.create','project.close','fs.save','fs.saveAs','fs.create','fs.rename','fs.move','fs.trash','fs.propose','fs.apply','fs.undo']);
  return {
    handle(command:string,args:unknown={}) {
      if(!mutations.has(command))return execute(command,args).catch(readableFileError);
      const pending=mutation.then(()=>execute(command,args)).catch(readableFileError);mutation=pending.catch(()=>undefined);return pending;
    },
    authorize:(input:string,allowMissing=false)=>access.authorize(input,allowMissing),
    getRoot:()=>access.root,
    dispose(){searchGeneration++;watcher?.close();watcher=null;}
  };
}
