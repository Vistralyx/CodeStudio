import { t, localizeMessage, getLanguage } from "./i18n";
import { version as appVersion } from "../package.json";
import { useCallback, useEffect, useRef, useState } from "react";
import {
  Files,
  Search,
  Sparkles,
  Settings as SettingsIcon,
  FolderOpen,
  FolderPlus,
  FilePlus2,
  Play,
  Square,
  Terminal as TerminalIcon,
  Plus,
  X,
  ChevronRight,
  ChevronDown,
  PanelBottom,
  Sun,
  Moon,
  GitCompareArrows,
  Undo2,
  Check,
  AlertCircle,
  CheckCircle2,
  ExternalLink,
  Code2,
  BookOpen,
  ArrowRight,
  RefreshCw,
} from "lucide-react";
import type {
  Settings,
  Locale,
  OpenFile,
  ContextFile,
  Suggestion,
} from "./shared";
import { CodeEditor, DiffView, languageFor, type EditorHandle } from "./Editor";
import Explorer, { basename, dirname, joinPath } from "./Explorer";
import Chat, { type FileBlock } from "./Chat";
import TerminalPane, { type TerminalSession } from "./Terminal";
import SettingsDialog from "./Settings";
import Markup from "./Markup";

interface Doc extends OpenFile {
  saved: string;
  external?: boolean;
  revision?: number;
}
interface InputPrompt {
  title: string;
  label: string;
  initial: string;
  resolve: (v: string | null) => void;
}
interface Problem {
  path: string;
  line: number;
  message: string;
  severity: number;
}
export default function App() {
  const [settings, setSettings] = useState<Settings | null>(null),
    [root, setRoot] = useState<string | null>(null),
    [files, setFiles] = useState<Doc[]>([]),
    [active, setActive] = useState<string | null>(null),
    [sidebar, setSidebar] = useState("explorer"),
    [sidebarVisible, setSidebarVisible] = useState(true),
    [panelTab, setPanelTab] = useState("terminal"),
    [refresh, setRefresh] = useState(0),
    [position, setPosition] = useState({ line: 1, column: 1 }),
    [problems, setProblems] = useState<Problem[]>([]),
    [sessions, setSessions] = useState<TerminalSession[]>([]),
    [activeTerminal, setActiveTerminal] = useState<string | null>(null),
    [running, setRunning] = useState<string | null>(null),
    [output, setOutput] = useState(""),
    [preview, setPreview] = useState<string | null>(null),
    [markdown, setMarkdown] = useState(false),
    [settingsOpen, setSettingsOpen] = useState(false),
    [help, setHelp] = useState<string | null>(null),
    [toast, setToast] = useState<string | null>(null),
    [query, setQuery] = useState(""),
    [searchResults, setSearchResults] = useState<any[]>([]),
    [searchBusy, setSearchBusy] = useState(false),
    [searchTruncated, setSearchTruncated] = useState(false),
    [quick, setQuick] = useState(false),
    [quickQuery, setQuickQuery] = useState(""),
    [quickResults, setQuickResults] = useState<any[]>([]),
    [prompt, setPrompt] = useState<InputPrompt | null>(null),
    [menu, setMenu] = useState<{
      x: number;
      y: number;
      path: string;
      directory: boolean;
    } | null>(null),
    [suggestions, setSuggestions] = useState<Suggestion[]>([]),
    [diffIndex, setDiffIndex] = useState(0),
    [checked, setChecked] = useState<Set<string>>(new Set()),
    [tasks, setTasks] = useState<any[] | null>(null);
  const editor = useRef<EditorHandle>(null),
    filesRef = useRef(files),
    activeRef = useRef(active),
    settingsRef = useRef(settings),
    rootRef = useRef(root),
    actionRef = useRef<(id: string) => void>(() => {}),
    runningRef = useRef(running),
    undoPaths = useRef<string[]>([]),
    nextUntitled = useRef(1),
    exitedRuns = useRef(new Map<string, number>());
  filesRef.current = files;
  activeRef.current = active;
  settingsRef.current = settings;
  rootRef.current = root;
  runningRef.current = running;
  const error = useCallback(
    (e: unknown) =>
      setToast(
        localizeMessage(
          getLanguage(),
          (e instanceof Error ? e.message : String(e)).replace(
            /^\[FILE_CONFLICT\]\s*/,
            "",
          ),
        ),
      ),
    [],
  );
  const safe = (fn: () => Promise<any>) => {
    void fn().catch(error);
  };
  const ask = (title: string, label: string, initial = "") =>
    new Promise<string | null>((resolve) =>
      setPrompt({ title, label, initial, resolve }),
    );
  const update = async (patch: Partial<Settings>) => {
    const result = await window.studio.invoke<Settings>("app.settings", patch);
    setSettings(result);
    return result;
  };
  const activeFile = files.find((f) => f.path === active) || null;
  const dirty = (f: Doc) => f.content !== f.saved;
  const mergeFiles = (incoming: OpenFile[]) => {
    setFiles((prev) =>
      prev.flatMap((old) => {
        const found = incoming.find((x) => x.path === old.path);
        return found
          ? found.hash
            ? [
                {
                  ...found,
                  saved: found.content,
                  revision: (old.revision || 0) + 1,
                },
              ]
            : []
          : [old];
      }),
    );
    setRefresh((r) => r + 1);
  };
  const save = async (file: Doc, as = false): Promise<OpenFile | null> => {
    const untitled = file.path.startsWith("untitled:");
    let saved: OpenFile | null;
    if (as || untitled)
      saved = await window.studio.invoke("fs.saveAs", {
        path: untitled ? undefined : file.path,
        content: file.content,
      });
    else {
      try {
        saved = await window.studio.invoke("fs.save", {
          path: file.path,
          content: file.content,
          hash: file.hash,
        });
      } catch (e) {
        if (
          (e as Error & { code?: string }).code === "FILE_CONFLICT" ||
          (e as Error).message.startsWith("[FILE_CONFLICT]")
        ) {
          saved = await window.studio.invoke("fs.save", {
            path: file.path,
            content: file.content,
            hash: file.hash,
            force: true,
          });
        } else throw e;
      }
    }
    if (!saved) return null;
    const fresh: Doc = { ...saved, saved: saved.content };
    setFiles((prev) => {
      const target = prev.find(
        (x) => x.path === saved!.path && x.path !== file.path,
      );
      if (target && dirty(target))
        return prev
          .filter((x) => x.path !== file.path)
          .map((x) =>
            x.path === target.path
              ? { ...fresh, content: x.content, revision: x.revision }
              : x,
          );
      return prev
        .filter((x) => x.path !== saved!.path || x.path === file.path)
        .map((x) =>
          x.path === file.path
            ? {
                ...fresh,
                content: x.content === file.content ? fresh.content : x.content,
                revision: x.revision,
              }
            : x,
        );
    });
    if (activeRef.current === file.path) setActive(saved.path);
    setRefresh((r) => r + 1);
    return saved;
  };
  const confirmClose = async (documents: Doc[]) => {
    for (const file of documents) {
      if (!dirty(file)) continue;
      const choice = await window.studio.invoke<string>("app.unsaved", {
        name: basename(file.path),
      });
      if (choice === "cancel") return false;
      if (choice === "save" && !(await save(file))) return false;
    }
    return true;
  };
  const changeLanguage = async (language: Locale) => {
    if (!settingsRef.current || language === settingsRef.current.language)
      return;
    if (!(await confirmClose(filesRef.current))) return;
    await window.studio.invoke("app.restart", { language });
  };
  const openFile = async (path: string, line?: number) => {
    let f = filesRef.current.find((f) => f.path === path);
    if (!f) {
      const opened = await window.studio.invoke<OpenFile>("fs.read", { path });
      f = { ...opened, saved: opened.content };
      setFiles((prev) =>
        prev.some((x) => x.path === f!.path) ? prev : [...prev, f!],
      );
    }
    setActive(f.path);
    setMarkdown(false);
    if (line) setTimeout(() => editor.current?.reveal(line), 100);
  };
  const newFile = () => {
    const path =
      "untitled:" + t("Unbenannt") + "-" + nextUntitled.current++ + ".txt";
    setFiles((prev) => [
      ...prev,
      { path, content: "", saved: "", hash: "", encoding: "UTF-8", eol: "LF" },
    ]);
    setActive(path);
    setMarkdown(false);
  };
  const closeFile = async (path: string) => {
    const target = filesRef.current.find((f) => f.path === path);
    if (!target || !(await confirmClose([target]))) return;
    const next = filesRef.current.filter((f) => f.path !== path);
    setFiles(next);
    if (activeRef.current === path) setActive(next.at(-1)?.path || null);
  };
  const changeProject = async (
    kind: "open" | "create" | "close",
    path?: string,
  ) => {
    if (!(await confirmClose(filesRef.current))) return;
    let result: string | null;
    if (kind === "create") {
      const name = await ask(
        t("Neues Projekt"),
        t("Name des neuen Projektordners"),
        t("Mein Projekt"),
      );
      if (!name) return;
      result = await window.studio.invoke("project.create", { name });
    } else
      result = await window.studio.invoke(
        "project." + kind,
        path ? { path } : {},
      );
    if (!result && kind !== "close") return;
    await window.studio.invoke("run.stop").catch(() => {});
    await window.studio.invoke("preview.close").catch(() => {});
    for (const session of sessions)
      await window.studio
        .invoke("terminal.close", { id: session.id })
        .catch(() => {});
    setRoot(result);
    setFiles([]);
    setActive(null);
    setPreview(null);
    setMarkdown(false);
    setSessions([]);
    setRunning(null);
    setSearchResults([]);
    setQuery("");
    setRefresh((r) => r + 1);
    const boot = await window.studio.invoke<any>("app.bootstrap");
    setSettings(boot.settings);
  };
  const terminal = async (shell?: "powershell" | "cmd") => {
    const session = await window.studio.invoke<TerminalSession>(
      "terminal.create",
      { shell: shell || settingsRef.current?.shell, cols: 100, rows: 20 },
    );
    setSessions((prev) => [...prev, session]);
    setActiveTerminal(session.id);
    setPanelTab("terminal");
    await update({ panelVisible: true });
  };
  const run = async (task?: string) => {
    let file = filesRef.current.find((f) => f.path === activeRef.current);
    if (!file && !task)
      throw new Error(
        t("Öffnen Sie zuerst eine Datei oder wählen Sie eine Projektaufgabe."),
      );
    if (file && (dirty(file) || file.path.startsWith("untitled:"))) {
      const saved = await save(file);
      if (!saved) return;
      file = { ...saved, saved: saved.content };
    }
    const lang = file ? languageFor(file.path) : "";
    if (!task && ["json", "yaml"].includes(lang)) {
      setPanelTab("problems");
      await update({ panelVisible: true });
      setToast(
        problems.length
          ? t("Die Probleme werden im unteren Bereich angezeigt.")
          : t("Für diese Datei sind aktuell keine Editor-Diagnosen vorhanden."),
      );
      return;
    }
    if (!task && lang === "markdown") {
      setMarkdown(true);
      return;
    }
    setOutput("");
    const result = await window.studio.invoke<any>("run.start", {
      path: file?.path,
      args: settingsRef.current?.runArgs || "",
      task,
    });
    if (result.previewUrl) {
      setPreview(result.previewUrl);
      setMarkdown(false);
      return;
    }
    const exitCode = exitedRuns.current.get(result.id);
    const session = { id: result.id, title: result.title, run: true, exitCode };
    setSessions((prev) => [
      ...prev.filter((s) => s.id !== session.id),
      session,
    ]);
    setActiveTerminal(session.id);
    setRunning(exitCode === undefined ? session.id : null);
    setPanelTab("terminal");
    await update({ panelVisible: true });
    setTasks(null);
  };
  const stop = async () => {
    await window.studio.invoke("run.stop", {
      id: runningRef.current || undefined,
    });
    setRunning(null);
  };
  const fileAction = async (action: string, path: string, directory = true) => {
    setMenu(null);
    if (action === "refresh") {
      setRefresh((r) => r + 1);
      return;
    }
    if (action.startsWith("drop:")) {
      const source = action.slice(5);
      const result = await window.studio.invoke<any>("fs.move", {
        path: source,
        target: path,
      });
      setFiles((prev) =>
        prev.map((f) =>
          f.path === source || f.path.startsWith(source + "\\")
            ? { ...f, path: result.path + f.path.slice(source.length) }
            : f,
        ),
      );
      if (
        activeRef.current === source ||
        activeRef.current?.startsWith(source + "\\")
      )
        setActive(result.path + activeRef.current!.slice(source.length));
      setRefresh((r) => r + 1);
      return;
    }
    if (action === "new-file" || action === "new-folder") {
      const name = await ask(
        action === "new-file" ? t("Neue Datei") : t("Neuer Ordner"),
        t("Name"),
        action === "new-file" ? t("datei.ts") : t("Neuer Ordner"),
      );
      if (!name) return;
      const result = await window.studio.invoke<any>("fs.create", {
        parent: directory ? path : dirname(path),
        name,
        directory: action === "new-folder",
      });
      setRefresh((r) => r + 1);
      if (action === "new-file") await openFile(result.path);
      return;
    }
    const affected = filesRef.current.filter(
      (f) => f.path === path || f.path.startsWith(path + "\\"),
    );
    if (action === "trash" && !(await confirmClose(affected))) return;
    if (action === "rename" || action === "move") {
      const value = await ask(
        action === "rename" ? t("Umbenennen") : t("Verschieben"),
        action === "rename"
          ? t("Neuer Name")
          : t("Zielordner (vollständiger Pfad)"),
        action === "rename" ? basename(path) : rootRef.current || dirname(path),
      );
      if (!value) return;
      const result = await window.studio.invoke<any>(
        action === "rename" ? "fs.rename" : "fs.move",
        action === "rename" ? { path, name: value } : { path, target: value },
      );
      setFiles((prev) =>
        prev.map((f) =>
          f.path === path || f.path.startsWith(path + "\\")
            ? { ...f, path: result.path + f.path.slice(path.length) }
            : f,
        ),
      );
      if (
        activeRef.current === path ||
        activeRef.current?.startsWith(path + "\\")
      )
        setActive(result.path + activeRef.current!.slice(path.length));
    }
    if (action === "trash") {
      const removed = await window.studio.invoke("fs.trash", { path });
      if (!removed) return;
      setFiles((prev) =>
        prev.filter((f) => !affected.some((a) => a.path === f.path)),
      );
      if (affected.some((f) => f.path === activeRef.current)) setActive(null);
    }
    setRefresh((r) => r + 1);
  };
  const proposals = async (blocks: FileBlock[]) => {
    if (!rootRef.current)
      throw new Error(t("Öffnen Sie zuerst ein Projekt für Dateiänderungen."));
    const list: Suggestion[] = [];
    for (const b of blocks) {
      const path = /^[A-Za-z]:[\\/]/.test(b.path)
        ? b.path
        : joinPath(rootRef.current, b.path);
      list.push(
        await window.studio.invoke("fs.propose", {
          path,
          after: b.after,
          ...(b.hash ? { hash: b.hash } : {}),
        }),
      );
    }
    setSuggestions(list);
    setDiffIndex(0);
    setChecked(new Set(list.map((s) => s.id)));
  };
  const apply = async (ids: string[]) => {
    const selected = suggestions.filter((s) => ids.includes(s.id));
    if (
      filesRef.current.some(
        (f) => selected.some((s) => s.path === f.path) && dirty(f),
      )
    )
      throw new Error(
        t(
          "Speichern oder schließen Sie zuerst die ungespeicherten Änderungen der betroffenen Dateien.",
        ),
      );
    const result = await window.studio.invoke<OpenFile[]>("fs.apply", { ids });
    undoPaths.current = selected.map((s) => s.path);
    mergeFiles(result);
    setSuggestions((prev) =>
      prev.map((s) => (ids.includes(s.id) ? { ...s, applied: true } : s)),
    );
    setToast(
      t(
        "Änderungen übernommen. Über „Änderungen rückgängig“ können Sie den letzten Satz zurücknehmen.",
      ),
    );
  };
  const undoAI = async () => {
    if (
      filesRef.current.some(
        (f) => undoPaths.current.includes(f.path) && dirty(f),
      )
    )
      throw new Error(
        t(
          "Speichern oder schließen Sie zuerst die ungespeicherten Änderungen der betroffenen Dateien.",
        ),
      );
    mergeFiles(await window.studio.invoke<OpenFile[]>("fs.undo"));
    setSuggestions([]);
    setToast(t("Letzte übernommene Dateiänderungen rückgängig gemacht."));
  };
  const getContext = async (
    selection: boolean,
  ): Promise<ContextFile | null> => {
    const file = filesRef.current.find((f) => f.path === activeRef.current);
    if (!file) throw new Error(t("Öffnen Sie zuerst eine Datei."));
    if (dirty(file) || file.path.startsWith("untitled:"))
      throw new Error(
        t(
          "Speichern Sie die Datei vor dem Anheften, damit der gesendete Dateistand eindeutig ist.",
        ),
      );
    const [context] = await window.studio.invoke<ContextFile[]>("fs.context", {
      paths: [file.path],
    });
    if (selection) {
      const content = editor.current?.selection();
      if (!content) throw new Error(t("Markieren Sie zuerst Code im Editor."));
      return { ...context, content, selection: true };
    }
    return context;
  };
  const execute = async (id: string) => {
    const file = filesRef.current.find((f) => f.path === activeRef.current),
      s = settingsRef.current;
    if (!s) return;
    switch (id) {
      case "new":
        newFile();
        break;
      case "open-file": {
        const list = await window.studio.invoke<OpenFile[]>("fs.pickFiles");
        for (const f of list || []) await openFile(f.path);
        break;
      }
      case "open-project":
        await changeProject("open");
        break;
      case "new-project":
        await changeProject("create");
        break;
      case "close-project":
        await changeProject("close");
        break;
      case "save":
        if (file) await save(file);
        break;
      case "save-as":
        if (file) await save(file, true);
        break;
      case "save-all":
        for (const f of filesRef.current) if (dirty(f)) await save(f);
        break;
      case "quit":
        if (await confirmClose(filesRef.current))
          await window.studio.invoke("app.close");
        break;
      case "settings":
        setSettingsOpen(true);
        break;
      case "theme":
        await update({ theme: s.theme === "dark" ? "light" : "dark" });
        break;
      case "word-wrap":
        await update({ wordWrap: !s.wordWrap });
        break;
      case "minimap":
        await update({ minimap: !s.minimap });
        break;
      case "toggle-sidebar":
        setSidebarVisible((v) => !v);
        break;
      case "toggle-panel":
        await update({ panelVisible: !s.panelVisible });
        break;
      case "explorer":
      case "search":
      case "chat":
        setSidebar(id);
        setSidebarVisible(true);
        break;
      case "terminal":
        await terminal();
        break;
      case "terminal-cmd":
        await terminal("cmd");
        break;
      case "interrupt":
        if (activeTerminal)
          await window.studio.invoke("terminal.interrupt", {
            id: activeTerminal,
          });
        break;
      case "run":
        await run();
        break;
      case "stop":
        await stop();
        break;
      case "tasks":
        setTasks(await window.studio.invoke("run.tasks"));
        break;
      case "quick":
        setQuick(true);
        setQuickQuery("");
        break;
      case "about":
        await window.studio.invoke("app.about");
        break;
      case "help":
      case "languages":
        setHelp(id);
        break;
      default:
        await editor.current?.action(id);
    }
  };
  actionRef.current = (id) => safe(() => execute(id));
  useEffect(() => {
    if (!window.studio) {
      setToast(t("Bitte starten Sie CodeStudio über die Desktop-Anwendung."));
      return;
    }
    window.studio
      .invoke<any>("app.bootstrap")
      .then(async (boot) => {
        setSettings(boot.settings);
        if (boot.settings.lastProject) {
          try {
            const p = await window.studio.invoke<string>("project.open", {
              path: boot.settings.lastProject,
            });
            setRoot(p);
          } catch (e) {
            error(e);
          }
        }
      })
      .catch(error);
    const key = (e: KeyboardEvent) => {
      let id = "";
      if (e.ctrlKey && !e.altKey) {
        if (e.code === "KeyN") id = "new";
        if (e.code === "KeyO") id = "open-file";
        if (e.code === "KeyS") id = e.shiftKey ? "save-as" : "save";
        if (e.code === "KeyP") id = "quick";
        if (e.code === "Comma") id = "settings";
        if (e.code === "KeyF" && e.shiftKey) id = "search";
        if (e.code === "KeyB") id = "toggle-sidebar";
        if (e.code === "KeyJ") id = "toggle-panel";
        if (e.code === "KeyK") id = "open-project";
      }
      if (e.key === "F5") id = e.shiftKey ? "stop" : "run";
      if (e.altKey && e.code === "KeyZ") id = "word-wrap";
      if (id) {
        e.preventDefault();
        e.stopPropagation();
        actionRef.current(id);
      }
    };
    window.addEventListener("keydown", key, true);
    const events = [
      window.studio.on("menu.action", (id) => actionRef.current(id)),
      window.studio.on("app.closeRequested", () => actionRef.current("quit")),
      window.studio.on("fs.watchError", (e) =>
        error(
          new Error(
            e.message ||
              t(
                "Externe Dateiänderungen können derzeit nicht überwacht werden.",
              ),
          ),
        ),
      ),
      window.studio.on("fs.changed", (e) => {
        setRefresh((r) => r + 1);
        const file = filesRef.current.find((f) => f.path === e.path);
        if (!file) return;
        window.studio
          .invoke<OpenFile>("fs.read", { path: e.path })
          .then((next) =>
            setFiles((prev) =>
              prev.map((f) =>
                f.path === next.path && f.hash !== next.hash
                  ? dirty(f)
                    ? { ...f, external: true }
                    : {
                        ...next,
                        saved: next.content,
                        revision: (f.revision || 0) + 1,
                      }
                  : f,
              ),
            ),
          )
          .catch(() =>
            setFiles((prev) =>
              prev.map((f) =>
                f.path === e.path ? { ...f, external: true } : f,
              ),
            ),
          );
      }),
      window.studio.on("terminal.exit", (e) =>
        setSessions((prev) =>
          prev.map((s) => (s.id === e.id ? { ...s, exitCode: e.exitCode } : s)),
        ),
      ),
      window.studio.on("run.exit", (e) => {
        exitedRuns.current.set(e.id, e.exitCode);
        if (exitedRuns.current.size > 100)
          exitedRuns.current.delete(exitedRuns.current.keys().next().value!);
        setRunning((prev) => (prev === e.id ? null : prev));
        setOutput(
          (prev) =>
            prev + "\n" + t("[Exitcode {code}]", { code: e.exitCode }) + "\n",
        );
      }),
      window.studio.on("run.output", (e) =>
        setOutput((prev) => (prev + e.data).slice(-300000)),
      ),
      window.studio.on("preview.updated", (e) => setPreview(e.url)),
    ];
    return () => {
      window.removeEventListener("keydown", key, true);
      events.forEach((off) => off());
    };
  }, []);
  useEffect(() => {
    if (settings) document.documentElement.dataset.theme = settings.theme;
  }, [settings?.theme]);
  useEffect(() => {
    document.title =
      (activeFile
        ? basename(activeFile.path) + (dirty(activeFile) ? " •" : "") + " — "
        : "") +
      (root ? basename(root) + " — " : "") +
      "CodeStudio";
  }, [activeFile?.path, activeFile?.content, root]);
  useEffect(() => {
    if (!root || !query.trim()) {
      setSearchResults([]);
      return;
    }
    let live = true;
    const timer = setTimeout(() => {
      setSearchBusy(true);
      window.studio
        .invoke<any>("fs.search", { query, caseSensitive: false })
        .then((r) => {
          if (live) {
            setSearchResults(r.results);
            setSearchTruncated(r.truncated);
          }
        })
        .catch(error)
        .finally(() => {
          if (live) setSearchBusy(false);
        });
    }, 300);
    return () => {
      live = false;
      clearTimeout(timer);
    };
  }, [query, root, refresh]);
  useEffect(() => {
    if (!quick) return;
    let live = true;
    const timer = setTimeout(
      () =>
        window.studio
          .invoke<any>("fs.search", { query: quickQuery, filesOnly: true })
          .then((r) => {
            if (live) setQuickResults(r.results);
          })
          .catch(error),
      100,
    );
    return () => {
      live = false;
      clearTimeout(timer);
    };
  }, [quickQuery, quick, root]);
  const resize = (type: "sidebar" | "panel", event: React.PointerEvent) => {
    event.preventDefault();
    const start = type === "sidebar" ? event.clientX : event.clientY;
    const original =
      type === "sidebar" ? settings!.sidebarWidth : settings!.panelHeight;
    let size = original;
    const move = (e: PointerEvent) => {
      size = Math.round(
        Math.max(
          type === "sidebar" ? 220 : 100,
          Math.min(
            type === "sidebar" ? 600 : window.innerHeight - 250,
            original +
              (type === "sidebar" ? e.clientX - start : start - e.clientY),
          ),
        ),
      );
      setSettings((s) =>
        s
          ? {
              ...s,
              [type === "sidebar" ? "sidebarWidth" : "panelHeight"]: size,
            }
          : s,
      );
    };
    const up = () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      safe(() =>
        update({ [type === "sidebar" ? "sidebarWidth" : "panelHeight"]: size }),
      );
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
  };
  if (!settings)
    return (
      <div className="starting">
        <Code2 size={38} />
        <h2>CodeStudio</h2>
        <p>{toast || t("Arbeitsplatz wird geöffnet …")}</p>
      </div>
    );
  const context = (
    event: React.MouseEvent,
    path: string,
    directory: boolean,
  ) => {
    event.preventDefault();
    setMenu({
      x: Math.min(event.clientX, window.innerWidth - 230),
      y: Math.min(event.clientY, window.innerHeight - 300),
      path,
      directory,
    });
  };
  return (
    <div className="app" onClick={() => menu && setMenu(null)}>
      <header className="menubar">
        <div className="brand-symbol">
          <Code2 size={18} />
        </div>
        <nav>
          {[
            t("Datei"),
            t("Bearbeiten"),
            t("Auswahl"),
            t("Ansicht"),
            t("Ausführen"),
            t("Terminal"),
            t("Hilfe"),
          ].map((name) => (
            <button
              key={name}
              onClick={(e) => {
                const b = e.currentTarget.getBoundingClientRect();
                safe(() =>
                  window.studio.invoke("app.menu", {
                    name,
                    x: b.left,
                    y: b.bottom,
                  }),
                );
              }}
            >
              {name}
            </button>
          ))}
        </nav>
        <div
          className="window-project"
          title={root || t("Kein Projekt geöffnet")}
        >
          {root ? basename(root) : "CodeStudio"}
        </div>
        <button
          title={t("Theme wechseln")}
          aria-label={t("Theme wechseln")}
          onClick={() => actionRef.current("theme")}
        >
          {settings.theme === "dark" ? <Sun size={15} /> : <Moon size={15} />}
        </button>
        <button
          title={t("Unteren Bereich ein-/ausblenden")}
          aria-label={t("Unteren Bereich umschalten")}
          onClick={() => actionRef.current("toggle-panel")}
        >
          <PanelBottom size={16} />
        </button>
      </header>
      <div className="workbench">
        <aside className="activity">
          <div>
            {[
              { id: "explorer", icon: Files, label: t("Explorer") },
              { id: "search", icon: Search, label: t("Suche") },
              { id: "chat", icon: Sparkles, label: t("KI-Assistent") },
            ].map(({ id, icon: Icon, label }) => (
              <button
                key={id}
                className={sidebar === id && sidebarVisible ? "selected" : ""}
                title={label}
                aria-label={label}
                onClick={() => {
                  if (sidebar === id) setSidebarVisible(!sidebarVisible);
                  else {
                    setSidebar(id);
                    setSidebarVisible(true);
                  }
                }}
              >
                <Icon size={23} />
              </button>
            ))}
          </div>
          <div>
            <button
              title={t("Neues Terminal")}
              aria-label={t("Terminal öffnen")}
              onClick={() => actionRef.current("terminal")}
            >
              <TerminalIcon size={22} />
            </button>
            <button
              title={t("Einstellungen (Strg+,)")}
              aria-label={t("Einstellungen")}
              onClick={() => setSettingsOpen(true)}
            >
              <SettingsIcon size={23} />
            </button>
          </div>
        </aside>
        {sidebarVisible && (
          <>
            <aside className="sidebar" style={{ width: settings.sidebarWidth }}>
              <div className="sidebar-title">
                <span>
                  {sidebar === "explorer"
                    ? t("EXPLORER")
                    : sidebar === "search"
                      ? t("SUCHE")
                      : t("KI-ASSISTENT")}
                </span>
                {sidebar === "chat" ? (
                  <Sparkles size={13} />
                ) : (
                  <button
                    title={t("Seitenleiste schließen")}
                    onClick={() => setSidebarVisible(false)}
                  >
                    <X size={14} />
                  </button>
                )}
              </div>
              <div
                style={{
                  display: sidebar === "explorer" ? "contents" : "none",
                }}
              >
                {root ? (
                  <Explorer
                    root={root}
                    refresh={refresh}
                    active={active}
                    onOpen={(p, l) => safe(() => openFile(p, l))}
                    onAction={(a, p) => safe(() => fileAction(a, p))}
                    onContext={context}
                    onError={error}
                  />
                ) : (
                  <div className="empty-sidebar">
                    <p>{t("Kein Projekt geöffnet")}</p>
                    <span>
                      {t(
                        "Öffnen Sie einen lokalen Ordner, um Ihre Dateien zu bearbeiten.",
                      )}{" "}
                    </span>
                    <button
                      className="primary"
                      onClick={() => actionRef.current("open-project")}
                    >
                      <FolderOpen size={15} />
                      {t("Projekt öffnen")}{" "}
                    </button>
                    <button onClick={() => actionRef.current("new-project")}>
                      <FolderPlus size={15} />
                      {t("Neues Projekt")}{" "}
                    </button>
                  </div>
                )}
              </div>
              <div
                className="search-panel"
                style={{ display: sidebar === "search" ? "flex" : "none" }}
              >
                <div className="search-input">
                  <Search size={15} />
                  <input
                    aria-label={t("Im Projekt suchen")}
                    placeholder={t("Im Projekt suchen …")}
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                  />
                  {query && (
                    <button onClick={() => setQuery("")}>
                      <X size={13} />
                    </button>
                  )}
                </div>
                <small>
                  {!root
                    ? t("Öffnen Sie zuerst einen Projektordner.")
                    : searchBusy
                      ? t("Suche läuft …")
                      : query
                        ? t("{count} Treffer{suffix}", {
                            count: searchResults.length,
                            suffix: searchTruncated ? t(" (begrenzt)") : "",
                          })
                        : t("Text in allen Projektdateien finden.")}
                </small>
                <div className="search-results">
                  {searchResults.map((r, i) => (
                    <button
                      key={r.path + ":" + i}
                      onClick={() => safe(() => openFile(r.path, r.line))}
                    >
                      <strong>
                        {basename(r.path)}
                        <span>{r.line ? ":" + r.line : ""}</span>
                      </strong>
                      <span className="result-path">
                        {r.path.replace(root || "", "").replace(/^[\\/]/, "")}
                      </span>
                      <code>{r.text}</code>
                    </button>
                  ))}
                </div>
              </div>
              <div
                className="chat-container"
                style={{ display: sidebar === "chat" ? "flex" : "none" }}
              >
                <Chat
                  root={root}
                  settings={settings}
                  update={update}
                  getContext={getContext}
                  onSettings={() => setSettingsOpen(true)}
                  onError={error}
                  onProposals={(b) => safe(() => proposals(b))}
                />
              </div>
            </aside>
            <div
              className="resize-sidebar"
              role="separator"
              aria-label={t("Seitenleistenbreite")}
              aria-orientation="vertical"
              onPointerDown={(e) => resize("sidebar", e)}
            />
          </>
        )}
        <main className="main-area">
          <div className="editor-tabs">
            <div className="tab-scroll">
              {files.map((f) => (
                <div
                  role="tab"
                  aria-selected={active === f.path}
                  className={"file-tab " + (active === f.path ? "active" : "")}
                  key={f.path}
                  title={f.path}
                  onClick={() => {
                    setActive(f.path);
                    setMarkdown(false);
                  }}
                >
                  <Code2 size={14} />
                  <span>{basename(f.path).replace("untitled:", "")}</span>
                  {dirty(f) ? (
                    <span
                      className="dirty-dot"
                      title={t("Ungespeicherte Änderungen")}
                    />
                  ) : null}
                  <button
                    aria-label={t("Datei schließen {name}", {
                      name: basename(f.path),
                    })}
                    onClick={(e) => {
                      e.stopPropagation();
                      safe(() => closeFile(f.path));
                    }}
                  >
                    <X size={13} />
                  </button>
                </div>
              ))}
            </div>
            <div className="run-controls">
              <button
                className="run-button"
                title={t("Aktive Datei ausführen (F5)")}
                aria-label={t("Ausführen")}
                onClick={() => actionRef.current("run")}
                disabled={!activeFile}
              >
                <Play size={14} />
                <span>{t("Ausführen")}</span>
              </button>
              <button
                title={t("Programm stoppen (Umschalt+F5)")}
                aria-label={t("Stoppen")}
                disabled={!running}
                onClick={() => actionRef.current("stop")}
              >
                <Square size={13} />
              </button>
              <button
                title={t("Neue Datei (Strg+N)")}
                aria-label={t("Neue Datei")}
                onClick={newFile}
              >
                <Plus size={16} />
              </button>
            </div>
          </div>
          {activeFile && (
            <div className="breadcrumbs">
              <span>{root ? basename(root) : t("Datei")}</span>
              <ChevronRight size={12} />
              <span>
                {activeFile.path.replace(root || "", "").replace(/^[\\/]/, "")}
              </span>
              {preview || markdown ? (
                <button
                  onClick={() => {
                    setPreview(null);
                    setMarkdown(false);
                  }}
                >
                  {t("Vorschau schließen")} <X size={12} />
                </button>
              ) : null}
            </div>
          )}
          {activeFile?.external && (
            <div className="external-banner">
              <AlertCircle size={15} />
              <span>
                {t(
                  "Diese Datei wurde außerhalb von CodeStudio geändert oder entfernt.",
                )}{" "}
              </span>
              <button
                onClick={() =>
                  safe(async () => {
                    const next = await window.studio.invoke<OpenFile>(
                      "fs.read",
                      { path: activeFile.path },
                    );
                    if (
                      dirty(activeFile) &&
                      !(await window.studio.invoke("app.confirm", {
                        message: t(
                          "Editoränderungen verwerfen und Datei neu laden?",
                        ),
                      }))
                    )
                      return;
                    mergeFiles([next]);
                  })
                }
              >
                {t("Neu laden")}{" "}
              </button>
              <button
                onClick={() =>
                  setFiles((prev) =>
                    prev.map((f) =>
                      f.path === active ? { ...f, external: false } : f,
                    ),
                  )
                }
              >
                {t("Editorinhalt behalten")}{" "}
              </button>
            </div>
          )}
          <div className="editor-space">
            <div
              className="code-surface"
              style={{
                display: activeFile ? "flex" : "none",
                width: preview || markdown ? "55%" : "100%",
              }}
            >
              <CodeEditor
                ref={editor}
                openPaths={files.map((f) => f.path)}
                file={activeFile}
                settings={settings}
                onChange={(path, content) => {
                  filesRef.current = filesRef.current.map((f) =>
                    f.path === path ? { ...f, content } : f,
                  );
                  setFiles((prev) =>
                    prev.map((f) => (f.path === path ? { ...f, content } : f)),
                  );
                }}
                onPosition={setPosition}
                onProblems={setProblems}
              />
            </div>
            {(preview || markdown) && (
              <section className="preview-pane">
                <header>
                  <span>
                    {markdown ? t("Markdown-Vorschau") : t("Webvorschau")}
                  </span>
                  <button
                    title={t("Aktualisieren")}
                    onClick={() =>
                      safe(() => window.studio.invoke("preview.refresh"))
                    }
                  >
                    <RefreshCw size={13} />
                  </button>
                  <button
                    title={t("Vorschau schließen")}
                    onClick={() => {
                      setPreview(null);
                      setMarkdown(false);
                    }}
                  >
                    <X size={14} />
                  </button>
                </header>
                {markdown ? (
                  <div className="markdown-preview">
                    <Markup text={activeFile?.content || ""} />
                  </div>
                ) : (
                  <iframe
                    title={t("Lokale Webvorschau")}
                    src={preview!}
                    sandbox="allow-scripts allow-forms allow-same-origin"
                  />
                )}
              </section>
            )}
            {!activeFile && (
              <div className="welcome">
                <div className="welcome-wordmark">
                  <span>
                    <Code2 size={38} strokeWidth={1.5} />
                  </span>
                  <h1>CodeStudio</h1>
                </div>
                <p className="welcome-subtitle">
                  {t(
                    "Ein klarer Platz für Ihren nächsten Gedanken in Code.",
                  )}{" "}
                </p>
                <div className="welcome-columns">
                  <section>
                    <h3>{t("Loslegen")}</h3>
                    <button onClick={() => actionRef.current("open-project")}>
                      <FolderOpen size={19} />
                      <span>
                        {t("Projekt öffnen")}{" "}
                        <small>{t("Einen lokalen Ordner auswählen")}</small>
                      </span>
                      <kbd>{t("Strg K")}</kbd>
                    </button>
                    <button onClick={() => actionRef.current("new-project")}>
                      <FolderPlus size={19} />
                      <span>
                        {t("Neues Projekt")}{" "}
                        <small>{t("An einem Ort Ihrer Wahl erstellen")}</small>
                      </span>
                    </button>
                    <button onClick={newFile}>
                      <FilePlus2 size={19} />
                      <span>
                        {t("Neue Datei")}
                        <small>{t("Eine Idee direkt aufschreiben")}</small>
                      </span>
                      <kbd>{t("Strg N")}</kbd>
                    </button>
                  </section>
                  <section>
                    <h3>{t("Zuletzt geöffnet")}</h3>
                    {settings.recentProjects.length ? (
                      settings.recentProjects.slice(0, 5).map((p) => (
                        <button
                          className="recent"
                          key={p}
                          onClick={() => safe(() => changeProject("open", p))}
                        >
                          <FolderOpen size={16} />
                          <span>
                            {basename(p)}
                            <small title={p}>{p}</small>
                          </span>
                          <ArrowRight size={14} />
                        </button>
                      ))
                    ) : (
                      <p className="muted">
                        {t("Ihre Projekte erscheinen hier,")} <br />
                        {t("sobald Sie einen Ordner öffnen.")}{" "}
                      </p>
                    )}
                    <button
                      className="help-link"
                      onClick={() => setHelp("help")}
                    >
                      <BookOpen size={15} />
                      {t("Kurzanleitung öffnen")}{" "}
                    </button>
                  </section>
                </div>
                <div className="welcome-footer">
                  <span>
                    <CheckCircle2 size={13} />
                    {t("Lokal arbeiten")}{" "}
                  </span>
                  <span>{t("KI optional")}</span>
                  <span>{t("Keine Anmeldung erforderlich")}</span>
                </div>
              </div>
            )}
          </div>
          {settings.panelVisible && (
            <>
              <div
                className="resize-panel"
                role="separator"
                aria-label={t("Höhe des unteren Bereichs")}
                aria-orientation="horizontal"
                onPointerDown={(e) => resize("panel", e)}
              />
              <section
                className="bottom-panel"
                style={{ height: settings.panelHeight }}
              >
                <header className="panel-tabs">
                  <div>
                    {["terminal", "output", "problems"].map((panel) => (
                      <button
                        key={panel}
                        className={panelTab === panel ? "selected" : ""}
                        onClick={() => setPanelTab(panel)}
                      >
                        {panel === "terminal"
                          ? t("TERMINAL")
                          : panel === "output"
                            ? t("AUSGABE")
                            : t("PROBLEME")}
                        {panel === "problems" && problems.length > 0 && (
                          <span className="count">{problems.length}</span>
                        )}
                      </button>
                    ))}
                  </div>
                  <div className="panel-tools">
                    {panelTab === "terminal" && (
                      <>
                        <select
                          title={t("Terminalsitzung")}
                          aria-label={t("Terminalsitzung")}
                          value={activeTerminal || ""}
                          onChange={(e) => setActiveTerminal(e.target.value)}
                        >
                          <option value="" disabled>
                            {t("Sitzung wählen")}{" "}
                          </option>
                          {sessions.map((s) => (
                            <option value={s.id} key={s.id}>
                              {s.title}
                              {s.exitCode !== undefined
                                ? t(" · Exit {code}", { code: s.exitCode })
                                : ""}
                            </option>
                          ))}
                        </select>
                        <button
                          title={t("Neues Terminal")}
                          onClick={() => actionRef.current("terminal")}
                        >
                          <Plus size={15} />
                        </button>
                        <button
                          title={t("Aktive Sitzung schließen")}
                          disabled={!activeTerminal}
                          onClick={() =>
                            safe(async () => {
                              await window.studio.invoke("terminal.close", {
                                id: activeTerminal,
                              });
                              const next = sessions.filter(
                                (s) => s.id !== activeTerminal,
                              );
                              setSessions(next);
                              setActiveTerminal(next.at(-1)?.id || null);
                            })
                          }
                        >
                          <X size={14} />
                        </button>
                      </>
                    )}
                    <button
                      title={t("Bereich schließen")}
                      onClick={() =>
                        safe(() => update({ panelVisible: false }))
                      }
                    >
                      <ChevronDown size={16} />
                    </button>
                  </div>
                </header>
                <div className="panel-body">
                  {sessions.map((s) => (
                    <TerminalPane
                      key={s.id}
                      session={s}
                      active={
                        activeTerminal === s.id && panelTab === "terminal"
                      }
                      theme={settings.theme}
                      onError={error}
                    />
                  ))}
                  {panelTab === "terminal" && !sessions.length && (
                    <div className="terminal-empty">
                      <TerminalIcon size={20} />
                      <span>{t("Ein echtes Terminal für Ihr Projekt.")}</span>
                      <button onClick={() => actionRef.current("terminal")}>
                        {t("PowerShell öffnen")}{" "}
                      </button>
                      <button onClick={() => actionRef.current("terminal-cmd")}>
                        {t("cmd öffnen")}{" "}
                      </button>
                    </div>
                  )}
                  {panelTab === "output" && (
                    <pre className="output">
                      {output ||
                        t(
                          "Programmausgaben erscheinen hier. Das interaktive Terminal führt Standard- und Fehlerausgabe zusammen.",
                        )}
                    </pre>
                  )}
                  {panelTab === "problems" && (
                    <div className="problems">
                      {problems.length ? (
                        problems.map((p, i) => (
                          <button
                            key={i}
                            onClick={() => safe(() => openFile(p.path, p.line))}
                          >
                            <AlertCircle size={14} />
                            <span>{p.message}</span>
                            <small>
                              {basename(p.path)}:{p.line}
                            </small>
                          </button>
                        ))
                      ) : (
                        <p>
                          <CheckCircle2 size={15} />
                          {t(
                            "Keine aktuellen Editor-Diagnosen. Der Funktionsumfang hängt vom Sprachdienst ab.",
                          )}{" "}
                        </p>
                      )}
                    </div>
                  )}
                </div>
              </section>
            </>
          )}
        </main>
      </div>
      <footer className="statusbar">
        <div>
          <Code2 size={13} />
          <span>{root ? basename(root) : t("Kein Projekt")}</span>
          <button
            title={t("Probleme anzeigen")}
            onClick={() => {
              setPanelTab("problems");
              safe(() => update({ panelVisible: true }));
            }}
          >
            <AlertCircle size={12} />
            {problems.filter((p) => p.severity === 8).length}
          </button>
          {running && <span className="running">{t("Programm läuft")}</span>}
        </div>
        <div>
          <span>
            {t("Ze")} {position.line}
            {t(", Sp")} {position.column}
          </span>
          <button onClick={() => setSettingsOpen(true)}>
            {settings.insertSpaces ? t("Leerzeichen") : t("Tabs")}:{" "}
            {settings.tabSize}
          </button>
          <span>{activeFile?.encoding || "UTF-8"}</span>
          <span>{activeFile?.eol || "LF"}</span>
          <button onClick={() => setHelp("languages")}>
            {activeFile ? languageFor(activeFile.path) : t("Text")}
          </button>
          <span>CodeStudio {appVersion}</span>
        </div>
      </footer>
      {toast && (
        <div className="toast" role="alert">
          <AlertCircle size={18} />
          <span>{toast}</span>
          <button
            aria-label={t("Meldung schließen")}
            onClick={() => setToast(null)}
          >
            <X size={16} />
          </button>
        </div>
      )}
      {settingsOpen && (
        <SettingsDialog
          settings={settings}
          update={update}
          onLanguageChange={changeLanguage}
          onClose={() => {
            setSettingsOpen(false);
            safe(async () =>
              setSettings(
                (await window.studio.invoke<any>("app.bootstrap")).settings,
              ),
            );
          }}
          onError={error}
        />
      )}
      {prompt && (
        <InputDialog
          prompt={prompt}
          onClose={(value) => {
            prompt.resolve(value);
            setPrompt(null);
          }}
        />
      )}
      {quick && (
        <div
          className="modal-backdrop quick-backdrop"
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) setQuick(false);
          }}
        >
          <section className="quick-open modal">
            <div className="search-input">
              <Search size={18} />
              <input
                autoFocus
                aria-label={t("Datei schnell öffnen")}
                value={quickQuery}
                placeholder={t("Dateinamen eingeben …")}
                onChange={(e) => setQuickQuery(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Escape") setQuick(false);
                  if (e.key === "Enter" && quickResults[0]) {
                    safe(() => openFile(quickResults[0].path));
                    setQuick(false);
                  }
                }}
              />
              <button onClick={() => setQuick(false)}>
                <X size={15} />
              </button>
            </div>
            <div>
              {quickResults.slice(0, 100).map((r) => (
                <button
                  key={r.path}
                  onClick={() => {
                    safe(() => openFile(r.path));
                    setQuick(false);
                  }}
                >
                  <Code2 size={14} />
                  <strong>{basename(r.path)}</strong>
                  <span>{r.path.replace(root || "", "")}</span>
                </button>
              ))}
              {!quickResults.length && (
                <p>
                  {root
                    ? t("Keine passende Datei gefunden.")
                    : t("Öffnen Sie zuerst einen Projektordner.")}
                </p>
              )}
            </div>
          </section>
        </div>
      )}
      {menu && (
        <div
          className="context-menu"
          style={{ left: menu.x, top: menu.y }}
          onClick={(e) => e.stopPropagation()}
        >
          {[
            ...(menu.directory
              ? [
                  ["new-file", t("Neue Datei")],
                  ["new-folder", t("Neuer Ordner")],
                ]
              : [["open", t("Datei öffnen")]]),
            ["rename", t("Umbenennen")],
            ["move", t("Verschieben …")],
            ["trash", t("In den Papierkorb")],
          ].map(([id, label]) => (
            <button
              key={id}
              onClick={() =>
                safe(async () => {
                  if (id === "open") {
                    await openFile(menu.path);
                    setMenu(null);
                  } else await fileAction(id, menu.path, menu.directory);
                })
              }
            >
              {label}
            </button>
          ))}
        </div>
      )}
      {suggestions.length > 0 && (
        <div className="modal-backdrop">
          <section className="diff-dialog modal">
            <header>
              <h2>
                <GitCompareArrows size={18} />
                {t("Änderungsvorschläge prüfen")}{" "}
              </h2>
              <button
                aria-label={t("Diff schließen")}
                onClick={() => setSuggestions([])}
              >
                <X size={18} />
              </button>
            </header>
            <div className="diff-tabs">
              {suggestions.map((s, i) => (
                <div key={s.id} className={diffIndex === i ? "active" : ""}>
                  <input
                    aria-label={t("Änderung auswählen {name}", {
                      name: basename(s.path),
                    })}
                    type="checkbox"
                    disabled={s.applied}
                    checked={checked.has(s.id)}
                    onChange={(e) =>
                      setChecked((prev) => {
                        const next = new Set(prev);
                        e.target.checked ? next.add(s.id) : next.delete(s.id);
                        return next;
                      })
                    }
                  />
                  <button onClick={() => setDiffIndex(i)}>
                    {basename(s.path)}
                    {s.applied && <Check size={14} />}
                  </button>
                </div>
              ))}
            </div>
            <div className="diff-labels">
              <span>{t("Aktueller gespeicherter Stand")}</span>
              <span>{t("Vorgeschlagener Stand")}</span>
            </div>
            <DiffView {...suggestions[diffIndex]} theme={settings.theme} />
            <footer>
              <button onClick={() => safe(undoAI)}>
                <Undo2 size={14} />
                {t("Änderungen rückgängig")}{" "}
              </button>
              <span>{suggestions[diffIndex].path}</span>
              <button
                disabled={suggestions[diffIndex].applied}
                onClick={() => safe(() => apply([suggestions[diffIndex].id]))}
              >
                {t("Einzeln übernehmen")}{" "}
              </button>
              <button
                className="primary"
                disabled={
                  !suggestions.some((s) => checked.has(s.id) && !s.applied)
                }
                onClick={() =>
                  safe(() =>
                    apply(
                      suggestions
                        .filter((s) => checked.has(s.id) && !s.applied)
                        .map((s) => s.id),
                    ),
                  )
                }
              >
                {t("Auswahl übernehmen")}{" "}
              </button>
            </footer>
          </section>
        </div>
      )}
      {tasks && (
        <div className="modal-backdrop">
          <section className="modal task-dialog">
            <header>
              <h2>{t("Projektaufgaben")}</h2>
              <button onClick={() => setTasks(null)}>
                <X size={18} />
              </button>
            </header>
            <p>
              {t(
                "Die ausgewählte Aufgabe führt den Build-Code dieses Projekts mit Ihren Benutzerrechten aus.",
              )}{" "}
            </p>
            {tasks.length ? (
              tasks.map((t) => (
                <button key={t.id} onClick={() => safe(() => run(t.id))}>
                  <Play size={14} />
                  {t.label}
                </button>
              ))
            ) : (
              <p>
                {t(
                  "Kein Maven- oder Gradle-Projekt erkannt. Öffnen Sie einen Ordner mit pom.xml oder build.gradle(.kts).",
                )}{" "}
              </p>
            )}
          </section>
        </div>
      )}
      {help && <HelpDialog type={help} onClose={() => setHelp(null)} />}
    </div>
  );
}
function InputDialog({
  prompt,
  onClose,
}: {
  prompt: InputPrompt;
  onClose: (s: string | null) => void;
}) {
  const [value, setValue] = useState(prompt.initial);
  return (
    <div className="modal-backdrop">
      <form
        className="input-dialog modal"
        onSubmit={(e) => {
          e.preventDefault();
          if (value.trim()) onClose(value.trim());
        }}
      >
        <header>
          <h2>{prompt.title}</h2>
          <button type="button" onClick={() => onClose(null)}>
            <X size={18} />
          </button>
        </header>
        <label>
          {prompt.label}
          <input
            autoFocus
            value={value}
            onFocus={(e) => e.target.select()}
            onChange={(e) => setValue(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Escape") onClose(null);
            }}
          />
        </label>
        <footer>
          <button type="button" onClick={() => onClose(null)}>
            {t("Abbrechen")}{" "}
          </button>
          <button className="primary" type="submit" disabled={!value.trim()}>
            {t("Bestätigen")}{" "}
          </button>
        </footer>
      </form>
    </div>
  );
}
function HelpDialog({ type, onClose }: { type: string; onClose: () => void }) {
  return (
    <div className="modal-backdrop">
      <section className="modal help-dialog">
        <header>
          <h2>
            {type === "languages"
              ? t("Sprachunterstützung")
              : t("CodeStudio · Kurzanleitung")}
          </h2>
          <button onClick={onClose}>
            <X size={18} />
          </button>
        </header>
        <div className="help-content">
          {type === "languages" ? (
            <>
              <p>
                {t(
                  "Syntaxfarben stehen für HTML, CSS, JavaScript, TypeScript, Python, Java, Kotlin, JSON, YAML, Markdown, C, C++, C#, SQL und PowerShell zur Verfügung.",
                )}{" "}
              </p>
              <table>
                <thead>
                  <tr>
                    <th>{t("Sprache")}</th>
                    <th>{t("Sprachdienst / Formatierung")}</th>
                    <th>{t("Ausführung")}</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>JS / TS</td>
                    <td>
                      {t(
                        "Monaco: Syntaxdiagnose, TS-Typprüfung, Vorschläge und Formatierung. Keine vollständige Node-/Projektauflösung.",
                      )}{" "}
                    </td>
                    <td>
                      {t(
                        "Node.js; TS: mitgelieferter tsc für einfache Einstiegsskripte (CommonJS).",
                      )}{" "}
                    </td>
                  </tr>
                  <tr>
                    <td>HTML / CSS</td>
                    <td>
                      {t(
                        "Monaco-Sprachdienste, Vervollständigung, Formatierung",
                      )}{" "}
                    </td>
                    <td>{t("Lokale Webvorschau; CSS über HTML-Einstieg.")}</td>
                  </tr>
                  <tr>
                    <td>JSON / YAML</td>
                    <td>
                      {t(
                        "JSON: Diagnose und Formatierung; YAML: Parserdiagnose und Syntaxfarben",
                      )}{" "}
                    </td>
                    <td>{t("Keine Programmausführung")}</td>
                  </tr>
                  <tr>
                    <td>Markdown</td>
                    <td>{t("Syntaxfarben, bereinigte Vorschau")}</td>
                    <td>{t("Vorschau über „Ausführen“")}</td>
                  </tr>
                  <tr>
                    <td>Python / Java / Kotlin</td>
                    <td>
                      {t(
                        "Syntaxfarben und einfache Wortvorschläge. Kein externer LSP integriert; keine vollständige IntelliSense oder automatische Formatierung.",
                      )}{" "}
                    </td>
                    <td>
                      {t(
                        "Python / JDK / kotlinc; erkannte Maven-/Gradle-Aufgaben",
                      )}{" "}
                    </td>
                  </tr>
                  <tr>
                    <td>C / C++ / C# / SQL / PowerShell</td>
                    <td>
                      {t(
                        "Syntaxfarben und Wortvorschläge. Keine semantischen Sprachdienste integriert.",
                      )}{" "}
                    </td>
                    <td>
                      {t("Manuell über das Terminal mit Ihren Werkzeugen")}
                    </td>
                  </tr>
                </tbody>
              </table>
              <p>
                {t(
                  "„Dokument formatieren“ ist nur verfügbar, wenn der integrierte Sprachdienst einen Formatter bereitstellt. Fehlende Laufzeiten werden unter Einstellungen angezeigt.",
                )}{" "}
              </p>
            </>
          ) : (
            <>
              <h3>{t("Öffnen, schreiben, speichern")}</h3>
              <p>
                {t(
                  "Öffnen Sie einen Projektordner über Datei → Projekt öffnen. Unterordner werden im Explorer aufgeklappt; über Rechtsklick können Sie Dateien erstellen, umbenennen, verschieben oder in den Papierkorb legen. Dateien lassen sich auf Ordner ziehen.",
                )}{" "}
              </p>
              <p>
                {t(
                  "Strg+N erstellt eine Datei, Strg+S speichert und Strg+Umschalt+S öffnet „Speichern unter“. Ein Punkt am Tab kennzeichnet Änderungen. Strg+P öffnet die Dateisuche, Strg+F die Suche im Editor und Strg+Umschalt+F die Projektsuche.",
                )}{" "}
              </p>
              <h3>{t("Programme ausprobieren")}</h3>
              <p>
                {t(
                  "„Ausführen“ oder F5 startet die aktive gespeicherte Datei. Eingaben erfolgen im echten Terminal. „Stoppen“ oder Umschalt+F5 beendet den Prozessbaum. Im Terminal können Sie weitere Werkzeuge und eigene Befehle ausführen. Programme laufen mit Ihren Benutzerrechten.",
                )}{" "}
              </p>
              <p>
                {t(
                  "HTML öffnet eine isolierte lokale Vorschau mit relativen Ressourcen. CSS verwendet eine HTML-Datei als Einstieg. Browser-JavaScript testen Sie über Ihre HTML-Datei; eine direkt ausgeführte JS-Datei verwendet Node.js.",
                )}{" "}
              </p>
              <h3>{t("KI bewusst verwenden")}</h3>
              <p>
                {t(
                  "Richten Sie unter Einstellungen → API-Key Ihren Anbieter ein, laden oder wählen Sie ein Modell und testen Sie die Verbindung. Öffnen Sie den Assistenten über das Funkensymbol links. Heften Sie nur die benötigten Dateien oder eine Auswahl an. Strg+Enter sendet die Nachricht.",
                )}{" "}
              </p>
              <p>
                {t("Änderungsvorschläge im Format")}{" "}
                <code>codestudio-file path="datei.ts"</code>{" "}
                {t(
                  "werden als Diff geprüft. Sie übernehmen sie einzeln oder zusammen und können den letzten übernommenen Satz rückgängig machen. Befehle im Chat führen sich nicht selbst aus.",
                )}{" "}
              </p>
              <h3>{t("Arbeitsplatz anpassen")}</h3>
              <p>
                {t(
                  "Ziehen Sie die Trennlinien neben der Seitenleiste und über dem Terminal. Strg+, öffnet die Einstellungen; Strg+J blendet den unteren Bereich ein oder aus. Beide Themes umfassen Editor, Chat, Terminal und Dialoge.",
                )}{" "}
              </p>
            </>
          )}
        </div>
        <footer>
          <button className="primary" onClick={onClose}>
            {t("Schließen")}{" "}
          </button>
        </footer>
      </section>
    </div>
  );
}
