import type {Locale} from './shared';

interface NLSGlobals {_VSCODE_NLS_MESSAGES?:Array<string|null>;_VSCODE_NLS_LANGUAGE?:string}
const messages=new Map<Exclude<Locale,'en'>,Array<string|null>>();
/** Runs before importing App/Monaco; language changes require an app restart. */
export async function loadMonacoLocale(language:Locale):Promise<void>{
  const target=globalThis as typeof globalThis&NLSGlobals;
  delete target._VSCODE_NLS_MESSAGES;delete target._VSCODE_NLS_LANGUAGE;
  if(language==='en')return;
  const cached=messages.get(language);
  if(cached){target._VSCODE_NLS_MESSAGES=cached;target._VSCODE_NLS_LANGUAGE=language;return}
  // Explicit paths keep the four language assets in Vite's production graph.
  switch(language){
    case 'de':await import('monaco-editor/nls/lang/de.js');break;
    case 'es':await import('monaco-editor/nls/lang/es.js');break;
    case 'fr':await import('monaco-editor/nls/lang/fr.js');break;
    case 'it':await import('monaco-editor/nls/lang/it.js');break;
  }
  if(target._VSCODE_NLS_LANGUAGE!==language||!Array.isArray(target._VSCODE_NLS_MESSAGES))throw new Error('The editor language resources could not be loaded.');
  messages.set(language,target._VSCODE_NLS_MESSAGES);
}
