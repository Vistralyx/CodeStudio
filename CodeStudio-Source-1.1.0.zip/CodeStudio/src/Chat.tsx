import {t} from './i18n';
import {useEffect,useRef,useState} from 'react';
import {ArrowUp,Square,Plus,Paperclip,FileCode2,TextSelect,Settings2,X,Sparkles,GitCompareArrows} from 'lucide-react';
import type {ChatMessage,ContextFile,Settings} from './shared';
import {basename} from './Explorer';
import Markup from './Markup';

export interface FileBlock {path:string;after:string;hash?:string}
interface StoredMessage extends ChatMessage {contextSnapshot?:{path:string;hash:string}[];state?:'complete'|'failed'|'cancelled'}
interface ActiveRequest {id:string;assistantId:string;epoch:number;root:string|null;label:string;model:string;cancelled:boolean}
export function fileBlocks(text:string):FileBlock[]{
 const result:FileBlock[]=[];const regex=/```codestudio-file\s+path=(?:"([^"]+)"|'([^']+)')\s*\r?\n([\s\S]*?)```/g;let match;
 while((match=regex.exec(text))&&result.length<20)result.push({path:match[1]||match[2],after:match[3].replace(/\r?\n$/,'')+'\n'});
 return result;
}
const normalize=(value:string)=>value.replace(/\\/g,'/').replace(/\/+$/,'').toLowerCase();

export default function Chat({root,settings,update,getContext,onSettings,onError,onProposals}:{root:string|null;settings:Settings;update:(s:Partial<Settings>)=>Promise<any>;getContext:(selection:boolean)=>Promise<ContextFile|null>;onSettings:()=>void;onError:(e:unknown)=>void;onProposals:(files:FileBlock[])=>void}){
 const [providers,setProviders]=useState<any[]>([]),[messages,setMessages]=useState<StoredMessage[]>([]),[text,setText]=useState(''),[pins,setPins]=useState<ContextFile[]>([]),[busy,setBusy]=useState(false),[loading,setLoading]=useState(true),[clearing,setClearing]=useState(false),[usage,setUsage]=useState<any>(null),[status,setStatus]=useState(''),[runningModel,setRunningModel]=useState('');
 const messageRef=useRef<StoredMessage[]>([]),request=useRef<ActiveRequest|null>(null),scroll=useRef<HTMLDivElement>(null),epoch=useRef(0),mounted=useRef(true),rootRef=useRef(root),handlers=useRef({onError,onProposals});
 rootRef.current=root;handlers.current={onError,onProposals};
 const commit=(next:StoredMessage[])=>{messageRef.current=next;setMessages(next)};
 const persist=(snapshot:StoredMessage[],project:string|null)=>window.studio.invoke('ai.historySave',{messages:snapshot,root:project});
 const providerConfigKey=JSON.stringify(settings.providers);
 useEffect(()=>{let current=true;window.studio.invoke<any[]>('ai.providers').then(list=>{if(current)setProviders(list)}).catch(e=>{if(current)handlers.current.onError(e)});return()=>{current=false}},[settings.activeProvider,providerConfigKey]);
 useEffect(()=>{
  const round=++epoch.current;setLoading(true);setBusy(false);setClearing(false);setPins([]);setText('');commit([]);setUsage(null);setStatus('');setRunningModel('');
  window.studio.invoke<StoredMessage[]>('ai.history',{root}).then(saved=>{if(mounted.current&&epoch.current===round)commit(saved)}).catch(e=>{if(mounted.current&&epoch.current===round)handlers.current.onError(e)}).finally(()=>{if(mounted.current&&epoch.current===round)setLoading(false)});
  return()=>{
   ++epoch.current;
   const current=request.current;request.current=null;
   if(current){void window.studio.invoke('ai.cancel',{requestId:current.id}).catch(()=>{});const snapshot=messageRef.current.map(m=>m.id===current.assistantId?{...m,state:'cancelled' as const}:m);void persist(snapshot,root).catch(()=>{});}
  };
 },[root]);
 useEffect(()=>{
  mounted.current=true;
  const offDelta=window.studio.on('ai.delta',event=>{
   const current=request.current;if(!current||event.requestId!==current.id||current.epoch!==epoch.current||current.root!==rootRef.current||typeof event.text!=='string')return;
   commit(messageRef.current.map(m=>m.id===current.assistantId?{...m,content:m.content+event.text}:m));
  });
  const finish=(event:any,failed=false)=>{
   const current=request.current;if(!current||event.requestId!==current.id||current.epoch!==epoch.current||current.root!==rootRef.current)return;
   request.current=null;setBusy(false);setRunningModel('');setUsage(event.usage||null);
   const state=current.cancelled?'cancelled':failed?'failed':'complete';
   const snapshot=messageRef.current.map(m=>m.id===current.assistantId?{...m,state:state as StoredMessage['state']}:m);commit(snapshot);
   setStatus(current.cancelled?t("Anfrage abgebrochen."):failed?String(event.message||t("Anfrage fehlgeschlagen.")):'');
   void persist(snapshot,current.root).catch(error=>{if(mounted.current&&rootRef.current===current.root)handlers.current.onError(error)});
   if(failed&&!current.cancelled)handlers.current.onError(new Error(String(event.message||t("Anfrage fehlgeschlagen."))));
  };
  const offDone=window.studio.on('ai.done',event=>finish(event));const offError=window.studio.on('ai.error',event=>finish(event,true));
  return()=>{mounted.current=false;offDelta();offDone();offError()};
 },[]);
 useEffect(()=>{scroll.current?.scrollTo({top:scroll.current.scrollHeight,behavior:busy?'instant':'smooth'})},[messages,busy]);
 const pin=async(selection:boolean)=>{const round=epoch.current;try{const file=await getContext(selection);if(file&&round===epoch.current)setPins(prev=>[...prev.filter(p=>p.path!==file.path),file])}catch(error){if(round===epoch.current)onError(error)}};
 const pick=async()=>{const round=epoch.current;try{const selected=await window.studio.invoke<any[]>('fs.pickFiles');if(selected?.length&&round===epoch.current){const list=await window.studio.invoke<ContextFile[]>('fs.context',{paths:selected.map(p=>p.path)});if(round===epoch.current)setPins(prev=>[...prev.filter(p=>!list.some(f=>f.path===p.path)),...list])}}catch(error){if(round===epoch.current)onError(error)}};
 const send=async()=>{
  if(!text.trim()||request.current||busy||loading||clearing)return;
  const provider=providers.find(p=>p.id===settings.activeProvider);if(!provider?.hasKey){onError(new Error(t("Bitte unter Einstellungen → API-Key einen Anbieter einrichten.")));return}if(!provider.model){onError(new Error(t("Bitte zuerst eine Modell-ID unter Einstellungen → API-Key auswählen.")));return}
  const current:ActiveRequest={id:crypto.randomUUID(),assistantId:crypto.randomUUID(),epoch:epoch.current,root,label:provider.label,model:provider.model,cancelled:false};request.current=current;
  const context=structuredClone(pins);const input:StoredMessage[]=[...messageRef.current.filter(m=>m.content),{role:'user',content:text.trim(),id:crypto.randomUUID()}];
  const next:StoredMessage[]=[...input,{role:'assistant',content:'',id:current.assistantId,contextSnapshot:context.map(f=>({path:f.path,hash:f.hash}))}];
  commit(next);setText('');setBusy(true);setUsage(null);setStatus('');setRunningModel(`${current.label} · ${current.model}`);
  void persist(next,current.root).catch(error=>{if(mounted.current&&current.epoch===epoch.current)onError(error)});
  try{const accepted=await window.studio.invoke<any>('ai.send',{requestId:current.id,provider:settings.activeProvider,messages:input,context});if(request.current===current&&accepted.model){current.model=accepted.model;current.label=accepted.label||current.label;setRunningModel(`${current.label} · ${current.model}`)}}
  catch(error){if(request.current===current&&current.epoch===epoch.current){request.current=null;setBusy(false);setRunningModel('');setStatus(error instanceof Error?error.message:String(error));const snapshot=messageRef.current.map(m=>m.id===current.assistantId?{...m,state:'failed' as const}:m);commit(snapshot);void persist(snapshot,current.root).catch(()=>{});onError(error)}}
 };
 const cancel=async()=>{const current=request.current;if(!current)return;current.cancelled=true;setStatus(t("Anfrage wird abgebrochen …"));try{await window.studio.invoke('ai.cancel',{requestId:current.id})}catch(error){if(request.current===current){current.cancelled=false;setStatus(t("Abbruch konnte nicht bestätigt werden."));onError(error)}}};
 const clear=async()=>{
  if(clearing||loading)return;const round=epoch.current,project=root;setClearing(true);
  try{
   if(messageRef.current.length&&!(await window.studio.invoke('app.confirm',{message:t("Diese Unterhaltung lokal löschen?"),detail:t("Angeheftete Dateien auf Ihrer Festplatte bleiben erhalten.")})))return;
   if(round!==epoch.current)return;
   const current=request.current;request.current=null;++epoch.current;const clearRound=epoch.current;
   if(current){commit(messageRef.current.map(message=>message.id===current.assistantId?{...message,state:'cancelled' as const}:message));setBusy(false);setRunningModel('');await window.studio.invoke('ai.cancel',{requestId:current.id});}
   await window.studio.invoke('ai.historyClear',{root:project});
   if(clearRound!==epoch.current||rootRef.current!==project)return;
   commit([]);setPins([]);setUsage(null);setStatus('');setBusy(false);setRunningModel('');setText('');
  }catch(error){if(rootRef.current===project){onError(error);setBusy(false);setRunningModel('')}}
  finally{if(rootRef.current===project)setClearing(false)}
 };
 const proposals=(message:StoredMessage)=>{
  try{
   const blocks=fileBlocks(message.content),seen=new Set<string>();
   for(const block of blocks){const relative=block.path.replace(/\\/g,'/');if(!relative||/^(?:[a-z]:|\/)/i.test(relative)||relative.split('/').some(part=>part==='..'||part==='.'||!part))throw new Error(t("Der KI-Vorschlag enthält keinen gültigen relativen Projektpfad. Bitten Sie um einen korrigierten Vorschlag."));const key=relative.toLowerCase();if(seen.has(key))throw new Error(t("Die KI-Antwort enthält mehrere Vorschläge für dieselbe Datei. Bitten Sie um einen eindeutigen vollständigen Dateivorschlag."));seen.add(key);const target=normalize((root||'')+'/'+relative);block.hash=message.contextSnapshot?.find(file=>normalize(file.path)===target)?.hash;}
   onProposals(blocks);
  }catch(error){onError(error)}
 };
 const provider=providers.find(p=>p.id===settings.activeProvider);
 const usageParts=usage?[['inputTokens',t("Eingabe")],['outputTokens',t("Ausgabe")],['totalTokens',t("Gesamt")]].filter(([key])=>typeof usage[key]==='number').map(([key,label])=>`${usage[key].toLocaleString(settings.language)} ${label}`):[];
 return <div className="chat-panel">
  <div className="chat-toolbar"><select title={t("Aktiver KI-Anbieter")} aria-label={t("Aktiver KI-Anbieter")} disabled={busy||clearing} value={settings.activeProvider} onChange={event=>update({activeProvider:event.target.value as any}).catch(onError)}>{providers.map(p=><option key={p.id} value={p.id}>{p.label}</option>)}</select><button title={t("Neue Unterhaltung / Verlauf löschen")} aria-label={t("Neue Unterhaltung")} disabled={loading||clearing} onClick={()=>void clear()}><Plus size={17}/></button><button title={t("API-Einstellungen")} onClick={onSettings}><Settings2 size={16}/></button></div>
  <div className="active-model" title={runningModel||provider?.model}>{runningModel||provider?.model||t("Modell in Einstellungen auswählen")}</div>
  <div className="chat-history" ref={scroll}>
   {loading?<p className="hint">{t("Unterhaltung wird geladen …")}</p>:!messages.length&&<div className="chat-welcome"><span className="assistant-mark"><Sparkles size={23}/></span><h3>{t("Ihr Assistent für Code.")}</h3><p>{t("Fragen stellen, Code verstehen und Änderungen gemeinsam prüfen.")}</p><p className="hint">{t("Heften Sie Dateien oder eine Auswahl bewusst an. Ohne Kontext werden keine Projektdateien gesendet.")}</p>{!provider?.hasKey&&<button onClick={onSettings}>{t("API-Key einrichten")}</button>}<div className="chat-starters">{[t("Erkläre mir den angehefteten Code."),t("Finde mögliche Fehler und schlage Tests vor.")].map(value=><button key={value} onClick={()=>setText(value)}>{value}</button>)}</div></div>}
   {messages.map((message,index)=><article className={'chat-message '+message.role} key={message.id||index}><div className="message-role">{message.role==='user'?t("Sie"):'CodeStudio'}{message.role==='assistant'&&message.content&&<button title={t("Antwort kopieren")} onClick={()=>window.studio.invoke('app.clipboardWrite',{text:message.content}).catch(onError)}>{t("Kopieren")}</button>}</div>{message.content?<Markup text={message.content}/>:<span className="thinking">{message.state==='cancelled'?t("Anfrage abgebrochen."):message.state==='failed'?t("Keine Antwort empfangen."):busy?t("Antwort wird angefragt …"):t("Keine Antwort gespeichert.")}</span>}{message.state==='cancelled'&&message.content&&<p className="hint">{t("Anfrage abgebrochen · Antwort unvollständig.")}</p>}{message.state==='failed'&&message.content&&<p className="hint">{t("Anfrage fehlgeschlagen · Antwort möglicherweise unvollständig.")}</p>}{message.role==='assistant'&&fileBlocks(message.content).length>0&&<button className="proposal-button" disabled={busy||message.state==='failed'||message.state==='cancelled'} onClick={()=>proposals(message)}><GitCompareArrows size={14}/>{t("Änderungsvorschläge prüfen")}</button>}</article>)}
  </div>
  {usageParts.length>0&&<div className="usage">{t("API-Verbrauch: {usage} Token",{usage:usageParts.join(' · ')})}</div>}{status&&<p className="connection-status" role="status">{status}</p>}
  <div className="chat-compose"><div className="context-chips">{pins.map(pin=><span key={pin.path} title={pin.path}>{pin.selection?<TextSelect size={12}/>:<FileCode2 size={12}/>}<span>{basename(pin.path)}{pin.selection?' · '+t('Auswahl'):''}</span><button disabled={busy} aria-label={t('Kontext entfernen: {name}',{name:basename(pin.path)})} onClick={()=>setPins(prev=>prev.filter(file=>file!==pin))}><X size={12}/></button></span>)}</div><textarea aria-label={t("Nachricht an den KI-Assistenten")} placeholder={t("Fragen Sie zu Ihrem Code …")} value={text} disabled={busy||loading||clearing} onChange={event=>setText(event.target.value)} onKeyDown={event=>{if(event.key==='Enter'&&(event.ctrlKey||event.metaKey)){event.preventDefault();void send()}}}/><div className="compose-actions"><div><button title={t("Aktive Datei anheften")} aria-label={t("Aktive Datei anheften")} disabled={busy||loading||clearing} onClick={()=>void pin(false)}><FileCode2 size={16}/></button><button title={t("Auswahl anheften")} aria-label={t("Auswahl anheften")} disabled={busy||loading||clearing} onClick={()=>void pin(true)}><TextSelect size={16}/></button><button title={t("Projektdateien auswählen")} aria-label={t("Projektdateien anheften")} disabled={busy||loading||clearing} onClick={()=>void pick()}><Paperclip size={16}/></button></div>{busy?<button className="send" title={t("Anfrage abbrechen")} aria-label={t("Anfrage abbrechen")} onClick={()=>void cancel()}><Square size={14}/></button>:<button className="send" title={t("Senden (Strg+Enter)")} aria-label={t("Nachricht senden")} disabled={!text.trim()||loading||clearing} onClick={()=>void send()}><ArrowUp size={17}/></button>}</div><small>{t("Nur angehefteter Kontext · Strg+Enter zum Senden")}</small></div>
 </div>;
}
