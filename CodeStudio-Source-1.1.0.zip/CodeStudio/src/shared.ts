export type ProviderId = 'openai' | 'xai' | 'anthropic' | 'gemini' | 'llama' | 'custom';
export type Locale = 'en' | 'de' | 'es' | 'fr' | 'it';
export interface Settings {
  language: Locale;
  theme: 'dark' | 'light'; fontSize: number; tabSize: number; insertSpaces: boolean;
  wordWrap: boolean; minimap: boolean; sidebarWidth: number; panelHeight: number;
  panelVisible: boolean; shell: 'powershell' | 'cmd'; recentProjects: string[];
  lastProject: string | null; runtimePaths: Record<string,string>; runArgs: string;
  searchExcluded: string[]; windowBounds?: {width:number;height:number;x?:number;y?:number};
  providers: Record<string, {model:string; baseUrl?:string; operator?:string}>;
  activeProvider: ProviderId;
}
export interface TreeEntry {name:string; path:string; directory:boolean; symlink?:boolean}
export interface OpenFile {path:string; content:string; hash:string; encoding?:string; eol?:string}
export interface ChatMessage {role:'user'|'assistant'; content:string; id?:string}
export interface ContextFile {path:string; content:string; hash:string; selection?:boolean}
export interface Suggestion {id:string;path:string;before:string;after:string;hash:string|null;applied?:boolean}
export interface StudioAPI {invoke<T=any>(command:string,args?:any):Promise<T>; on(event:string,callback:(data:any)=>void):()=>void}
declare global {interface Window {studio:StudioAPI}}
