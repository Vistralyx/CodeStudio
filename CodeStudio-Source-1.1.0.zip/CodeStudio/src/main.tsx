import React from 'react';
import {createRoot} from 'react-dom/client';
import {loadMonacoLocale} from './bootstrap';
import {setLanguage,t} from './i18n';
import type {Settings} from './shared';
import './style.css';

async function start(){
  const bootstrap=await window.studio.invoke<{settings:Settings}>('app.bootstrap');
  const language=setLanguage(bootstrap.settings.language);document.documentElement.lang=language;
  await loadMonacoLocale(language);
  const {default:App}=await import('./App');
  createRoot(document.getElementById('root')!).render(<App/>);
}
void start().catch(error=>{
  const root=document.getElementById('root');if(!root)return;
  const heading=document.createElement('h1');heading.textContent='CodeStudio';
  const message=document.createElement('p');message.textContent=t('CodeStudio konnte nicht gestartet werden.');
  const detail=document.createElement('pre');detail.textContent=error instanceof Error?error.message:String(error);
  root.replaceChildren(heading,message,detail);
});
