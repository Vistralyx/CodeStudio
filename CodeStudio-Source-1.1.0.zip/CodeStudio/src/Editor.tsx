import {forwardRef,useEffect,useImperativeHandle,useRef} from 'react';
import * as monaco from 'monaco-editor';
import EditorWorker from 'monaco-editor/editor/editor.worker.js?worker';
import JsonWorker from 'monaco-editor/languages/features/json/json.worker.js?worker';
import CssWorker from 'monaco-editor/languages/features/css/css.worker.js?worker';
import HtmlWorker from 'monaco-editor/languages/features/html/html.worker.js?worker';
import TsWorker from 'monaco-editor/languages/features/typescript/ts.worker.js?worker';
import {parseDocument,LineCounter} from 'yaml';
import type {Settings} from './shared';
import {t} from './i18n';

(globalThis as any).MonacoEnvironment={getWorker(_id:string,label:string){if(label==='json')return new JsonWorker();if(['css','scss','less'].includes(label))return new CssWorker();if(['html','handlebars','razor'].includes(label))return new HtmlWorker();if(['typescript','javascript'].includes(label))return new TsWorker();return new EditorWorker()}};
monaco.editor.defineTheme('studio-dark',{base:'vs-dark',inherit:true,rules:[{token:'comment',foreground:'737d87'},{token:'keyword',foreground:'b9a5d4'},{token:'string',foreground:'a4ba9d'},{token:'number',foreground:'c6b18c'}],colors:{'editor.background':'#111315','editor.foreground':'#d3d7dc','editorLineNumber.foreground':'#626a73','editorLineNumber.activeForeground':'#d3d7dc','editor.lineHighlightBackground':'#191c20','editor.selectionBackground':'#344459','editor.inactiveSelectionBackground':'#2b343f','editorCursor.foreground':'#b6cce5','editorIndentGuide.background1':'#262a30','editorWidget.background':'#202328','editorWidget.border':'#3b4149','editorGutter.background':'#111315'}});
monaco.editor.defineTheme('studio-light',{base:'vs',inherit:true,rules:[],colors:{'editor.background':'#fafbfc','editor.foreground':'#252a31','editorLineNumber.foreground':'#8a929c','editor.lineHighlightBackground':'#f0f2f5','editor.selectionBackground':'#d4e2f1','editorWidget.background':'#ffffff','editorWidget.border':'#cdd3db','editorGutter.background':'#fafbfc'}});
monaco.typescript.typescriptDefaults.setCompilerOptions({target:monaco.typescript.ScriptTarget.ESNext,module:monaco.typescript.ModuleKind.ESNext,allowNonTsExtensions:true,allowJs:true,strict:true,jsx:monaco.typescript.JsxEmit.React,noEmit:true});
monaco.typescript.javascriptDefaults.setDiagnosticsOptions({noSemanticValidation:true,noSyntaxValidation:false});
monaco.json.jsonDefaults.setDiagnosticsOptions({validate:true,allowComments:false,schemas:[]});
export const languageFor=(p:string)=>{const e=p.split('.').pop()?.toLowerCase();return ({html:'html',htm:'html',css:'css',scss:'scss',js:'javascript',mjs:'javascript',cjs:'javascript',jsx:'javascript',ts:'typescript',tsx:'typescript',py:'python',java:'java',kt:'kotlin',kts:'kotlin',json:'json',yaml:'yaml',yml:'yaml',md:'markdown',mdx:'markdown',c:'c',h:'c',cpp:'cpp',hpp:'cpp',cc:'cpp',cs:'csharp',sql:'sql',ps1:'powershell',xml:'xml',svg:'xml',sh:'shell',bat:'bat',txt:'plaintext'} as Record<string,string>)[e||'']||'plaintext'};
export interface EditorHandle {action:(id:string)=>Promise<void>;selection:()=>string;focus:()=>void;reveal:(line:number)=>void}
export interface EditorDoc {path:string;content:string;hash?:string;revision?:number}
function validateYaml(model:monaco.editor.ITextModel){
  if(model.getLanguageId()!=='yaml')return;
  const lineCounter=new LineCounter(),doc=parseDocument(model.getValue(),{lineCounter});
  monaco.editor.setModelMarkers(model,'yaml',doc.errors.map(error=>{
    const start=error.linePos?.[0]||lineCounter.linePos(error.pos[0]),end=error.linePos?.[1]||lineCounter.linePos(error.pos[1]);
    return {severity:monaco.MarkerSeverity.Error,message:error.message,startLineNumber:start.line||1,startColumn:start.col||1,endLineNumber:end.line||start.line||1,endColumn:end.col>start.col||end.line>start.line?end.col:(start.col||1)+1};
  }));
}
export const CodeEditor=forwardRef<EditorHandle,{file:EditorDoc|null;openPaths?:string[];settings:Settings;onChange:(path:string,content:string)=>void;onPosition:(p:{line:number;column:number})=>void;onProblems:(p:{path:string;line:number;message:string;severity:number}[])=>void}>(({file,openPaths,settings,onChange,onPosition,onProblems},ref)=>{
  const host=useRef<HTMLDivElement>(null),editor=useRef<monaco.editor.IStandaloneCodeEditor|null>(null),models=useRef(new Map<string,monaco.editor.ITextModel>()),views=useRef(new Map<string,monaco.editor.ICodeEditorViewState|null>()),current=useRef<string|null>(null),suppress=useRef(false),callbacks=useRef({onChange,onPosition,onProblems});callbacks.current={onChange,onPosition,onProblems};
  const instance=useRef('');if(!instance.current)instance.current=crypto.randomUUID();
  const reportProblems=()=>callbacks.current.onProblems([...models.current.entries()].flatMap(([path,model])=>monaco.editor.getModelMarkers({resource:model.uri}).map(marker=>({path,line:marker.startLineNumber,message:marker.message,severity:marker.severity}))));
  useImperativeHandle(ref,()=>({action:async id=>{
    const ed=editor.current;if(!ed)return;
    const ids:Record<string,string>={undo:'undo',redo:'redo',find:'actions.find',replace:'editor.action.startFindReplaceAction',comment:'editor.action.commentLine',format:'editor.action.formatDocument','select-all':'editor.action.selectAll','multi-cursor':'editor.action.addSelectionToNextFindMatch',duplicate:'editor.action.copyLinesDownAction','select-occurrences':'editor.action.selectHighlights'};
    if(['cut','copy','paste'].includes(id)){
      ed.focus();const model=ed.getModel(),selections=ed.getSelections();if(!model||!selections?.length)return;
      const version=model.getVersionId();
      if(id==='paste'){
        const text=await window.studio.invoke<string>('app.clipboardRead');
        if(ed.getModel()!==model||model.getVersionId()!==version)throw new Error(t('Die Datei wurde zwischenzeitlich geändert. Bitte Einfügen erneut ausführen.'));
        ed.setSelections(selections);ed.pushUndoStop();ed.trigger('menu','paste',{text});ed.pushUndoStop();return;
      }
      const text=selections.map(selection=>selection.isEmpty()?model.getLineContent(selection.startLineNumber)+model.getEOL():model.getValueInRange(selection)).join(model.getEOL());
      await window.studio.invoke('app.clipboardWrite',{text});
      if(id==='cut'){
        if(ed.getModel()!==model||model.getVersionId()!==version)throw new Error(t('Die Datei wurde zwischenzeitlich geändert. Ausschneiden wurde abgebrochen.'));
        const ranges=selections.map(selection=>selection.isEmpty()?new monaco.Range(selection.startLineNumber,1,selection.startLineNumber,model.getLineMaxColumn(selection.startLineNumber)):selection);
        const unique=[...new Map(ranges.map(range=>[`${range.startLineNumber}:${range.startColumn}:${range.endLineNumber}:${range.endColumn}`,range])).values()];
        ed.pushUndoStop();ed.executeEdits('clipboard',unique.map(range=>({range,text:''})));ed.pushUndoStop();
      }
      return;
    }
    ed.focus();ed.trigger('menu',ids[id]||id,null);
  },selection:()=>{const ed=editor.current;const sel=ed?.getSelection();return sel?ed?.getModel()?.getValueInRange(sel)||'':''},focus:()=>editor.current?.focus(),reveal:line=>{editor.current?.revealLineInCenter(line);editor.current?.setPosition({lineNumber:line,column:1});editor.current?.focus()}}));
  useEffect(()=>{
    const ed=monaco.editor.create(host.current!,{theme:'studio-dark',automaticLayout:true,fontFamily:'Consolas, Cascadia Code, monospace',padding:{top:12,bottom:12},scrollBeyondLastLine:false,renderLineHighlight:'line',smoothScrolling:true,bracketPairColorization:{enabled:false},unicodeHighlight:{ambiguousCharacters:false},accessibilitySupport:'auto',fixedOverflowWidgets:true});editor.current=ed;
    const change=ed.onDidChangeModelContent(()=>{
      if(!suppress.current&&current.current)callbacks.current.onChange(current.current,ed.getValue());
      const model=ed.getModel();if(model)validateYaml(model);
    });
    const pos=ed.onDidChangeCursorPosition(e=>callbacks.current.onPosition({line:e.position.lineNumber,column:e.position.column}));
    const markers=monaco.editor.onDidChangeMarkers(reportProblems);
    return()=>{change.dispose();pos.dispose();markers.dispose();ed.setModel(null);ed.dispose();models.current.forEach(m=>m.dispose());models.current.clear()};
  },[]);
  useEffect(()=>{
    const ed=editor.current;if(!ed)return;if(current.current)views.current.set(current.current,ed.saveViewState());current.current=file?.path||null;
    if(!file){ed.setModel(null);return}
    let model=models.current.get(file.path);
    if(!model){const uri=file.path.startsWith('untitled:')?monaco.Uri.from({scheme:'untitled',authority:'codestudio',path:`/${instance.current}/${file.path.slice(9)}`}):monaco.Uri.file(file.path);model=monaco.editor.createModel(file.content,languageFor(file.path),uri);models.current.set(file.path,model)}
    suppress.current=true;try{if(model.getValue()!==file.content)model.setValue(file.content);ed.setModel(model);ed.restoreViewState(views.current.get(file.path)||null)}finally{suppress.current=false}
    validateYaml(model);ed.focus();
  },[file?.path]);
  useEffect(()=>{
    const ed=editor.current,model=ed?.getModel();if(!ed||!model||!file||current.current!==file.path)return;
    if(model.getValue()===file.content)return;
    const view=ed.saveViewState();suppress.current=true;
    try{model.setValue(file.content);ed.restoreViewState(view);validateYaml(model)}finally{suppress.current=false}
    // Monaco owns local edits. Only an explicit external-content revision may
    // replace the model; ordinary React echoes and saving never reset its text.
  },[file?.path,file?.revision]);
  useEffect(()=>{
    if(!openPaths)return;
    const keep=new Set(openPaths);let removed=false;
    for(const [path,model] of models.current){
      if(keep.has(path))continue;
      if(editor.current?.getModel()===model)editor.current.setModel(null);
      models.current.delete(path);views.current.delete(path);model.dispose();removed=true;
    }
    if(removed)reportProblems();
  },[openPaths,file?.path]);
  useEffect(()=>{monaco.editor.setTheme(settings.theme==='dark'?'studio-dark':'studio-light');editor.current?.updateOptions({fontSize:settings.fontSize,tabSize:settings.tabSize,insertSpaces:settings.insertSpaces,wordWrap:settings.wordWrap?'on':'off',minimap:{enabled:settings.minimap},autoIndent:'full',autoClosingBrackets:'always',formatOnPaste:false});models.current.forEach(m=>m.updateOptions({tabSize:settings.tabSize,insertSpaces:settings.insertSpaces}))},[settings]);
  return <div className="editor-host" ref={host} aria-label={t('Code-Editor')}/>;
});
export function DiffView({before,after,path,theme}:{before:string;after:string;path:string;theme:string}){const host=useRef<HTMLDivElement>(null);useEffect(()=>{const original=monaco.editor.createModel(before,languageFor(path)),modified=monaco.editor.createModel(after,languageFor(path));const ed=monaco.editor.createDiffEditor(host.current!,{theme:theme==='dark'?'studio-dark':'studio-light',automaticLayout:true,readOnly:true,originalEditable:false,renderSideBySide:true,renderGutterMenu:false,minimap:{enabled:false},fontSize:13});ed.setModel({original,modified});return()=>{ed.setModel(null);ed.dispose();original.dispose();modified.dispose()}},[before,after,path,theme]);return <div className="diff-host" ref={host}/>}
