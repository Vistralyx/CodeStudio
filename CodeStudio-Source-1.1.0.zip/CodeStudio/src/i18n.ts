import type {Locale} from './shared';
import {messages as appMessages} from './locales/app';
import {messages as panelMessages} from './locales/panels';
import {messages as backendMessages} from './locales/backend';
import type {MessageCatalogue,Translations} from './locales/types';

export type {Locale} from './shared';
export const languages:ReadonlyArray<{id:Locale;label:string}>=Object.freeze([
  {id:'en',label:'English'},{id:'de',label:'Deutsch'},{id:'es',label:'Español'},
  {id:'fr',label:'Français'},{id:'it',label:'Italiano'},
]);
export function normalizeLocale(value:unknown):Locale {
  return typeof value==='string'&&languages.some(language=>language.id===value)?value as Locale:'en';
}

const sources=[['app',appMessages],['panels',panelMessages],['backend',backendMessages]] as const;
const combined:MessageCatalogue=Object.create(null);
export const catalogueConflicts:Array<{source:string;key:string}>=[];
for(const [source,messages] of sources){
  for(const [key,value] of Object.entries(messages)){
    if(Object.hasOwn(combined,key)){
      if((['en','es','fr','it'] as const).some(language=>combined[key][language]!==value[language]))catalogueConflicts.push({source,key});
      continue;
    }
    combined[key]=Object.freeze({...value});
  }
}
export const catalogue:Readonly<MessageCatalogue>=Object.freeze(combined);
const placeholderPattern=/\{([A-Za-z][A-Za-z0-9_]*)\}/g;
const localizableParams=new Set(['label','runtime','action','kind','reason','operation','limit','message']);
function valueFor(locale:Locale,source:string):string {
  return locale==='de'?source:catalogue[source]?.[locale]??source;
}
function format(locale:Locale,text:string,params:Record<string,string|number>):string {
  return text.replace(placeholderPattern,(token,name:string)=>{
    if(!Object.hasOwn(params,name))return token;
    const raw=String(params[name]);
    // Labels are intentional UI vocabulary. User names, paths, model IDs and
    // arbitrary API details must remain byte-for-byte values in the message.
    return localizableParams.has(name)&&Object.hasOwn(catalogue,raw)&&!/[{}]/.test(raw)?valueFor(locale,raw):raw;
  });
}
export function translate(locale:Locale,sourceGerman:string,params:Record<string,string|number>={}):string {
  const language=normalizeLocale(locale);
  return format(language,valueFor(language,sourceGerman),params);
}

function escapeRegExp(value:string):string{return value.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')}
interface MessageTemplate {source:string;expression:RegExp;names:string[];specificity:number}
const templates:MessageTemplate[]=[];
for(const source of Object.keys(catalogue)){
  const matches=[...source.matchAll(placeholderPattern)];if(!matches.length)continue;
  const names:string[]=[],groups=new Map<string,number>();let expression='^',offset=0,specificity=0;
  for(const match of matches){
    const literal=source.slice(offset,match.index);specificity+=literal.length;expression+=escapeRegExp(literal);
    const name=match[1],previous=groups.get(name);
    if(previous!==undefined)expression+=`\\k<p${previous}>`;
    else{const group=names.length;groups.set(name,group);names.push(name);expression+=`(?<p${group}>[\\s\\S]*?)`}
    offset=match.index!+match[0].length;
  }
  const tail=source.slice(offset);specificity+=tail.length;expression+=escapeRegExp(tail)+'$';
  // An all-placeholder template must never translate arbitrary OS/API output.
  if(specificity)templates.push({source,expression:new RegExp(expression,'u'),names,specificity});
}
templates.sort((a,b)=>b.specificity-a.specificity||a.source.localeCompare(b.source));
export function localizeMessage(locale:Locale,formattedSourceGerman:string):string {
  const language=normalizeLocale(locale);if(language==='de')return formattedSourceGerman;
  if(Object.hasOwn(catalogue,formattedSourceGerman))return translate(language,formattedSourceGerman);
  for(const template of templates){
    const result=template.expression.exec(formattedSourceGerman);if(!result)continue;
    const params:Record<string,string>=Object.create(null);
    template.names.forEach((name,index)=>{params[name]=result.groups?.['p'+index]??''});
    return translate(language,template.source,params);
  }
  return formattedSourceGerman;
}

let currentLanguage:Locale='en';
export function setLanguage(value:unknown):Locale {currentLanguage=normalizeLocale(value);return currentLanguage}
export function getLanguage():Locale{return currentLanguage}
export function t(sourceGerman:string,params?:Record<string,string|number>):string{return translate(currentLanguage,sourceGerman,params)}
