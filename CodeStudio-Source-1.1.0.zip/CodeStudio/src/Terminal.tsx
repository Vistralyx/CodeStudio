import {t as tr} from './i18n';
import {useEffect,useRef} from 'react';
import {Terminal} from '@xterm/xterm';
import {FitAddon} from '@xterm/addon-fit';
import '@xterm/xterm/css/xterm.css';

export interface TerminalSession {id:string;title:string;exitCode?:number;run?:boolean}
interface TerminalData {id:string;data:string;sequence:number}
interface TerminalBuffer {data:string;sequence:number;exitCode?:number}
const dark={background:'#111315',foreground:'#d3d7dc',cursor:'#b7c9dd',selectionBackground:'#344459',black:'#252a30',red:'#d49a9a',green:'#a4ba9d',yellow:'#c6b18c',blue:'#94b4d6',magenta:'#b9a5d4',cyan:'#93bdc3',white:'#d3d7dc'};
const light={background:'#fafbfc',foreground:'#252a31',cursor:'#3c5a7b',selectionBackground:'#c6d8ec',black:'#252a31',red:'#a13030',green:'#3b6a3e',yellow:'#87641b',blue:'#2a5f99',magenta:'#76549b',cyan:'#246b77',white:'#e0e3e8'};

export default function TerminalPane({session,active,theme,onError}:{session:TerminalSession;active:boolean;theme:string;onError:(e:unknown)=>void}){
  const host=useRef<HTMLDivElement>(null),term=useRef<Terminal|null>(null),fit=useRef<FitAddon|null>(null),err=useRef(onError);
  const receiveExit=useRef<((exitCode:number)=>void)|null>(null);
  err.current=onError;
  useEffect(()=>{
    const element=host.current!;
    const t=new Terminal({theme:theme==='dark'?dark:light,fontFamily:'Consolas, Cascadia Code, monospace',fontSize:13,cursorBlink:true,convertEol:false,scrollback:5000,allowProposedApi:false});
    const f=new FitAddon();t.loadAddon(f);t.open(element);term.current=t;fit.current=f;
    let loading=true,alive=true,ended=session.exitCode!==undefined,exitWritten=false,lastSequence=0;
    let pendingExit=session.exitCode;
    const queue:TerminalData[]=[];
    const report=(error:unknown)=>{if(alive)err.current(error)};
    const writeExit=(exitCode:number)=>{
      pendingExit=exitCode;ended=true;t.options.disableStdin=true;
      if(!loading&&!exitWritten){exitWritten=true;t.write(`\r\n[${tr("Prozess beendet · Exitcode {code}",{code:exitCode})}]\r\n`)}
    };
    receiveExit.current=writeExit;
    const writeData=(event:TerminalData)=>{
      // Delayed IPC events already included in the snapshot must not appear twice.
      if(event.sequence<=lastSequence)return;
      lastSequence=event.sequence;t.write(event.data);
    };
    const input=t.onData(data=>{
      if(!alive||ended)return;
      window.studio.invoke('terminal.write',{id:session.id,data}).catch(error=>{if(alive&&!ended)report(error)});
    });
    // Register both streams before requesting history: a process can finish
    // between capturing the buffer and delivering its IPC response to React.
    const offData=window.studio.on('terminal.data',(event:TerminalData)=>{
      if(event.id!==session.id||!alive)return;
      if(loading)queue.push(event);else writeData(event);
    });
    const offExit=window.studio.on('terminal.exit',event=>{if(event.id===session.id&&alive)writeExit(event.exitCode)});
    window.studio.invoke<TerminalBuffer>('terminal.buffer',{id:session.id}).then(snapshot=>{
      if(!alive)return;
      if(snapshot.exitCode!==undefined){ended=true;pendingExit=snapshot.exitCode;t.options.disableStdin=true}
      lastSequence=snapshot.sequence;t.write(snapshot.data);
      queue.sort((a,b)=>a.sequence-b.sequence).forEach(writeData);queue.length=0;loading=false;
      if(pendingExit!==undefined)writeExit(pendingExit);
    }).catch(error=>{
      if(!alive)return;
      queue.sort((a,b)=>a.sequence-b.sequence).forEach(writeData);queue.length=0;loading=false;
      if(pendingExit!==undefined)writeExit(pendingExit);
      report(error);
    });
    const paste=(text:string)=>{
      if(!alive||ended||!text)return;
      if(text.length>1_000_000){report(new Error(tr("Der Zwischenablagetext ist für eine einzelne Terminaleingabe zu groß.")));return}
      // Preserve xterm's bracketed-paste protocol and newline handling.
      t.paste(text);
    };
    const copy=()=>{const text=t.getSelection();if(text)window.studio.invoke('app.clipboardWrite',{text}).catch(report)};
    const pasteFromClipboard=()=>{if(!ended)window.studio.invoke<string>('app.clipboardRead').then(paste).catch(report)};
    t.attachCustomKeyEventHandler(event=>{
      if(event.type!=='keydown')return true;
      const copyKey=event.ctrlKey&&!event.altKey&&event.code==='KeyC'&&(event.shiftKey||t.hasSelection());
      const pasteKey=(event.ctrlKey&&!event.altKey&&event.code==='KeyV')||(event.shiftKey&&!event.ctrlKey&&event.code==='Insert');
      if(!copyKey&&!pasteKey)return true;
      event.preventDefault();event.stopPropagation();if(copyKey)copy();else pasteFromClipboard();return false;
    });
    const nativePaste=(event:ClipboardEvent)=>{
      event.preventDefault();event.stopPropagation();
      const text=event.clipboardData?.getData('text/plain');
      if(text!==undefined)paste(text);else pasteFromClipboard();
    };
    element.addEventListener('paste',nativePaste,true);
    const resize=()=>{
      if(!alive||!element.clientWidth||!element.clientHeight)return;
      f.fit();if(!ended)window.studio.invoke('terminal.resize',{id:session.id,cols:t.cols,rows:t.rows}).catch(()=>{});
    };
    const observer=new ResizeObserver(resize);observer.observe(element);resize();
    return()=>{
      alive=false;receiveExit.current=null;offData();offExit();input.dispose();observer.disconnect();element.removeEventListener('paste',nativePaste,true);
      if(term.current===t){term.current=null;fit.current=null}t.dispose();
    };
  },[session.id]);
  useEffect(()=>{if(session.exitCode!==undefined)receiveExit.current?.(session.exitCode)},[session.exitCode]);
  useEffect(()=>{if(term.current)term.current.options.theme=theme==='dark'?dark:light},[theme]);
  useEffect(()=>{
    if(!active)return;
    const frame=requestAnimationFrame(()=>{
      const t=term.current;if(!t||!host.current?.clientWidth||!host.current?.clientHeight)return;
      fit.current?.fit();t.focus();if(session.exitCode===undefined)window.studio.invoke('terminal.resize',{id:session.id,cols:t.cols,rows:t.rows}).catch(()=>{});
    });
    return()=>cancelAnimationFrame(frame);
  },[active,session.id]);
  return <div className="terminal-host" ref={host} style={{display:active?'block':'none'}} aria-label={session.title}/>;
}
