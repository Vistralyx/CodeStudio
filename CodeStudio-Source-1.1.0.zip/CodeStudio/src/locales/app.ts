import type {MessageCatalogue} from "./types";
export const messages:MessageCatalogue={
  "Neues Projekt": {
    "en": "New project",
    "es": "Nuevo proyecto",
    "fr": "Nouveau projet",
    "it": "Nuovo progetto"
  },
  "Name des neuen Projektordners": {
    "en": "New project folder name",
    "es": "Nombre de la carpeta del proyecto",
    "fr": "Nom du nouveau dossier de projet",
    "it": "Nome della nuova cartella del progetto"
  },
  "Mein Projekt": {
    "en": "My project",
    "es": "Mi proyecto",
    "fr": "Mon projet",
    "it": "Il mio progetto"
  },
  "Öffnen Sie zuerst eine Datei oder wählen Sie eine Projektaufgabe.": {
    "en": "Open a file first or choose a project task.",
    "es": "Abre un archivo o elige una tarea del proyecto.",
    "fr": "Ouvrez un fichier ou choisissez une tâche du projet.",
    "it": "Apri un file o scegli un'attività del progetto."
  },
  "Die Probleme werden im unteren Bereich angezeigt.": {
    "en": "Problems are shown in the bottom panel.",
    "es": "Los problemas se muestran en el panel inferior.",
    "fr": "Les problèmes sont affichés dans le panneau inférieur.",
    "it": "I problemi sono mostrati nel pannello inferiore."
  },
  "Für diese Datei sind aktuell keine Editor-Diagnosen vorhanden.": {
    "en": "There are no current editor diagnostics for this file.",
    "es": "No hay diagnósticos del editor para este archivo.",
    "fr": "Aucun diagnostic de l'éditeur pour ce fichier.",
    "it": "Non ci sono diagnostiche dell'editor per questo file."
  },
  "Neue Datei": {
    "en": "New file",
    "es": "Nuevo archivo",
    "fr": "Nouveau fichier",
    "it": "Nuovo file"
  },
  "Neuer Ordner": {
    "en": "New folder",
    "es": "Nueva carpeta",
    "fr": "Nouveau dossier",
    "it": "Nuova cartella"
  },
  "Name": {
    "en": "Name",
    "es": "Nombre",
    "fr": "Nom",
    "it": "Nome"
  },
  "Neuer Name": {
    "en": "New name",
    "es": "Nuevo nombre",
    "fr": "Nouveau nom",
    "it": "Nuovo nome"
  },
  "Zielordner (vollständiger Pfad)": {
    "en": "Destination folder (full path)",
    "es": "Carpeta de destino (ruta completa)",
    "fr": "Dossier de destination (chemin complet)",
    "it": "Cartella di destinazione (percorso completo)"
  },
  "Öffnen Sie zuerst ein Projekt für Dateiänderungen.": {
    "en": "Open a project before applying file changes.",
    "es": "Abre un proyecto antes de modificar archivos.",
    "fr": "Ouvrez un projet avant de modifier les fichiers.",
    "it": "Apri un progetto prima di modificare i file."
  },
  "Speichern oder schließen Sie zuerst die ungespeicherten Änderungen der betroffenen Dateien.": {
    "en": "Save or close unsaved changes in the affected files first.",
    "es": "Guarda o cierra los cambios sin guardar de los archivos afectados.",
    "fr": "Enregistrez ou fermez d'abord les modifications des fichiers concernés.",
    "it": "Salva o chiudi prima le modifiche non salvate nei file interessati."
  },
  "Änderungen übernommen. Über „Änderungen rückgängig“ können Sie den letzten Satz zurücknehmen.": {
    "en": "Changes applied. Use “Undo changes” to revert the last set.",
    "es": "Cambios aplicados. Usa «Deshacer cambios» para revertir el último conjunto.",
    "fr": "Modifications appliquées. Utilisez «Annuler les modifications» pour rétablir le dernier lot.",
    "it": "Modifiche applicate. Usa «Annulla modifiche» per ripristinare l'ultimo gruppo."
  },
  "Letzte übernommene Dateiänderungen rückgängig gemacht.": {
    "en": "Last applied file changes undone.",
    "es": "Se deshicieron los últimos cambios de archivos.",
    "fr": "Les dernières modifications de fichiers ont été annulées.",
    "it": "Ultime modifiche ai file annullate."
  },
  "Öffnen Sie zuerst eine Datei.": {
    "en": "Open a file first.",
    "es": "Abre primero un archivo.",
    "fr": "Ouvrez d'abord un fichier.",
    "it": "Apri prima un file."
  },
  "Speichern Sie die Datei vor dem Anheften, damit der gesendete Dateistand eindeutig ist.": {
    "en": "Save the file before attaching it so the shared version is clear.",
    "es": "Guarda el archivo antes de adjuntarlo para identificar su versión.",
    "fr": "Enregistrez le fichier avant de le joindre pour identifier la version partagée.",
    "it": "Salva il file prima di allegarlo per identificare la versione condivisa."
  },
  "Markieren Sie zuerst Code im Editor.": {
    "en": "Select some code in the editor first.",
    "es": "Selecciona primero código en el editor.",
    "fr": "Sélectionnez d'abord du code dans l'éditeur.",
    "it": "Seleziona prima del codice nell'editor."
  },
  "Bitte starten Sie CodeStudio über die Desktop-Anwendung.": {
    "en": "Please start CodeStudio using the desktop application.",
    "es": "Inicia CodeStudio desde la aplicación de escritorio.",
    "fr": "Lancez CodeStudio depuis l'application de bureau.",
    "it": "Avvia CodeStudio dall'applicazione desktop."
  },
  "Externe Dateiänderungen können derzeit nicht überwacht werden.": {
    "en": "External file changes cannot be monitored right now.",
    "es": "No se pueden supervisar los cambios externos de archivos.",
    "fr": "Impossible de surveiller les modifications externes des fichiers.",
    "it": "Al momento non è possibile monitorare le modifiche esterne ai file."
  },
  "Arbeitsplatz wird geöffnet …": {
    "en": "Opening workspace…",
    "es": "Abriendo espacio de trabajo…",
    "fr": "Ouverture de l'espace de travail…",
    "it": "Apertura dell'area di lavoro…"
  },
  "Datei": {
    "en": "File",
    "es": "Archivo",
    "fr": "Fichier",
    "it": "File"
  },
  "Bearbeiten": {
    "en": "Edit",
    "es": "Editar",
    "fr": "Édition",
    "it": "Modifica"
  },
  "Auswahl": {
    "en": "Selection",
    "es": "Selección",
    "fr": "Sélection",
    "it": "Selezione"
  },
  "Ansicht": {
    "en": "View",
    "es": "Ver",
    "fr": "Affichage",
    "it": "Visualizza"
  },
  "Ausführen": {
    "en": "Run",
    "es": "Ejecutar",
    "fr": "Exécuter",
    "it": "Esegui"
  },
  "Terminal": {
    "en": "Terminal",
    "es": "Terminal",
    "fr": "Terminal",
    "it": "Terminale"
  },
  "Hilfe": {
    "en": "Help",
    "es": "Ayuda",
    "fr": "Aide",
    "it": "Aiuto"
  },
  "Kein Projekt geöffnet": {
    "en": "No project open",
    "es": "No hay proyecto abierto",
    "fr": "Aucun projet ouvert",
    "it": "Nessun progetto aperto"
  },
  "Theme wechseln": {
    "en": "Switch theme",
    "es": "Cambiar tema",
    "fr": "Changer de thème",
    "it": "Cambia tema"
  },
  "Unteren Bereich ein-/ausblenden": {
    "en": "Show or hide bottom panel",
    "es": "Mostrar u ocultar el panel inferior",
    "fr": "Afficher ou masquer le panneau inférieur",
    "it": "Mostra o nascondi il pannello inferiore"
  },
  "Unteren Bereich umschalten": {
    "en": "Toggle bottom panel",
    "es": "Alternar panel inferior",
    "fr": "Basculer le panneau inférieur",
    "it": "Attiva o disattiva il pannello inferiore"
  },
  "Neues Terminal": {
    "en": "New terminal",
    "es": "Nuevo terminal",
    "fr": "Nouveau terminal",
    "it": "Nuovo terminale"
  },
  "Terminal öffnen": {
    "en": "Open terminal",
    "es": "Abrir terminal",
    "fr": "Ouvrir un terminal",
    "it": "Apri terminale"
  },
  "Einstellungen (Strg+,)": {
    "en": "Settings (Ctrl+,)",
    "es": "Configuración (Ctrl+,)",
    "fr": "Paramètres (Ctrl+,)",
    "it": "Impostazioni (Ctrl+,)"
  },
  "Explorer": {
    "en": "Explorer",
    "es": "Explorador",
    "fr": "Explorateur",
    "it": "Esplora file"
  },
  "Suche": {
    "en": "Search",
    "es": "Buscar",
    "fr": "Recherche",
    "it": "Cerca"
  },
  "KI-Assistent": {
    "en": "AI assistant",
    "es": "Asistente de IA",
    "fr": "Assistant IA",
    "it": "Assistente IA"
  },
  "Einstellungen": {
    "en": "Settings",
    "es": "Configuración",
    "fr": "Paramètres",
    "it": "Impostazioni"
  },
  "EXPLORER": {
    "en": "EXPLORER",
    "es": "EXPLORADOR",
    "fr": "EXPLORATEUR",
    "it": "ESPLORA FILE"
  },
  "SUCHE": {
    "en": "SEARCH",
    "es": "BUSCAR",
    "fr": "RECHERCHE",
    "it": "CERCA"
  },
  "KI-ASSISTENT": {
    "en": "AI ASSISTANT",
    "es": "ASISTENTE DE IA",
    "fr": "ASSISTANT IA",
    "it": "ASSISTENTE IA"
  },
  "Seitenleiste schließen": {
    "en": "Close sidebar",
    "es": "Cerrar barra lateral",
    "fr": "Fermer la barre latérale",
    "it": "Chiudi barra laterale"
  },
  "Öffnen Sie einen lokalen Ordner, um Ihre Dateien zu bearbeiten.": {
    "en": "Open a local folder to work with your files.",
    "es": "Abre una carpeta local para editar tus archivos.",
    "fr": "Ouvrez un dossier local pour modifier vos fichiers.",
    "it": "Apri una cartella locale per modificare i file."
  },
  "Projekt öffnen": {
    "en": "Open project",
    "es": "Abrir proyecto",
    "fr": "Ouvrir un projet",
    "it": "Apri progetto"
  },
  "Im Projekt suchen": {
    "en": "Search in project",
    "es": "Buscar en el proyecto",
    "fr": "Rechercher dans le projet",
    "it": "Cerca nel progetto"
  },
  "Im Projekt suchen …": {
    "en": "Search in project…",
    "es": "Buscar en el proyecto…",
    "fr": "Rechercher dans le projet…",
    "it": "Cerca nel progetto…"
  },
  "Öffnen Sie zuerst einen Projektordner.": {
    "en": "Open a project folder first.",
    "es": "Abre primero una carpeta de proyecto.",
    "fr": "Ouvrez d'abord un dossier de projet.",
    "it": "Apri prima una cartella di progetto."
  },
  "Suche läuft …": {
    "en": "Searching…",
    "es": "Buscando…",
    "fr": "Recherche en cours…",
    "it": "Ricerca in corso…"
  },
  "Text in allen Projektdateien finden.": {
    "en": "Find text across project files.",
    "es": "Busca texto en los archivos del proyecto.",
    "fr": "Recherchez du texte dans les fichiers du projet.",
    "it": "Cerca testo nei file del progetto."
  },
  "Ungespeicherte Änderungen": {
    "en": "Unsaved changes",
    "es": "Cambios sin guardar",
    "fr": "Modifications non enregistrées",
    "it": "Modifiche non salvate"
  },
  "Aktive Datei ausführen (F5)": {
    "en": "Run active file (F5)",
    "es": "Ejecutar archivo activo (F5)",
    "fr": "Exécuter le fichier actif (F5)",
    "it": "Esegui file attivo (F5)"
  },
  "Programm stoppen (Umschalt+F5)": {
    "en": "Stop program (Shift+F5)",
    "es": "Detener programa (Mayús+F5)",
    "fr": "Arrêter le programme (Maj+F5)",
    "it": "Ferma programma (Maiusc+F5)"
  },
  "Neue Datei (Strg+N)": {
    "en": "New file (Ctrl+N)",
    "es": "Nuevo archivo (Ctrl+N)",
    "fr": "Nouveau fichier (Ctrl+N)",
    "it": "Nuovo file (Ctrl+N)"
  },
  "Vorschau schließen": {
    "en": "Close preview",
    "es": "Cerrar vista previa",
    "fr": "Fermer l'aperçu",
    "it": "Chiudi anteprima"
  },
  "Diese Datei wurde außerhalb von CodeStudio geändert oder entfernt.": {
    "en": "This file was changed or removed outside CodeStudio.",
    "es": "Este archivo se modificó o eliminó fuera de CodeStudio.",
    "fr": "Ce fichier a été modifié ou supprimé hors de CodeStudio.",
    "it": "Questo file è stato modificato o rimosso fuori da CodeStudio."
  },
  "Editoränderungen verwerfen und Datei neu laden?": {
    "en": "Discard editor changes and reload the file?",
    "es": "¿Descartar los cambios del editor y recargar el archivo?",
    "fr": "Ignorer les modifications de l'éditeur et recharger le fichier ?",
    "it": "Scartare le modifiche dell'editor e ricaricare il file?"
  },
  "Neu laden": {
    "en": "Reload",
    "es": "Recargar",
    "fr": "Recharger",
    "it": "Ricarica"
  },
  "Editorinhalt behalten": {
    "en": "Keep editor content",
    "es": "Conservar contenido del editor",
    "fr": "Conserver le contenu de l'éditeur",
    "it": "Mantieni contenuto dell'editor"
  },
  "Lokale Webvorschau": {
    "en": "Local web preview",
    "es": "Vista previa web local",
    "fr": "Aperçu web local",
    "it": "Anteprima web locale"
  },
  "Ein klarer Platz für Ihren nächsten Gedanken in Code.": {
    "en": "A clear space for your next idea in code.",
    "es": "Un espacio claro para tu próxima idea en código.",
    "fr": "Un espace clair pour votre prochaine idée en code.",
    "it": "Uno spazio ordinato per la tua prossima idea in codice."
  },
  "Loslegen": {
    "en": "Get started",
    "es": "Comenzar",
    "fr": "Bien démarrer",
    "it": "Inizia"
  },
  "Einen lokalen Ordner auswählen": {
    "en": "Choose a local folder",
    "es": "Elegir una carpeta local",
    "fr": "Choisir un dossier local",
    "it": "Scegli una cartella locale"
  },
  "Strg K": {
    "en": "Ctrl K",
    "es": "Ctrl K",
    "fr": "Ctrl K",
    "it": "Ctrl K"
  },
  "An einem Ort Ihrer Wahl erstellen": {
    "en": "Create it wherever you choose",
    "es": "Crear donde prefieras",
    "fr": "Créer à l'emplacement de votre choix",
    "it": "Crea dove preferisci"
  },
  "Eine Idee direkt aufschreiben": {
    "en": "Start writing an idea",
    "es": "Empieza a escribir una idea",
    "fr": "Commencer à écrire une idée",
    "it": "Inizia a scrivere un'idea"
  },
  "Strg N": {
    "en": "Ctrl N",
    "es": "Ctrl N",
    "fr": "Ctrl N",
    "it": "Ctrl N"
  },
  "Zuletzt geöffnet": {
    "en": "Recent projects",
    "es": "Proyectos recientes",
    "fr": "Projets récents",
    "it": "Progetti recenti"
  },
  "Ihre Projekte erscheinen hier,": {
    "en": "Your projects appear here",
    "es": "Tus proyectos aparecerán aquí",
    "fr": "Vos projets apparaîtront ici",
    "it": "I tuoi progetti appariranno qui"
  },
  "sobald Sie einen Ordner öffnen.": {
    "en": "after you open a folder.",
    "es": "cuando abras una carpeta.",
    "fr": "après l'ouverture d'un dossier.",
    "it": "dopo aver aperto una cartella."
  },
  "Kurzanleitung öffnen": {
    "en": "Open quick guide",
    "es": "Abrir guía rápida",
    "fr": "Ouvrir le guide rapide",
    "it": "Apri guida rapida"
  },
  "Lokal arbeiten": {
    "en": "Work locally",
    "es": "Trabajo local",
    "fr": "Travail local",
    "it": "Lavora in locale"
  },
  "KI optional": {
    "en": "Optional AI",
    "es": "IA opcional",
    "fr": "IA facultative",
    "it": "IA opzionale"
  },
  "Keine Anmeldung erforderlich": {
    "en": "No sign-in required",
    "es": "Sin inicio de sesión",
    "fr": "Aucune connexion requise",
    "it": "Nessun accesso richiesto"
  },
  "Höhe des unteren Bereichs": {
    "en": "Bottom panel height",
    "es": "Altura del panel inferior",
    "fr": "Hauteur du panneau inférieur",
    "it": "Altezza del pannello inferiore"
  },
  "TERMINAL": {
    "en": "TERMINAL",
    "es": "TERMINAL",
    "fr": "TERMINAL",
    "it": "TERMINALE"
  },
  "AUSGABE": {
    "en": "OUTPUT",
    "es": "SALIDA",
    "fr": "SORTIE",
    "it": "OUTPUT"
  },
  "PROBLEME": {
    "en": "PROBLEMS",
    "es": "PROBLEMAS",
    "fr": "PROBLÈMES",
    "it": "PROBLEMI"
  },
  "Sitzung wählen": {
    "en": "Choose session",
    "es": "Elegir sesión",
    "fr": "Choisir une session",
    "it": "Scegli sessione"
  },
  "Aktive Sitzung schließen": {
    "en": "Close active session",
    "es": "Cerrar sesión activa",
    "fr": "Fermer la session active",
    "it": "Chiudi sessione attiva"
  },
  "Bereich schließen": {
    "en": "Close panel",
    "es": "Cerrar panel",
    "fr": "Fermer le panneau",
    "it": "Chiudi pannello"
  },
  "Ein echtes Terminal für Ihr Projekt.": {
    "en": "An interactive terminal for your project.",
    "es": "Un terminal interactivo para tu proyecto.",
    "fr": "Un terminal interactif pour votre projet.",
    "it": "Un terminale interattivo per il tuo progetto."
  },
  "PowerShell öffnen": {
    "en": "Open PowerShell",
    "es": "Abrir PowerShell",
    "fr": "Ouvrir PowerShell",
    "it": "Apri PowerShell"
  },
  "cmd öffnen": {
    "en": "Open cmd",
    "es": "Abrir cmd",
    "fr": "Ouvrir cmd",
    "it": "Apri cmd"
  },
  "Programmausgaben erscheinen hier. Das interaktive Terminal führt Standard- und Fehlerausgabe zusammen.": {
    "en": "Program output appears here. The interactive terminal combines standard output and errors.",
    "es": "La salida del programa aparece aquí. El terminal combina la salida estándar y los errores.",
    "fr": "La sortie du programme apparaît ici. Le terminal combine sortie standard et erreurs.",
    "it": "L'output del programma appare qui. Il terminale combina output standard ed errori."
  },
  "Keine aktuellen Editor-Diagnosen. Der Funktionsumfang hängt vom Sprachdienst ab.": {
    "en": "No current editor diagnostics. Features depend on the language service.",
    "es": "No hay diagnósticos actuales. Las funciones dependen del servicio de lenguaje.",
    "fr": "Aucun diagnostic actuel. Les fonctions dépendent du service de langage.",
    "it": "Nessuna diagnostica attuale. Le funzioni dipendono dal servizio del linguaggio."
  },
  "Kein Projekt": {
    "en": "No project",
    "es": "Sin proyecto",
    "fr": "Aucun projet",
    "it": "Nessun progetto"
  },
  "Probleme anzeigen": {
    "en": "Show problems",
    "es": "Mostrar problemas",
    "fr": "Afficher les problèmes",
    "it": "Mostra problemi"
  },
  "Programm läuft": {
    "en": "Program running",
    "es": "Programa en ejecución",
    "fr": "Programme en cours",
    "it": "Programma in esecuzione"
  },
  "Ze": {
    "en": "Ln",
    "es": "Lín",
    "fr": "Lig",
    "it": "Riga"
  },
  ", Sp": {
    "en": ", Col",
    "es": ", Col",
    "fr": ", Col",
    "it": ", Col"
  },
  "Text": {
    "en": "Text",
    "es": "Texto",
    "fr": "Texte",
    "it": "Testo"
  },
  "Meldung schließen": {
    "en": "Dismiss message",
    "es": "Cerrar mensaje",
    "fr": "Fermer le message",
    "it": "Chiudi messaggio"
  },
  "Datei schnell öffnen": {
    "en": "Quick open file",
    "es": "Abrir archivo rápidamente",
    "fr": "Ouverture rapide de fichier",
    "it": "Apri file rapidamente"
  },
  "Dateinamen eingeben …": {
    "en": "Type a file name…",
    "es": "Escribe un nombre de archivo…",
    "fr": "Saisissez un nom de fichier…",
    "it": "Digita un nome di file…"
  },
  "Keine passende Datei gefunden.": {
    "en": "No matching file found.",
    "es": "No se encontró ningún archivo.",
    "fr": "Aucun fichier correspondant.",
    "it": "Nessun file corrispondente."
  },
  "Datei öffnen": {
    "en": "Open file",
    "es": "Abrir archivo",
    "fr": "Ouvrir un fichier",
    "it": "Apri file"
  },
  "Verschieben …": {
    "en": "Move…",
    "es": "Mover…",
    "fr": "Déplacer…",
    "it": "Sposta…"
  },
  "In den Papierkorb": {
    "en": "Move to Recycle Bin",
    "es": "Mover a la papelera",
    "fr": "Mettre à la corbeille",
    "it": "Sposta nel cestino"
  },
  "Änderungsvorschläge prüfen": {
    "en": "Review proposed changes",
    "es": "Revisar cambios propuestos",
    "fr": "Examiner les modifications",
    "it": "Esamina modifiche proposte"
  },
  "Diff schließen": {
    "en": "Close diff",
    "es": "Cerrar diferencias",
    "fr": "Fermer les différences",
    "it": "Chiudi confronto"
  },
  "Aktueller gespeicherter Stand": {
    "en": "Current saved version",
    "es": "Versión guardada actual",
    "fr": "Version enregistrée actuelle",
    "it": "Versione salvata attuale"
  },
  "Vorgeschlagener Stand": {
    "en": "Proposed version",
    "es": "Versión propuesta",
    "fr": "Version proposée",
    "it": "Versione proposta"
  },
  "Änderungen rückgängig": {
    "en": "Undo changes",
    "es": "Deshacer cambios",
    "fr": "Annuler les modifications",
    "it": "Annulla modifiche"
  },
  "Einzeln übernehmen": {
    "en": "Apply this change",
    "es": "Aplicar este cambio",
    "fr": "Appliquer cette modification",
    "it": "Applica questa modifica"
  },
  "Auswahl übernehmen": {
    "en": "Apply selected changes",
    "es": "Aplicar cambios seleccionados",
    "fr": "Appliquer la sélection",
    "it": "Applica modifiche selezionate"
  },
  "Projektaufgaben": {
    "en": "Project tasks",
    "es": "Tareas del proyecto",
    "fr": "Tâches du projet",
    "it": "Attività del progetto"
  },
  "Die ausgewählte Aufgabe führt den Build-Code dieses Projekts mit Ihren Benutzerrechten aus.": {
    "en": "The selected task runs this project's build code with your user permissions.",
    "es": "La tarea ejecuta el código de compilación con tus permisos de usuario.",
    "fr": "La tâche exécute le code de compilation du projet avec vos droits utilisateur.",
    "it": "L'attività esegue il codice di compilazione con i tuoi permessi utente."
  },
  "Kein Maven- oder Gradle-Projekt erkannt. Öffnen Sie einen Ordner mit pom.xml oder build.gradle(.kts).": {
    "en": "No Maven or Gradle project found. Open a folder with pom.xml or build.gradle(.kts).",
    "es": "No se encontró un proyecto Maven o Gradle. Abre una carpeta con pom.xml o build.gradle(.kts).",
    "fr": "Aucun projet Maven ou Gradle trouvé. Ouvrez un dossier avec pom.xml ou build.gradle(.kts).",
    "it": "Nessun progetto Maven o Gradle trovato. Apri una cartella con pom.xml o build.gradle(.kts)."
  },
  "Abbrechen": {
    "en": "Cancel",
    "es": "Cancelar",
    "fr": "Annuler",
    "it": "Annulla"
  },
  "Bestätigen": {
    "en": "Confirm",
    "es": "Confirmar",
    "fr": "Confirmer",
    "it": "Conferma"
  },
  "Sprachunterstützung": {
    "en": "Language support",
    "es": "Compatibilidad de lenguajes",
    "fr": "Prise en charge des langages",
    "it": "Supporto dei linguaggi"
  },
  "CodeStudio · Kurzanleitung": {
    "en": "CodeStudio · Quick guide",
    "es": "CodeStudio · Guía rápida",
    "fr": "CodeStudio · Guide rapide",
    "it": "CodeStudio · Guida rapida"
  },
  "Syntaxfarben stehen für HTML, CSS, JavaScript, TypeScript, Python, Java, Kotlin, JSON, YAML, Markdown, C, C++, C#, SQL und PowerShell zur Verfügung.": {
    "en": "Syntax highlighting is available for HTML, CSS, JavaScript, TypeScript, Python, Java, Kotlin, JSON, YAML, Markdown, C, C++, C#, SQL, and PowerShell.",
    "es": "Hay resaltado de sintaxis para HTML, CSS, JavaScript, TypeScript, Python, Java, Kotlin, JSON, YAML, Markdown, C, C++, C#, SQL y PowerShell.",
    "fr": "La coloration syntaxique couvre HTML, CSS, JavaScript, TypeScript, Python, Java, Kotlin, JSON, YAML, Markdown, C, C++, C#, SQL et PowerShell.",
    "it": "L'evidenziazione della sintassi supporta HTML, CSS, JavaScript, TypeScript, Python, Java, Kotlin, JSON, YAML, Markdown, C, C++, C#, SQL e PowerShell."
  },
  "Sprache": {
    "en": "Language",
    "es": "Idioma",
    "fr": "Langue",
    "it": "Lingua"
  },
  "Sprachdienst / Formatierung": {
    "en": "Language service / Formatting",
    "es": "Servicio de lenguaje / Formato",
    "fr": "Service de langage / Formatage",
    "it": "Servizio del linguaggio / Formattazione"
  },
  "Ausführung": {
    "en": "Execution",
    "es": "Ejecución",
    "fr": "Exécution",
    "it": "Esecuzione"
  },
  "Monaco: Syntaxdiagnose, TS-Typprüfung, Vorschläge und Formatierung. Keine vollständige Node-/Projektauflösung.": {
    "en": "Monaco: syntax diagnostics, TS type checking, suggestions, and formatting. Full Node/project resolution is not included.",
    "es": "Monaco: diagnósticos de sintaxis, tipos TS, sugerencias y formato. Sin resolución completa de Node/proyecto.",
    "fr": "Monaco : diagnostics syntaxiques, types TS, suggestions et formatage. Pas de résolution complète Node/projet.",
    "it": "Monaco: diagnostica sintattica, tipi TS, suggerimenti e formattazione. Nessuna risoluzione completa Node/progetto."
  },
  "Node.js; TS: mitgelieferter tsc für einfache Einstiegsskripte (CommonJS).": {
    "en": "Node.js; TS: bundled tsc for simple entry scripts (CommonJS).",
    "es": "Node.js; TS: tsc incluido para scripts sencillos (CommonJS).",
    "fr": "Node.js ; TS : tsc inclus pour les scripts simples (CommonJS).",
    "it": "Node.js; TS: tsc incluso per script semplici (CommonJS)."
  },
  "Monaco-Sprachdienste, Vervollständigung, Formatierung": {
    "en": "Monaco language services, completion, formatting",
    "es": "Servicios de Monaco, completado y formato",
    "fr": "Services Monaco, complétion et formatage",
    "it": "Servizi Monaco, completamento e formattazione"
  },
  "Lokale Webvorschau; CSS über HTML-Einstieg.": {
    "en": "Local web preview; CSS through an HTML entry.",
    "es": "Vista previa local; CSS mediante un archivo HTML.",
    "fr": "Aperçu web local ; CSS via une page HTML.",
    "it": "Anteprima web locale; CSS tramite un file HTML."
  },
  "JSON: Diagnose und Formatierung; YAML: Parserdiagnose und Syntaxfarben": {
    "en": "JSON: diagnostics and formatting; YAML: parser diagnostics and syntax highlighting",
    "es": "JSON: diagnósticos y formato; YAML: diagnósticos del analizador y sintaxis",
    "fr": "JSON : diagnostics et formatage ; YAML : diagnostics d'analyse et coloration",
    "it": "JSON: diagnostica e formattazione; YAML: diagnostica del parser e sintassi"
  },
  "Keine Programmausführung": {
    "en": "No program execution",
    "es": "Sin ejecución de programas",
    "fr": "Pas d'exécution de programme",
    "it": "Nessuna esecuzione di programmi"
  },
  "Syntaxfarben, bereinigte Vorschau": {
    "en": "Syntax highlighting, sanitized preview",
    "es": "Resaltado de sintaxis, vista previa depurada",
    "fr": "Coloration syntaxique, aperçu assaini",
    "it": "Evidenziazione della sintassi, anteprima filtrata"
  },
  "Vorschau über „Ausführen“": {
    "en": "Preview using “Run”",
    "es": "Vista previa con «Ejecutar»",
    "fr": "Aperçu via «Exécuter»",
    "it": "Anteprima con «Esegui»"
  },
  "Syntaxfarben und einfache Wortvorschläge. Kein externer LSP integriert; keine vollständige IntelliSense oder automatische Formatierung.": {
    "en": "Syntax highlighting and basic word suggestions. No external LSP, full IntelliSense, or automatic formatting.",
    "es": "Sintaxis y sugerencias básicas. Sin LSP externo, IntelliSense completo ni formato automático.",
    "fr": "Coloration et suggestions simples. Pas de LSP externe, d'IntelliSense complet ni de formatage automatique.",
    "it": "Sintassi e suggerimenti di base. Nessun LSP esterno, IntelliSense completo o formattazione automatica."
  },
  "Python / JDK / kotlinc; erkannte Maven-/Gradle-Aufgaben": {
    "en": "Python / JDK / kotlinc; detected Maven/Gradle tasks",
    "es": "Python / JDK / kotlinc; tareas Maven/Gradle detectadas",
    "fr": "Python / JDK / kotlinc ; tâches Maven/Gradle détectées",
    "it": "Python / JDK / kotlinc; attività Maven/Gradle rilevate"
  },
  "Syntaxfarben und Wortvorschläge. Keine semantischen Sprachdienste integriert.": {
    "en": "Syntax highlighting and word suggestions. No semantic language services included.",
    "es": "Sintaxis y sugerencias de palabras. Sin servicios semánticos integrados.",
    "fr": "Coloration et suggestions de mots. Aucun service de langage sémantique intégré.",
    "it": "Sintassi e suggerimenti di parole. Nessun servizio semantico integrato."
  },
  "Manuell über das Terminal mit Ihren Werkzeugen": {
    "en": "Manually in the terminal using your tools",
    "es": "Manualmente en el terminal con tus herramientas",
    "fr": "Manuellement dans le terminal avec vos outils",
    "it": "Manualmente nel terminale con i tuoi strumenti"
  },
  "„Dokument formatieren“ ist nur verfügbar, wenn der integrierte Sprachdienst einen Formatter bereitstellt. Fehlende Laufzeiten werden unter Einstellungen angezeigt.": {
    "en": "“Format document” is available when the language service includes a formatter. Missing runtimes appear in Settings.",
    "es": "«Formatear documento» está disponible si el servicio incluye un formateador. Los entornos faltantes aparecen en Configuración.",
    "fr": "«Formater le document» est disponible si le service inclut un formateur. Les outils manquants apparaissent dans les paramètres.",
    "it": "«Formatta documento» è disponibile se il servizio include un formattatore. I runtime mancanti appaiono nelle impostazioni."
  },
  "Öffnen, schreiben, speichern": {
    "en": "Open, write, save",
    "es": "Abrir, escribir, guardar",
    "fr": "Ouvrir, écrire, enregistrer",
    "it": "Apri, scrivi, salva"
  },
  "Öffnen Sie einen Projektordner über Datei → Projekt öffnen. Unterordner werden im Explorer aufgeklappt; über Rechtsklick können Sie Dateien erstellen, umbenennen, verschieben oder in den Papierkorb legen. Dateien lassen sich auf Ordner ziehen.": {
    "en": "Use File → Open project to select a folder. Expand subfolders in Explorer. Right-click to create, rename, move, or recycle files. Drag files onto folders to move them.",
    "es": "Usa Archivo → Abrir proyecto para elegir una carpeta. Expande subcarpetas en el explorador. Con el botón derecho puedes crear, renombrar, mover o eliminar archivos. Arrastra archivos a carpetas para moverlos.",
    "fr": "Utilisez Fichier → Ouvrir un projet pour choisir un dossier. Développez les sous-dossiers dans l'explorateur. Le clic droit permet de créer, renommer, déplacer ou mettre des fichiers à la corbeille. Glissez les fichiers sur les dossiers pour les déplacer.",
    "it": "Usa File → Apri progetto per scegliere una cartella. Espandi le sottocartelle in Esplora file. Con il tasto destro puoi creare, rinominare, spostare o cestinare i file. Trascina i file sulle cartelle per spostarli."
  },
  "Strg+N erstellt eine Datei, Strg+S speichert und Strg+Umschalt+S öffnet „Speichern unter“. Ein Punkt am Tab kennzeichnet Änderungen. Strg+P öffnet die Dateisuche, Strg+F die Suche im Editor und Strg+Umschalt+F die Projektsuche.": {
    "en": "Ctrl+N creates a file, Ctrl+S saves, and Ctrl+Shift+S opens Save as. A dot on the tab indicates unsaved changes. Ctrl+P opens quick file search, Ctrl+F searches the editor, and Ctrl+Shift+F searches the project.",
    "es": "Ctrl+N crea un archivo, Ctrl+S guarda y Ctrl+Mayús+S abre Guardar como. Un punto indica cambios sin guardar. Ctrl+P busca archivos, Ctrl+F busca en el editor y Ctrl+Mayús+F busca en el proyecto.",
    "fr": "Ctrl+N crée un fichier, Ctrl+S enregistre et Ctrl+Maj+S ouvre Enregistrer sous. Un point signale les modifications. Ctrl+P recherche les fichiers, Ctrl+F dans l'éditeur et Ctrl+Maj+F dans le projet.",
    "it": "Ctrl+N crea un file, Ctrl+S salva e Ctrl+Maiusc+S apre Salva con nome. Un punto indica modifiche non salvate. Ctrl+P cerca file, Ctrl+F nell'editor e Ctrl+Maiusc+F nel progetto."
  },
  "Programme ausprobieren": {
    "en": "Try your programs",
    "es": "Probar programas",
    "fr": "Essayer vos programmes",
    "it": "Prova i programmi"
  },
  "„Ausführen“ oder F5 startet die aktive gespeicherte Datei. Eingaben erfolgen im echten Terminal. „Stoppen“ oder Umschalt+F5 beendet den Prozessbaum. Im Terminal können Sie weitere Werkzeuge und eigene Befehle ausführen. Programme laufen mit Ihren Benutzerrechten.": {
    "en": "Run or F5 starts the active saved file. Enter input in the interactive terminal. Stop or Shift+F5 terminates the process tree. Use the terminal for your own commands and tools. Programs run with your user permissions.",
    "es": "Ejecutar o F5 inicia el archivo activo guardado. Introduce datos en el terminal. Detener o Mayús+F5 termina el árbol de procesos. Usa el terminal para tus comandos y herramientas. Los programas usan tus permisos de usuario.",
    "fr": "Exécuter ou F5 lance le fichier actif enregistré. Saisissez les données dans le terminal. Arrêter ou Maj+F5 termine l'arbre des processus. Le terminal accepte vos commandes et outils. Les programmes utilisent vos droits utilisateur.",
    "it": "Esegui o F5 avvia il file attivo salvato. Inserisci i dati nel terminale. Ferma o Maiusc+F5 termina l'albero dei processi. Usa il terminale per comandi e strumenti. I programmi usano i tuoi permessi utente."
  },
  "HTML öffnet eine isolierte lokale Vorschau mit relativen Ressourcen. CSS verwendet eine HTML-Datei als Einstieg. Browser-JavaScript testen Sie über Ihre HTML-Datei; eine direkt ausgeführte JS-Datei verwendet Node.js.": {
    "en": "HTML opens an isolated local preview with relative resources. CSS uses an HTML entry file. Test browser JavaScript through HTML; running a JS file directly uses Node.js.",
    "es": "HTML abre una vista previa local aislada con recursos relativos. CSS usa una entrada HTML. Prueba JavaScript del navegador desde HTML; ejecutar un archivo JS directamente usa Node.js.",
    "fr": "HTML ouvre un aperçu local isolé avec des ressources relatives. CSS utilise une entrée HTML. Testez JavaScript navigateur via HTML ; un fichier JS exécuté directement utilise Node.js.",
    "it": "HTML apre un'anteprima locale isolata con risorse relative. CSS usa un ingresso HTML. Prova JavaScript del browser tramite HTML; eseguire direttamente un file JS usa Node.js."
  },
  "KI bewusst verwenden": {
    "en": "Use AI deliberately",
    "es": "Usar la IA con control",
    "fr": "Utiliser l'IA en gardant le contrôle",
    "it": "Usa l'IA con controllo"
  },
  "Richten Sie unter Einstellungen → API-Key Ihren Anbieter ein, laden oder wählen Sie ein Modell und testen Sie die Verbindung. Öffnen Sie den Assistenten über das Funkensymbol links. Heften Sie nur die benötigten Dateien oder eine Auswahl an. Strg+Enter sendet die Nachricht.": {
    "en": "Set up a provider under Settings → API key, load or choose a model, and test the connection. Open the assistant using the sparkle icon on the left. Attach only the files or selection you need. Ctrl+Enter sends the message.",
    "es": "Configura un proveedor en Configuración → Clave de API, elige un modelo y prueba la conexión. Abre el asistente con el icono de destellos. Adjunta solo archivos o selecciones necesarios. Ctrl+Enter envía el mensaje.",
    "fr": "Configurez un fournisseur dans Paramètres → Clé API, choisissez un modèle et testez la connexion. Ouvrez l'assistant via l'icône d'étincelles. Joignez uniquement les fichiers ou la sélection utiles. Ctrl+Entrée envoie le message.",
    "it": "Configura un fornitore in Impostazioni → Chiave API, scegli un modello e prova la connessione. Apri l'assistente con l'icona delle scintille. Allega solo file o selezioni necessari. Ctrl+Invio invia il messaggio."
  },
  "Änderungsvorschläge im Format": {
    "en": "File suggestions in the format",
    "es": "Las propuestas de archivos con el formato",
    "fr": "Les propositions de fichiers au format",
    "it": "Le proposte di file nel formato"
  },
  "werden als Diff geprüft. Sie übernehmen sie einzeln oder zusammen und können den letzten übernommenen Satz rückgängig machen. Befehle im Chat führen sich nicht selbst aus.": {
    "en": "are reviewed as a diff. Apply them individually or together, and undo the last applied set. Chat commands do not run automatically.",
    "es": "se revisan como diferencias. Aplícalas por separado o juntas y deshaz el último conjunto. Los comandos del chat no se ejecutan solos.",
    "fr": "sont examinées sous forme de différences. Appliquez-les séparément ou ensemble et annulez le dernier lot. Les commandes du chat ne s'exécutent pas seules.",
    "it": "si esaminano come differenze. Applicale singolarmente o insieme e annulla l'ultimo gruppo. I comandi in chat non si eseguono da soli."
  },
  "Arbeitsplatz anpassen": {
    "en": "Customize your workspace",
    "es": "Personalizar el espacio de trabajo",
    "fr": "Personnaliser l'espace de travail",
    "it": "Personalizza l'area di lavoro"
  },
  "Ziehen Sie die Trennlinien neben der Seitenleiste und über dem Terminal. Strg+, öffnet die Einstellungen; Strg+J blendet den unteren Bereich ein oder aus. Beide Themes umfassen Editor, Chat, Terminal und Dialoge.": {
    "en": "Drag the dividers beside the sidebar and above the terminal. Ctrl+, opens Settings; Ctrl+J toggles the bottom panel. Both themes cover the editor, chat, terminal, and dialogs.",
    "es": "Arrastra los separadores junto a la barra lateral y sobre el terminal. Ctrl+, abre Configuración y Ctrl+J alterna el panel inferior. Ambos temas incluyen editor, chat, terminal y diálogos.",
    "fr": "Faites glisser les séparateurs de la barre latérale et du terminal. Ctrl+, ouvre les paramètres et Ctrl+J bascule le panneau inférieur. Les deux thèmes couvrent éditeur, chat, terminal et dialogues.",
    "it": "Trascina i separatori della barra laterale e del terminale. Ctrl+, apre le impostazioni e Ctrl+J attiva il pannello inferiore. Entrambi i temi includono editor, chat, terminale e finestre."
  },
  "Schließen": {
    "en": "Close",
    "es": "Cerrar",
    "fr": "Fermer",
    "it": "Chiudi"
  },
  "Umbenennen": {
    "en": "Rename",
    "es": "Renombrar",
    "fr": "Renommer",
    "it": "Rinomina"
  },
  "Verschieben": {
    "en": "Move",
    "es": "Mover",
    "fr": "Déplacer",
    "it": "Sposta"
  },
  "Seitenleistenbreite": {
    "en": "Sidebar width",
    "es": "Ancho de la barra lateral",
    "fr": "Largeur de la barre latérale",
    "it": "Larghezza della barra laterale"
  },
  "Stoppen": {
    "en": "Stop",
    "es": "Detener",
    "fr": "Arrêter",
    "it": "Ferma"
  },
  "Markdown-Vorschau": {
    "en": "Markdown preview",
    "es": "Vista previa Markdown",
    "fr": "Aperçu Markdown",
    "it": "Anteprima Markdown"
  },
  "Webvorschau": {
    "en": "Web preview",
    "es": "Vista previa web",
    "fr": "Aperçu web",
    "it": "Anteprima web"
  },
  "Aktualisieren": {
    "en": "Refresh",
    "es": "Actualizar",
    "fr": "Actualiser",
    "it": "Aggiorna"
  },
  "Terminalsitzung": {
    "en": "Terminal session",
    "es": "Sesión de terminal",
    "fr": "Session de terminal",
    "it": "Sessione del terminale"
  },
  "Leerzeichen": {
    "en": "Spaces",
    "es": "Espacios",
    "fr": "Espaces",
    "it": "Spazi"
  },
  "Tabs": {
    "en": "Tabs",
    "es": "Tabulaciones",
    "fr": "Tabulations",
    "it": "Tabulazioni"
  },
  "Unbenannt": {
    "en": "Untitled",
    "es": "Sin título",
    "fr": "Sans titre",
    "it": "Senza titolo"
  },
  "datei.ts": {
    "en": "file.ts",
    "es": "archivo.ts",
    "fr": "fichier.ts",
    "it": "file.ts"
  },
  "{count} Treffer{suffix}": {
    "en": "{count} results{suffix}",
    "es": "{count} resultados{suffix}",
    "fr": "{count} résultats{suffix}",
    "it": "{count} risultati{suffix}"
  },
  " (begrenzt)": {
    "en": " (limited)",
    "es": " (limitados)",
    "fr": " (limités)",
    "it": " (limitati)"
  },
  "Datei schließen {name}": {
    "en": "Close file {name}",
    "es": "Cerrar archivo {name}",
    "fr": "Fermer le fichier {name}",
    "it": "Chiudi file {name}"
  },
  "Änderung auswählen {name}": {
    "en": "Select change {name}",
    "es": "Seleccionar cambio {name}",
    "fr": "Sélectionner la modification {name}",
    "it": "Seleziona modifica {name}"
  },
  " · Exit {code}": {
    "en": " · Exit {code}",
    "es": " · Salida {code}",
    "fr": " · Sortie {code}",
    "it": " · Uscita {code}"
  },
  "[Exitcode {code}]": {
    "en": "[Exit code {code}]",
    "es": "[Código de salida {code}]",
    "fr": "[Code de sortie {code}]",
    "it": "[Codice di uscita {code}]"
  },
  "CodeStudio konnte nicht gestartet werden.": {
    "en": "CodeStudio could not start.",
    "es": "No se pudo iniciar CodeStudio.",
    "fr": "CodeStudio n'a pas pu démarrer.",
    "it": "Impossibile avviare CodeStudio."
  },
  "Sprache ändern und CodeStudio neu starten?": {
    "en": "Change language and restart CodeStudio?",
    "es": "¿Cambiar el idioma y reiniciar CodeStudio?",
    "fr": "Changer de langue et redémarrer CodeStudio ?",
    "it": "Cambiare lingua e riavviare CodeStudio?"
  },
  "Gespeicherte Projekte bleiben erhalten. Offene Terminals und laufende Programme werden beendet.": {
    "en": "Saved projects are kept. Open terminals and running programs will be stopped.",
    "es": "Los proyectos guardados se conservan. Se cerrarán los terminales y programas en ejecución.",
    "fr": "Les projets enregistrés sont conservés. Les terminaux et programmes en cours seront arrêtés.",
    "it": "I progetti salvati vengono mantenuti. I terminali e i programmi in esecuzione verranno chiusi."
  },
  "Datei öffnen …": {
    "en": "Open file…",
    "es": "Abrir archivo…",
    "fr": "Ouvrir un fichier…",
    "it": "Apri file…"
  },
  "Projekt öffnen …": {
    "en": "Open project…",
    "es": "Abrir proyecto…",
    "fr": "Ouvrir un projet…",
    "it": "Apri progetto…"
  },
  "Neues Projekt …": {
    "en": "New project…",
    "es": "Nuevo proyecto…",
    "fr": "Nouveau projet…",
    "it": "Nuovo progetto…"
  },
  "Projekt schließen": {
    "en": "Close project",
    "es": "Cerrar proyecto",
    "fr": "Fermer le projet",
    "it": "Chiudi progetto"
  },
  "Speichern": {
    "en": "Save",
    "es": "Guardar",
    "fr": "Enregistrer",
    "it": "Salva"
  },
  "Speichern unter …": {
    "en": "Save as…",
    "es": "Guardar como…",
    "fr": "Enregistrer sous…",
    "it": "Salva con nome…"
  },
  "Alle speichern": {
    "en": "Save all",
    "es": "Guardar todo",
    "fr": "Tout enregistrer",
    "it": "Salva tutto"
  },
  "Beenden": {
    "en": "Quit",
    "es": "Salir",
    "fr": "Quitter",
    "it": "Esci"
  },
  "Rückgängig": {
    "en": "Undo",
    "es": "Deshacer",
    "fr": "Annuler",
    "it": "Annulla"
  },
  "Wiederholen": {
    "en": "Redo",
    "es": "Rehacer",
    "fr": "Rétablir",
    "it": "Ripeti"
  },
  "Ausschneiden": {
    "en": "Cut",
    "es": "Cortar",
    "fr": "Couper",
    "it": "Taglia"
  },
  "Kopieren": {
    "en": "Copy",
    "es": "Copiar",
    "fr": "Copier",
    "it": "Copia"
  },
  "Einfügen": {
    "en": "Paste",
    "es": "Pegar",
    "fr": "Coller",
    "it": "Incolla"
  },
  "Suchen": {
    "en": "Find",
    "es": "Buscar",
    "fr": "Rechercher",
    "it": "Trova"
  },
  "Ersetzen": {
    "en": "Replace",
    "es": "Reemplazar",
    "fr": "Remplacer",
    "it": "Sostituisci"
  },
  "Kommentar umschalten": {
    "en": "Toggle comment",
    "es": "Alternar comentario",
    "fr": "Basculer le commentaire",
    "it": "Attiva o disattiva commento"
  },
  "Dokument formatieren": {
    "en": "Format document",
    "es": "Formatear documento",
    "fr": "Formater le document",
    "it": "Formatta documento"
  },
  "Alles auswählen": {
    "en": "Select all",
    "es": "Seleccionar todo",
    "fr": "Tout sélectionner",
    "it": "Seleziona tutto"
  },
  "Nächstes Vorkommen hinzufügen": {
    "en": "Add next occurrence",
    "es": "Añadir siguiente coincidencia",
    "fr": "Ajouter l'occurrence suivante",
    "it": "Aggiungi occorrenza successiva"
  },
  "Zeile duplizieren": {
    "en": "Duplicate line",
    "es": "Duplicar línea",
    "fr": "Dupliquer la ligne",
    "it": "Duplica riga"
  },
  "Alle Vorkommen auswählen": {
    "en": "Select all occurrences",
    "es": "Seleccionar todas las coincidencias",
    "fr": "Sélectionner toutes les occurrences",
    "it": "Seleziona tutte le occorrenze"
  },
  "Projektsuche": {
    "en": "Project search",
    "es": "Buscar en el proyecto",
    "fr": "Recherche dans le projet",
    "it": "Ricerca nel progetto"
  },
  "Seitenleiste ein/aus": {
    "en": "Toggle sidebar",
    "es": "Alternar barra lateral",
    "fr": "Basculer la barre latérale",
    "it": "Attiva o disattiva barra laterale"
  },
  "Unterer Bereich ein/aus": {
    "en": "Toggle bottom panel",
    "es": "Alternar panel inferior",
    "fr": "Basculer le panneau inférieur",
    "it": "Attiva o disattiva pannello inferiore"
  },
  "Zeilenumbruch": {
    "en": "Word wrap",
    "es": "Ajuste de línea",
    "fr": "Retour automatique à la ligne",
    "it": "A capo automatico"
  },
  "Minimap": {
    "en": "Minimap",
    "es": "Minimapa",
    "fr": "Minicarte",
    "it": "Minimappa"
  },
  "Aktive Datei ausführen": {
    "en": "Run active file",
    "es": "Ejecutar archivo activo",
    "fr": "Exécuter le fichier actif",
    "it": "Esegui file attivo"
  },
  "Projektaufgaben …": {
    "en": "Project tasks…",
    "es": "Tareas del proyecto…",
    "fr": "Tâches du projet…",
    "it": "Attività del progetto…"
  },
  "Neues PowerShell-Terminal": {
    "en": "New PowerShell terminal",
    "es": "Nuevo terminal PowerShell",
    "fr": "Nouveau terminal PowerShell",
    "it": "Nuovo terminale PowerShell"
  },
  "Neues cmd-Terminal": {
    "en": "New cmd terminal",
    "es": "Nuevo terminal cmd",
    "fr": "Nouveau terminal cmd",
    "it": "Nuovo terminale cmd"
  },
  "Aktiven Prozess abbrechen": {
    "en": "Interrupt active process",
    "es": "Interrumpir proceso activo",
    "fr": "Interrompre le processus actif",
    "it": "Interrompi processo attivo"
  },
  "Bedienungsanleitung": {
    "en": "User guide",
    "es": "Guía de uso",
    "fr": "Guide d'utilisation",
    "it": "Guida utente"
  },
  "Über CodeStudio": {
    "en": "About CodeStudio",
    "es": "Acerca de CodeStudio",
    "fr": "À propos de CodeStudio",
    "it": "Informazioni su CodeStudio"
  },
  "Zugriff verweigert.": {
    "en": "Access denied.",
    "es": "Acceso denegado.",
    "fr": "Accès refusé.",
    "it": "Accesso negato."
  },
  "Ungültige Aktion.": {
    "en": "Invalid action.",
    "es": "Acción no válida.",
    "fr": "Action non valide.",
    "it": "Azione non valida."
  },
  "Die Anfrage ist zu groß.": {
    "en": "The request is too large.",
    "es": "La solicitud es demasiado grande.",
    "fr": "La requête est trop volumineuse.",
    "it": "La richiesta è troppo grande."
  },
  "Ungültige Einstellungen.": {
    "en": "Invalid settings.",
    "es": "Configuración no válida.",
    "fr": "Paramètres non valides.",
    "it": "Impostazioni non valide."
  },
  "Unbekanntes Menü.": {
    "en": "Unknown menu.",
    "es": "Menú desconocido.",
    "fr": "Menu inconnu.",
    "it": "Menu sconosciuto."
  },
  "„{name}“ wurde geändert.": {
    "en": "“{name}” has changed.",
    "es": "«{name}» ha cambiado.",
    "fr": "«{name}» a été modifié.",
    "it": "«{name}» è stato modificato."
  },
  "Möchten Sie die Änderungen vor dem Schließen speichern?": {
    "en": "Save your changes before closing?",
    "es": "¿Guardar los cambios antes de cerrar?",
    "fr": "Enregistrer les modifications avant de fermer ?",
    "it": "Salvare le modifiche prima di chiudere?"
  },
  "Verwerfen": {
    "en": "Discard",
    "es": "Descartar",
    "fr": "Ignorer",
    "it": "Scarta"
  },
  "Fortfahren?": {
    "en": "Continue?",
    "es": "¿Continuar?",
    "fr": "Continuer ?",
    "it": "Continuare?"
  },
  "Fortfahren": {
    "en": "Continue",
    "es": "Continuar",
    "fr": "Continuer",
    "it": "Continua"
  },
  "Der Zwischenablagetext ist ungültig.": {
    "en": "Invalid clipboard text.",
    "es": "Texto del portapapeles no válido.",
    "fr": "Texte du presse-papiers non valide.",
    "it": "Testo degli appunti non valido."
  },
  "Diese Adresse ist nicht erlaubt.": {
    "en": "This address is not allowed.",
    "es": "Esta dirección no está permitida.",
    "fr": "Cette adresse n'est pas autorisée.",
    "it": "Questo indirizzo non è consentito."
  },
  "Link im Standardbrowser öffnen?": {
    "en": "Open link in the default browser?",
    "es": "¿Abrir enlace en el navegador predeterminado?",
    "fr": "Ouvrir le lien dans le navigateur par défaut ?",
    "it": "Aprire il collegamento nel browser predefinito?"
  },
  "Öffnen": {
    "en": "Open",
    "es": "Abrir",
    "fr": "Ouvrir",
    "it": "Apri"
  },
  "Unbekannte Aktion.": {
    "en": "Unknown action.",
    "es": "Acción desconocida.",
    "fr": "Action inconnue.",
    "it": "Azione sconosciuta."
  },
  "Unbekanntes Ereignis.": {
    "en": "Unknown event.",
    "es": "Evento desconocido.",
    "fr": "Événement inconnu.",
    "it": "Evento sconosciuto."
  },
  "Die Aktion konnte nicht ausgeführt werden.": {
    "en": "The action could not be completed.",
    "es": "No se pudo completar la acción.",
    "fr": "L'action n'a pas pu être effectuée.",
    "it": "Impossibile completare l'azione."
  },
  "Ungültige Sprache.": {
    "en": "Unsupported interface language.",
    "es": "Idioma de interfaz no compatible.",
    "fr": "Langue d'interface non prise en charge.",
    "it": "Lingua dell'interfaccia non supportata."
  },
  "Lokaler Code-Editor": {
    "en": "Local code editor",
    "es": "Editor de código local",
    "fr": "Éditeur de code local",
    "it": "Editor di codice locale"
  },
  "Windows x64 · Setup ohne Herausgebersignatur": {
    "en": "Windows x64 · Unsigned installer",
    "es": "Windows x64 · Instalador sin firma",
    "fr": "Windows x64 · Installateur non signé",
    "it": "Windows x64 · Installer non firmato"
  },
  "KI ist optional. Lokale Programme laufen mit Ihren Benutzerrechten.": {
    "en": "AI is optional. Local programs run with your user permissions.",
    "es": "La IA es opcional. Los programas locales usan tus permisos de usuario.",
    "fr": "L'IA est facultative. Les programmes locaux utilisent vos droits utilisateur.",
    "it": "L'IA è opzionale. I programmi locali usano i tuoi permessi utente."
  },
  "Die Datei wurde zwischenzeitlich geändert. Bitte Einfügen erneut ausführen.": {
    "en": "The file changed in the meantime. Please paste again.",
    "es": "El archivo cambió. Vuelve a pegar el contenido.",
    "fr": "Le fichier a changé. Réessayez de coller le contenu.",
    "it": "Il file è cambiato. Incolla di nuovo il contenuto."
  },
  "Die Datei wurde zwischenzeitlich geändert. Ausschneiden wurde abgebrochen.": {
    "en": "The file changed in the meantime. Cut was canceled.",
    "es": "El archivo cambió. Se canceló el corte.",
    "fr": "Le fichier a changé. La coupe a été annulée.",
    "it": "Il file è cambiato. Il taglio è stato annullato."
  },
  "Code-Editor": {
    "en": "Code editor",
    "es": "Editor de código",
    "fr": "Éditeur de code",
    "it": "Editor di codice"
  },
  "Lizenz: MIT": {
    "en": "License: MIT",
    "es": "Licencia: MIT",
    "fr": "Licence : MIT",
    "it": "Licenza: MIT"
  }
};
