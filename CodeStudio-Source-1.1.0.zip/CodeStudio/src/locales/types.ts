/** German source text is the stable key; German itself needs no duplicate value. */
export interface Translations {en:string;es:string;fr:string;it:string}
export type MessageCatalogue = Record<string,Translations>;
