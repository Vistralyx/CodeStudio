const message: string = 'Grüße aus TypeScript – wirklich kompiliert und ausgeführt.';
console.log(message);
