const readline = require('node:readline');
const terminal = readline.createInterface({ input: process.stdin, output: process.stdout });
terminal.question('Wie heißt du? ', name => { console.log(`Hallo, ${name}! Grüße aus JavaScript.`); terminal.close(); });
