# Beispielprojekt

Öffne diesen Ordner in CodeStudio. Starte `index.html`, `hallo.js`, `hallo.ts`, `hallo.py`, `Hallo.java` oder `hallo.kt` mit **Ausführen**. Eigene Laufzeiten müssen unter Einstellungen verfügbar sein. Python und JavaScript fragen interaktiv nach einem Namen; klicke ins Ausführungsterminal, gib einen Namen ein und drücke Enter. `dauerlauf.js` lässt sich mit **Stoppen** beenden.
