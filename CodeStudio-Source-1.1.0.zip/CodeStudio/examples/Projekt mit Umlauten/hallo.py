name = input('Wie heißt du? ')
print(f'Hallo, {name}! Grüße aus Python.')
