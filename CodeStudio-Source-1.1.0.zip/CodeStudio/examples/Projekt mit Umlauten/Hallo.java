public class Hallo {
    public static void main(String[] args) {
        System.out.println("Grüße aus Java – kompiliert und ausgeführt.");
    }
}
