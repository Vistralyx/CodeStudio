document.querySelector('#aktion').addEventListener('click', () => {
  document.querySelector('#meldung').textContent = 'JavaScript läuft in der isolierten Projektvorschau.';
});
