fun main() {
    println("Grüße aus Kotlin – kompiliert und ausgeführt.")
}
