setInterval(() => console.log('Programm läuft. Mit Stoppen beenden.'), 1000);
